/* ECHO — independent, offline-first Spotify statistics dashboard. No external JavaScript deps. */
(() => {
'use strict';
const periods=[['7d','7 dias'],['30d','30 dias'],['90d','90 dias'],['365d','1 ano'],['all','Tudo']];
const weekdays=['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
const fullWeekdays=['domingo','segunda-feira','terça-feira','quarta-feira','quinta-feira','sexta-feira','sábado'];
const native=typeof window.EchoNative!=='undefined';
const fmt=new Intl.NumberFormat('pt-BR');
const el=id=>document.getElementById(id);
const escapeHtml=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const n=v=>Number(v)||0;
const num=v=>fmt.format(Math.round(n(v)));
const compact=v=>n(v)>=1000000?(n(v)/1e6).toFixed(1).replace('.',',')+' mi':n(v)>=10000?(n(v)/1000).toFixed(1).replace('.',',')+' mil':num(v);
const hash=s=>[...String(s)].reduce((a,c)=>((a*31+c.charCodeAt(0))>>>0),21);
const palette=[['#9c7efc','#474b8e'],['#65c2b9','#3a607a'],['#fb917a','#6c416c'],['#a9db73','#4e6f64'],['#f9ba6a','#b76d84'],['#80adfb','#574ca0']];
const cleanUrl=s=>{try{let u=new URL(s);return u.protocol==='https:'?u.href:''}catch{return''}};
const spotifyLink=item=>cleanUrl(item?.external_urls?.spotify|| (item?.uri?.startsWith('spotify:track:')?'https://open.spotify.com/track/'+item.uri.split(':')[2] :''));
let period='30d',view='home',previewKind='tracks',rankingKind='tracks',rankingSource='history';
let spotify={},stats={},connected=false,clientId='',isDemo=!native,demoEvents=[],importedEvents=[],noticeTimer=0,importDb=null;

function toast(text,error=false){const t=el('toast');t.textContent=text;t.className='toast show'+(error?' error':'');clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>t.className='toast',5800)}
function nameTitle(k){return ({home:'Visão geral',ranking:'Rankings',radar:'Radar musical',history:'Linha do tempo',explore:'Universo ECHO',lab:'Laboratório',search:'Explorar acervo',games:'Jogos musicais',challenges:'Missões & conquistas',collection:'Coleção',mix:'Mix Lab',diary:'Diário musical',capsule:'Cápsula do tempo',settings:'Ajustes & conexão',life:'ECHO LIFE', 'life-letterboxd':'Cinema', 'life-steam':'Games', 'life-youtube':'YouTube'})[k]||'Visão geral'}
function navigate(next){view=next;document.querySelectorAll('.view').forEach(v=>v.classList.toggle('active',v.id==='view-'+next));document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===next));el('breadcrumb').textContent=nameTitle(next);window.scrollTo({top:0,behavior:'smooth'});render()}
function setPeriod(next){period=next;document.querySelectorAll('.period-tabs button').forEach(b=>b.classList.toggle('active',b.dataset.period===next));if(native){window.EchoNative.refresh(next)}else{stats=calculate(importedEvents.length?importedEvents:demoEvents,next);render()}}
function periodTabs(){document.querySelectorAll('.period-tabs').forEach(box=>box.innerHTML=periods.map(([value,label])=>`<button type="button" data-period="${value}" class="${period===value?'active':''}">${label}</button>`).join(''))}
const safeDate=value=>{const d=new Date(value);return isNaN(d.getTime())?null:d};
const dname=raw=>{const d=safeDate(raw+'T12:00:00');return d?d.toLocaleDateString('pt-BR',{day:'2-digit',month:'short',year:'numeric'}):raw};
function cover(name,image,artist=false){let colors=palette[hash(name)%palette.length];let initial=escapeHtml(String(name||'♪').trim().slice(0,1).toUpperCase());const url=cleanUrl(image);return `<span class="album-cover${artist?' artist-image':''}" style="background:linear-gradient(140deg,${colors[0]},${colors[1]})">${url?`<img src="${escapeHtml(url)}" alt="" loading="lazy" onerror="this.remove()">`:initial}</span>`}
function empty(message){return `<div class="empty-state"><span class="empty-symbol">✦</span><b>Seu som ainda não chegou por aqui</b><p>${escapeHtml(message)}</p><button class="small-outline" data-view="settings">Conectar ou importar ↗</button></div>`}
function getTop(type,source=rankingSource){
 if(source==='spotify'&&type!=='albums'){
  const range=(period==='7d'||period==='30d')?'short_term':period==='90d'?'medium_term':'long_term';
  const raw=spotify?.[type==='tracks'?'topTracks':'topArtists']?.[range]||[];
  return raw.map((it,i)=>({name:it.name,artist:it.artists?.map(a=>a.name).join(', ')||'',image:it.album?.images?.[0]?.url||it.images?.[0]?.url,uri:it.uri,link:spotifyLink(it),plays:0,minutes:0,rank:i+1,official:true,genres:it.genres||[]}));
 }
 return (type==='tracks'?stats.topTracks:type==='artists'?stats.topArtists:stats.topAlbums)||[];
}
function activeSource(){let withHistory=n(stats?.summary?.exactEntries)>0||!connected;return rankingSource==='spotify'&&!connected&&!isDemo?'history':rankingSource==='history'&&!withHistory&&connected?'spotify':rankingSource}
function showRanks(items,{full=false,kind='tracks',source='history'}={}){
 if(!items.length)return empty(source==='spotify'?'Conecte o Spotify e sincronize os rankings oficiais.':'Importe o histórico do Spotify para descobrir os favoritos.');
 return items.slice(0,full?30:4).map((item,i)=>{
  const title=item.name||'Música desconhecida';const secondary=kind==='tracks'?(item.artist||'Artista desconhecido'):kind==='albums'?(item.artist||'Álbum'):(item.official?'Top oficial do Spotify':`${num(item.plays||0)} reproduções`);
  let measure='';if(item.official)measure='<b>TOP '+(i+1)+'</b><span>afinidade</span>';else if(n(stats?.summary?.exactEntries))measure=`<b>${num(item.minutes)} min</b><span>${num(item.plays)} plays</span>`;else measure=`<b>${num(item.plays)} plays</b>`;
  const link=cleanUrl(item.link||spotifyLink(item));
  return `<div class="rank-row"><span class="rank-number">${String(i+1).padStart(2,'0')}</span>${cover(title,item.image,kind==='artists')}<div class="rank-meta"><strong>${escapeHtml(title)}</strong><span>${escapeHtml(secondary)}</span></div><div class="rank-measure">${measure}</div>${link?`<button class="rank-arrow" data-spotify-url="${escapeHtml(link)}" aria-label="Abrir no Spotify">↗</button>`:''}</div>`;
 }).join('')
}
function renderHome(){
 const s=stats.summary||{};const exact=n(s.exactEntries)>0;
 el('hero-minutes').textContent=exact?compact(s.minutes):'—';
 el('hero-subtitle').textContent=isDemo?'Estatísticas de exemplo. Importe seu histórico para ver os seus números.':exact?'Minutos reais registrados no período escolhido.':'Importe seu histórico para revelar o tempo real de escuta.';
 el('hero-total').textContent=num(s.plays)+' reproduções registradas';
 el('metric-plays').textContent=compact(s.plays);el('metric-artists').textContent=num(s.artists);el('metric-songs').textContent=num(s.songs);el('metric-streak').textContent=num(s.currentStreak);
 el('note-plays').textContent=isDemo?'Dados de exemplo':exact?'No histórico importado':'Capturadas pelo app';
 const source=activeSource();const kind=previewKind;el('preview-ranks').innerHTML=showRanks(getTop(kind,source),{kind,source});
 document.querySelectorAll('#preview-switch button').forEach(b=>b.classList.toggle('on',b.dataset.kind===kind));
 const now=spotify.nowPlaying?.item||null;document.querySelector('.live-dot').style.display=(spotify.nowPlaying?.is_playing?'inline-block':'none');
 const np=el('now-playing');
 if(now && spotify.nowPlaying?.is_playing){const coverUrl=now.album?.images?.[0]?.url;const pos=n(spotify.nowPlaying?.progress_ms),duration=n(now.duration_ms);
 np.innerHTML=`<div class="playing-upper"><div class="playing-cover">${cleanUrl(coverUrl)?`<img src="${escapeHtml(cleanUrl(coverUrl))}" alt="Capa do álbum">`:'♫'}</div><div class="playing-text"><strong>${escapeHtml(now.name)}</strong><span>${escapeHtml(now.artists?.map(a=>a.name).join(', ')||'Spotify')}</span></div><span class="playing-live">♪</span></div><div><div class="playing-progress"><span style="width:${duration?Math.round(pos/duration*100):0}%"></span></div><div class="playing-times"><span>${Math.floor(pos/60000)}:${String(Math.floor(pos/1000)%60).padStart(2,'0')}</span><span>${Math.floor(duration/60000)}:${String(Math.floor(duration/1000)%60).padStart(2,'0')}</span></div></div>`;
 }else np.innerHTML=`<div class="now-empty"><span class="now-symbol">♫</span><strong>Nada tocando neste instante</strong><small>${connected?'Abra o Spotify e toque uma música. Depois atualize os dados.':'Conecte seu Spotify para ver a faixa que estiver tocando.'}</small></div>`;
 const insp=buildInsights();el('home-insight').textContent=insp[1]?.description||'Comece a escutar e importe seus dados para revelar seus hábitos.';
 el('highlight-insight').innerHTML=`${escapeHtml(insp[0]?.title||'Sua música, do seu jeito.')} <strong>${escapeHtml(insp[0]?.value||'✳')}</strong>`;
 const hours=Array.from({length:24},(_,i)=>n(stats.hours?.find(x=>n(x.hour)===i)?.plays));
 const peak=Math.max(...hours,1);el('home-hours').innerHTML=hours.map((v,i)=>`<span class="hour-bar ${v===peak&&v>0?'peak':''}" style="height:${Math.max(3,Math.round(v/peak*100))}%" title="${String(i).padStart(2,'0')}h: ${num(v)} reproduções"></span>`).join('');
 const sync=spotify.lastSync;el('updated-label').textContent=sync?'Spotify atualizado '+new Date(sync).toLocaleDateString('pt-BR'):'Seu retrato musical';
}
function renderRanking(){
 if(rankingKind==='albums'&&rankingSource==='spotify')rankingSource='history';
 let source=activeSource();
 if(rankingKind==='albums')source='history';
 document.querySelectorAll('#ranking-kind button').forEach(b=>b.classList.toggle('chosen',b.dataset.kind===rankingKind));
 const select=el('ranking-source');select.value=source;
 select.querySelector('[value=spotify]').disabled=rankingKind==='albums'||(!connected&&!isDemo);
 el('ranking-explainer').textContent=source==='spotify'?'Ordem de afinidade calculada pelo Spotify. Não representa uma contagem exata de reproduções.':'Ordem por minutos de escuta registrados; desempate por número de reproduções. Apenas dados disponíveis no seu dispositivo.';
 el('full-ranks').innerHTML=showRanks(getTop(rankingKind,source),{full:true,kind:rankingKind,source});
}
function topHour(){return (stats.hours||[]).slice().sort((a,b)=>n(b.plays)-n(a.plays))[0]||null}
function topWeekday(){return (stats.weekdays||[]).slice().sort((a,b)=>n(b.plays)-n(a.plays))[0]||null}
function buildInsights(){const summary=stats.summary||{},hour=topHour(),weekday=topWeekday(),track=stats.topTracks?.[0],artist=stats.topArtists?.[0],days=stats.topDays||[];
 const out=[];
 if(hour){let h=n(hour.hour),desc=h>=22||h<=4?'Você e a madrugada têm uma conexão especial.':h>=5&&h<=11?'Suas manhãs ganham ritmo com música.':h>=12&&h<=17?'A trilha sonora do seu dia ganha força à tarde.':'A noite é seu horário favorito para dar play.';out.push({emoji:h>=22||h<=4?'🌙':h<12?'☀️':'🌆',title:h>=22||h<=4?'Coruja musical':h<12?'Bom dia, música!':'Sua hora favorita',description:desc,value:String(h).padStart(2,'0')+'h – '+String((h+1)%24).padStart(2,'0')+'h'});}
 if(track){out.push({emoji:'🔁',title:'No repeat? Nunca!',description:`${track.name} é sua música mais recorrente neste período.`,value:num(track.plays)+' reproduções'});}
 if(artist){out.push({emoji:'👑',title:'Fã de carteirinha',description:`${artist.name} lidera sua lista pessoal de artistas.`,value:n(summary.exactEntries)>0?num(artist.minutes)+' min registrados':num(artist.plays)+' plays'});}
 if(weekday){out.push({emoji:'📅',title:'O dia do play',description:`${fullWeekdays[n(weekday.day)]} é o dia da semana mais musical por aqui.`,value:num(weekday.plays)+' reproduções'});}
 if(n(summary.bestStreak))out.push({emoji:'🔥',title:'Maratona musical',description:'Seu maior período com música em dias consecutivos.',value:num(summary.bestStreak)+' dias seguidos'});
 if(days.length){const d=days[0];out.push({emoji:'⚡',title:'Dia inesquecível',description:`O dia ${dname(d.date)} teve o maior tempo de escuta do período.`,value:num(d.minutes)+' minutos'});}
 if(n(summary.artists)>0)out.push({emoji:'✨',title:'Explorador sonoro',description:'O número de artistas diferentes que passaram pelos seus fones.',value:num(summary.artists)+' artistas'});
 if(n(summary.exactEntries)&&n(summary.skips))out.push({emoji:'⏭',title:'Próxima faixa',description:'Faixas marcadas como puladas nos dados exportados.',value:num(summary.skips)+' pulos registrados'});
 return out;
}
function renderRadar(){const insights=buildInsights();el('insight-cards').innerHTML=(insights.length?insights:[{emoji:'✦',title:'Seu radar está em construção',description:'Conecte ou importe o histórico para descobrir curiosidades reais.',value:'Mais dados = mais histórias'}]).map(i=>`<article class="insight-card"><span class="insight-emoji">${i.emoji}</span><h3>${escapeHtml(i.title)}</h3><p>${escapeHtml(i.description)}</p><span class="insight-value">${escapeHtml(i.value)}</span></article>`).join('');
 const map=new Map((stats.heatmap||[]).map(it=>[`${it.day}-${it.hour}`,n(it.plays)]));let max=Math.max(...[...map.values()],1);
 el('heatmap').innerHTML=Array.from({length:168},(_,i)=>{let day=Math.floor(i/24),hour=i%24,value=map.get(day+'-'+hour)||0;let pct=value/max;let level=value===0?0:pct<.22?1:pct<.48?2:pct<.75?3:4;return `<div class="heatcell ${level?'h'+level:''}" title="${weekdays[day]}, ${hour}h: ${num(value)} reproduções"></div>`}).join('');
 let range=(period==='7d'||period==='30d')?'short_term':period==='90d'?'medium_term':'long_term';let arr=spotify.topArtists?.[range]||[];let genres=new Map();
 arr.forEach((artist,i)=>{(artist.genres||[]).forEach(g=>genres.set(g,(genres.get(g)||0)+Math.max(1,50-i)))});
 let topGenres=[...genres].sort((a,b)=>b[1]-a[1]).slice(0,6);let highest=topGenres[0]?.[1]||1;
 el('genres').innerHTML=topGenres.length?topGenres.map(([name,value])=>`<div class="genre-row"><div class="genre-head"><span>${escapeHtml(name)}</span><span>${Math.round(value/highest*100)}%</span></div><div class="genre-track"><span style="width:${Math.max(5,Math.round(value/highest*100))}%"></span></div></div>`).join(''):empty('O Spotify não disponibilizou gêneros para os artistas consultados. Essa informação pode estar indisponível na API atual.');
}
function renderHistory(){let months=stats.months||[],max=Math.max(...months.map(m=>n(m.minutes)),1);
 el('monthly-chart').innerHTML=months.length?months.slice(-16).map(m=>`<div class="month-group"><div class="month-bar" style="height:${Math.max(2,Math.round(n(m.minutes)/max*100))}%" title="${escapeHtml(m.month)}: ${num(m.minutes)} minutos"></div><span class="month-label">${escapeHtml(String(m.month).slice(5))}/${escapeHtml(String(m.month).slice(2,4))}</span></div>`).join(''):empty('Importe o histórico para acompanhar a sua evolução mês a mês.');
 el('top-days').innerHTML=stats.topDays?.length?stats.topDays.slice(0,5).map((d,i)=>`<div class="day-item"><span class="day-medal">${i+1}</span><div class="day-meta"><strong>${escapeHtml(dname(d.date))}</strong><span>${num(d.plays)} reproduções</span></div><b>${num(d.minutes)} min</b></div>`).join(''):empty('Os melhores dias vão aparecer aqui.');
 el('year-tiles').innerHTML=stats.years?.length?stats.years.map(y=>`<div class="year-tile"><strong>${escapeHtml(y.year)}</strong><small>${num(y.minutes)} minutos</small><p>${num(y.plays)} registros</p></div>`).join(''):empty('Envie o histórico estendido para ver todos os anos.');
}
function renderSettings(){
 el('client-id').value=clientId;
 const status=el('connect-status');status.textContent=connected?'● Spotify conectado':'● Spotify não conectado';status.className='connect-status'+(connected?' connected':'');
 el('connect-button').textContent=connected?'Reconectar ↗':'Conectar ↗';
 el('sync-button').disabled=!connected;el('disconnect-button').disabled=!connected;
 const name=spotify.profile?.display_name||spotify.profile?.id||'Meu perfil';el('profile-name').textContent=name;
 el('profile-avatar').textContent=name==='Meu perfil'?'♪':name[0].toUpperCase();
 const pill=el('mode-pill');pill.className='mode-pill'+(isDemo?'':connected?' live':' imported');pill.textContent=isDemo?'MODO DEMONSTRAÇÃO':connected?'● SPOTIFY CONECTADO':'DADOS LOCAIS';
 if(!native)el('import-button').textContent='↥  Importar arquivos .JSON';
}
function render(){renderSettings();if(view==='home')renderHome();if(view==='ranking')renderRanking();if(view==='radar')renderRadar();if(view==='history')renderHistory();if(window.EchoUniverse)window.EchoUniverse.render()}

function makeDemo(){const names=['Luna Atlas','Cores do Norte','Vento Sul','Maré Urbana','Aurora Azul','Nilo & Os Astros','Fio de Luz','Céu de Marte','Sol de Inverno'];const tracks=['Depois das Duas','Sem Pressa','Entre Nós','Outro Lugar','Noites Claras','Cor de Fim de Tarde','Tudo Vai','Luzes da Cidade','Nunca Foi Sorte','Amanhã, Talvez','Caminho de Volta','Carta ao Mar','Ainda Bem','Volta Pra Mim','Dois Segundos'];const genres=['indie pop','mpb','alternative rock','pop nacional','synthpop','indie folk'];let now=Date.now(),r=[];
 for(let i=0;i<1240;i++){let mix=(i*1013904223+1664525)>>>0,howLong=((i*31)%280),time=new Date(now-howLong*86400000 - (((i*17)%24)*3600000));let artist=names[(mix+i)%names.length];let title=tracks[((mix>>>4)+(i%6))%tracks.length];let duration=60000+((i*51731)%225000);r.push({at:time.toISOString(),artist,title,album:'Entre Estrelas',ms:duration,platform:i%3===0?'Android OS':'Desktop',source:'export',skipped:i%13===0?1:0,shuffle:i%4===0?1:0,offline:i%9===0?1:0,uri:''});}
 const albumList=names.map((name,i)=>({id:'demo_'+i,name,genres:[genres[i%genres.length],genres[(i+1)%genres.length]],images:[]}));let tlist=tracks.map((name,i)=>({name,artists:[{name:names[i%names.length]}],album:{images:[]}}));
 return {events:r,spotify:{profile:{display_name:'Visitante'},topTracks:{short_term:tlist,medium_term:tlist.slice().reverse(),long_term:tlist},topArtists:{short_term:albumList,medium_term:albumList,long_term:albumList},nowPlaying:{item:tlist[3],is_playing:false},lastSync:0}};
}
function calculate(events,p){const cutoff=p==='all'?0:Date.now()-parseInt(p)*86400000;let filtered=events.filter(x=>new Date(x.at).getTime()>=cutoff);let artistMap=new Map(),trackMap=new Map(),albumMap=new Map(),hourMap=new Map(),dayMap=new Map(),monthMap=new Map(),weekdayMap=new Map(),heat=new Map(),platformMap=new Map(),years=new Map(),activeDays=new Set(),exact=0,minutes=0,skips=0,shuffle=0,offline=0,qualified=0;let allYear=new Map(),monthlyTracks=new Map();
 for(const e of events){let y=e.at.slice(0,4),v=allYear.get(y)||{year:y,plays:0,minutes:0};v.plays++;v.minutes+=(e.ms||0)/60000;allYear.set(y,v)}
 for(const e of filtered){let d=safeDate(e.at);if(!d)continue;let day=d.getDay(),hour=d.getHours(),date=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`,month=date.slice(0,7),key=day+'-'+hour,ms=n(e.ms),count=ms>=30000||e.source==='api'?1:0,minute=ms/60000;
 if(e.source==='export')exact++;if(e.skipped===1)skips++;if(e.shuffle===1)shuffle++;if(e.offline===1)offline++;qualified+=count;minutes+=minute;activeDays.add(date);
 const accumulate=(map,key,info,weight)=>{let it=map.get(key)||{...info,plays:0,minutes:0};it.plays+=count;it.minutes+=minute;map.set(key,it)};
 accumulate(artistMap,e.artist||'Desconhecido',{name:e.artist||'Desconhecido'});
 accumulate(trackMap,e.artist+'|'+e.title,{name:e.title,artist:e.artist,album:e.album,uri:e.uri});
 if(e.album)accumulate(albumMap,e.artist+'|'+e.album,{name:e.album,artist:e.artist});
 let h=hourMap.get(hour)||{hour,plays:0,minutes:0};h.plays++;h.minutes+=minute;hourMap.set(hour,h);
 let w=weekdayMap.get(day)||{day,plays:0,minutes:0};w.plays++;w.minutes+=minute;weekdayMap.set(day,w);
 let mo=monthMap.get(month)||{month,plays:0,minutes:0};mo.plays++;mo.minutes+=minute;monthMap.set(month,mo);
 let da=dayMap.get(date)||{date,plays:0,minutes:0};da.plays++;da.minutes+=minute;dayMap.set(date,da);
 let hm=heat.get(key)||{day,hour,plays:0};hm.plays++;heat.set(key,hm);
 if(e.title&&e.artist){let mk=month+'|'+e.artist+'|'+e.title,mt=monthlyTracks.get(mk)||{month,name:e.title,artist:e.artist,plays:0,minutes:0};mt.plays+=count;mt.minutes+=minute;monthlyTracks.set(mk,mt)}
 if(e.platform){let pl=platformMap.get(e.platform)||{name:e.platform,plays:0};pl.plays++;platformMap.set(e.platform,pl)}
 }
 const top=m=>[...m.values()].sort((a,b)=>b.minutes-a.minutes||b.plays-a.plays).map(x=>({...x,minutes:Math.round(x.minutes)}));
 const dates=[...activeDays].sort(),dateSet=new Set(dates);let curr=0,best=0,run=0,prev=null;for(const date of dates){let ts=new Date(date+'T12:00:00').getTime();run=prev!=null&&ts-prev===86400000?run+1:1;best=Math.max(run,best);prev=ts}
 let today=new Date();const yy=today.getFullYear(),mm=String(today.getMonth()+1).padStart(2,'0'),dd=String(today.getDate()).padStart(2,'0');let latest=`${yy}-${mm}-${dd}`;if(!dateSet.has(latest)){let d=new Date(today.getTime()-86400000);latest=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
 while(dateSet.has(latest)){curr++;let d=new Date(latest+'T12:00:00');d.setDate(d.getDate()-1);latest=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
 return {period:p,summary:{entries:filtered.length,plays:qualified,minutes:Math.round(minutes),artists:artistMap.size,songs:trackMap.size,activeDays:activeDays.size,exactEntries:exact,skips,shuffle,offline,currentStreak:curr,bestStreak:best},topArtists:top(artistMap).slice(0,120),topTracks:top(trackMap).slice(0,180),topAlbums:top(albumMap).slice(0,90),hours:[...hourMap.values()],weekdays:[...weekdayMap.values()],months:[...monthMap.values()].sort((a,b)=>a.month.localeCompare(b.month)).map(x=>({...x,minutes:Math.round(x.minutes)})),heatmap:[...heat.values()],days:[...dayMap.values()].sort((a,b)=>a.date.localeCompare(b.date)),topDays:top(dayMap).slice(0,7),years:[...allYear.values()].sort((a,b)=>b.year.localeCompare(a.year)).map(x=>({...x,minutes:Math.round(x.minutes)})),platforms:[...platformMap.values()],monthlyFavorites:[...monthlyTracks.values()].sort((a,b)=>b.minutes-a.minutes||b.plays-a.plays).reduce((out,it)=>{if(!out.some(x=>x.month===it.month))out.push({...it,minutes:Math.round(it.minutes)});return out},[])};
}
function setupEvents(){document.addEventListener('click',event=>{const t=event.target.closest('button');if(!t)return;
 if(t.dataset.view){navigate(t.dataset.view);return}
 if(t.dataset.period){setPeriod(t.dataset.period);return}
 if(t.dataset.spotifyUrl){let url=t.dataset.spotifyUrl;if(native)window.EchoNative.openSpotify(url);else window.open(url,'_blank','noopener');return}
 if(t.parentElement?.id==='preview-switch'){previewKind=t.dataset.kind;renderHome();return}
 if(t.parentElement?.id==='ranking-kind'){rankingKind=t.dataset.kind;renderRanking();return}
 });
 el('ranking-source').addEventListener('change',e=>{rankingSource=e.target.value;renderRanking()});
 el('connect-button').addEventListener('click',()=>{
  const id=el('client-id').value.trim();
  if(!native){toast('A conexão direta usa o aplicativo Android. Nesta prévia você pode importar JSON.',true);return}
  if(!/^[a-fA-F0-9]{32}$/.test(id)){toast('O Spotify Client ID deve ter exatamente 32 caracteres hexadecimais.',true);return}
  window.EchoNative.connect(id)
 });
 el('sync-button').addEventListener('click',()=>{if(native)window.EchoNative.sync();else toast('Conecte sua conta no aplicativo Android.',true)});
 el('disconnect-button').addEventListener('click',()=>{if(native&&confirm('Desconectar do Spotify? O histórico importado ficará salvo.'))window.EchoNative.signOut()});
 el('import-button').addEventListener('click',()=>{if(native)window.EchoNative.importHistory();else el('browser-import').click()});
 el('export-button').addEventListener('click',async()=>{
  if(native){window.EchoNative.exportCsv();return}
  const rows=importedEvents.map(e=>[e.at,e.title,e.artist,e.album,(e.ms/60000).toFixed(2),'export',e.platform]);
  const csv=['data_utc,musica,artista,album,minutos,origem,plataforma',...rows.map(r=>r.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(','))].join('\n');
  const a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff'+csv],{type:'text/csv'}));a.download='echo_historico.csv';a.click();URL.revokeObjectURL(a.href);toast('CSV exportado.');
 });
 el('delete-button').addEventListener('click',async()=>{if(!confirm('Apagar todo o histórico que o ECHO guardou neste dispositivo?'))return;if(native){window.EchoNative.clearHistory()}else{importedEvents=[];try{await clearBrowserDatabase()}catch(ignore){}isDemo=true;stats=calculate(demoEvents,period);render();toast('Histórico local apagado. Voltando à demonstração.')}});
 el('share-main').addEventListener('click',()=>{const s=stats.summary||{},line=`Meu ECHO 🎧\nPeríodo: ${periods.find(x=>x[0]===period)?.[1]}\n${n(s.exactEntries)?num(s.minutes)+' minutos registrados\n':''}${num(s.plays)} reproduções | ${num(s.artists)} artistas\nArtista favorito: ${stats.topArtists?.[0]?.name||'—'}\n${isDemo?'(dados ilustrativos)\n':''}ECHO — sua música em números`;
  if(native)window.EchoNative.share(line);else if(navigator.clipboard?.writeText)navigator.clipboard.writeText(line).then(()=>toast('Resumo copiado!')).catch(()=>toast('Use o aplicativo Android para compartilhar.'));else toast('Use o aplicativo Android para compartilhar.');
 });
 el('browser-import').addEventListener('change',async e=>{let files=[...e.target.files];if(!files.length)return;let newEvents=[];try{
  for(const f of files){const raw=JSON.parse(await f.text());if(!Array.isArray(raw))continue;for(const item of raw){let title=item.master_metadata_track_name||item.trackName,artist=item.master_metadata_album_artist_name||item.artistName,at=item.ts||item.endTime;if(!title||!artist||!at)continue;if(at.includes(' ')&&!at.includes('T'))at=at.replace(' ','T')+(at.length===16?':00Z':'Z');newEvents.push({at,title,artist,album:item.master_metadata_album_album_name||'',ms:n(item.ms_played??item.msPlayed),uri:item.spotify_track_uri||'',source:'export',platform:item.platform||'',skipped:item.skipped===true?1:0,shuffle:item.shuffle===true?1:0,offline:item.offline===true?1:0});}}
  if(!newEvents.length){toast('Nenhuma faixa válida encontrada. Escolha um histórico JSON do Spotify.',true);return}
  let persistent=true;try{await saveBrowserEvents(newEvents);await loadBrowserEvents()}catch(storageErr){persistent=false;const byKey=new Map(importedEvents.map(x=>[x.at+"|"+x.artist+"|"+x.title,x]));for(const x of newEvents)byKey.set(x.at+"|"+x.artist+"|"+x.title,x);importedEvents=[...byKey.values()]}isDemo=false;spotify={};connected=false;rankingSource='history';stats=calculate(importedEvents,period);render();toast(`${num(newEvents.length)} registros lidos. Estatísticas atualizadas!${persistent?"":" (os dados não serão mantidos após fechar a prévia)"}`);
 }catch(ex){toast('Falha ao ler os arquivos: '+ex.message,true)}finally{e.target.value=''}});
}

function openDb(){return new Promise((resolve,reject)=>{if(!('indexedDB' in window))return reject(Error('IndexedDB indisponível'));const req=indexedDB.open('echo_history',1);req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains('plays'))db.createObjectStore('plays',{keyPath:'key'})};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
async function saveBrowserEvents(events){let db=importDb||(importDb=await openDb());for(let start=0;start<events.length;start+=500){let batch=events.slice(start,start+500);await new Promise((resolve,reject)=>{const tx=db.transaction('plays','readwrite'),store=tx.objectStore('plays');for(const e of batch)store.put({...e,key:e.at+'|'+e.artist+'|'+e.title});tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)})}}
async function loadBrowserEvents(){try{let db=importDb||(importDb=await openDb());importedEvents=await new Promise((resolve,reject)=>{const req=db.transaction('plays','readonly').objectStore('plays').getAll();req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}catch(e){importedEvents=[]}}
async function clearBrowserDatabase(){let db=importDb||(importDb=await openDb());await new Promise((resolve,reject)=>{const tx=db.transaction('plays','readwrite');tx.objectStore('plays').clear();tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)})}
window.ECHO={receive:payload=>{
 if(payload.type==='notice'){toast(payload.message,Boolean(payload.error));return}
 if(payload.type==='dashboard'){
   isDemo=false;connected=Boolean(payload.connected);clientId=payload.clientId||'';spotify=payload.spotify||{};stats=payload.stats||{};
   if(!n(stats.summary?.exactEntries)&&connected)rankingSource='spotify';
   render();
 }
}};
window.EchoRuntime={snapshot:()=>({period,view,spotify,stats,connected,isDemo,native}),events:()=>importedEvents.length?importedEvents:demoEvents,calculate,toast,navigate,escapeHtml,spotifyLink,number:num};
async function init(){periodTabs();setupEvents();if(native){stats={summary:{},topTracks:[],topArtists:[],topAlbums:[],hours:[],heatmap:[]};render()}else{let demo=makeDemo();demoEvents=demo.events;spotify=demo.spotify;await loadBrowserEvents();if(importedEvents.length){isDemo=false;spotify={};rankingSource='history'}else{isDemo=true;rankingSource='history'}stats=calculate(importedEvents.length?importedEvents:demoEvents,period);render()}}
init().catch(e=>{toast('Erro ao iniciar o ECHO: '+e.message,true);console.error(e)});
})();
