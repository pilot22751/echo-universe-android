package com.echomusic.stats;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;

import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Small native Android shell with secure Spotify PKCE, local SQLite, ZIP/JSON imports. */
public final class MainActivity extends Activity {
    private static final int REQUEST_IMPORT=221, REQUEST_EXPORT=222, REQUEST_LETTERBOXD=223;
    private WebView web;
    private SpotifyClient spotify;
    private StatsDatabase stats;
    private LifeIntegrations life;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private volatile String selectedPeriod="30d";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(10,12,22));
        getWindow().setNavigationBarColor(Color.rgb(10,12,22));
        spotify=new SpotifyClient(this);
        stats=new StatsDatabase(this);
        life=new LifeIntegrations(this);
        web=new WebView(this);
        WebSettings settings=web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccess(true); // only to load bundled android_asset HTML
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        web.setBackgroundColor(Color.rgb(10,12,22));
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Bridge(),"EchoNative");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri uri=req.getUrl();
                if ("file".equals(uri.getScheme()) && "android_asset".equals(uri.getAuthority())) return false;
                if ("https".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); } catch(Exception ignored) { }
                }
                return true;
            }
            @Override public void onPageFinished(WebView view,String url) { requestDashboard(selectedPeriod); requestLife(); }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        if (spotify.isConnected() && System.currentTimeMillis() - spotify.getCached().optLong("lastSync", 0L) > 30 * 60_000L) {
            worker.execute(this::syncSpotify);
        }
        if (getIntent()!=null && getIntent().getData()!=null) receiveOAuth(getIntent().getData());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getData()!=null) receiveOAuth(intent.getData());
    }

    private void receiveOAuth(Uri uri) {
        if (!"echomusicapp".equals(uri.getScheme()) || !"auth".equals(uri.getHost())) return;
        status("Concluindo conexão segura com o Spotify...",false);
        worker.execute(()->{
            try {
                spotify.finishAuthorization(uri);
                status("Spotify conectado! Buscando seus rankings...",false);
                syncSpotify();
            } catch (Exception e) { status("Falha no login: " + e.getMessage(),true); }
        });
    }

    private void syncSpotify() {
        try {
            JSONObject result=spotify.sync();
            int added=stats.addRecent(result.optJSONArray("recent"));
            requestDashboard(selectedPeriod);
            status("Spotify atualizado. " + added + " novas reproduções recentes registradas.",false);
        } catch(Exception e) { status("Não foi possível sincronizar: " + e.getMessage(),true); requestDashboard(selectedPeriod); }
    }

    private void requestDashboard(String period) {
        selectedPeriod=period;
        worker.execute(()->{
            try {
                JSONObject result=new JSONObject();
                result.put("type","dashboard");
                result.put("nativeApp",true);
                result.put("connected",spotify.isConnected());
                result.put("clientId",spotify.getClientId());
                result.put("spotify",spotify.getCached());
                result.put("stats",stats.dashboard(selectedPeriod));
                deliver(result);
            } catch(Exception e) { status("Falha ao ler estatísticas: " + e.getMessage(),true); }
        });
    }

    private void requestLife() {
        worker.execute(()->{
            try {deliver(new JSONObject().put("type","life").put("data",life.snapshot()));}
            catch(Exception e){status("Erro ao abrir conexões: "+e.getMessage(),true);}
        });
    }

    private void status(String message,boolean isError) {
        try {
            JSONObject obj=new JSONObject().put("type","notice")
                .put("message",message).put("error",isError);
            deliver(obj);
        } catch(Exception ignored) {}
    }

    private void deliver(JSONObject obj) {
        runOnUiThread(()->{
            if (web!=null) web.evaluateJavascript("window.ECHO&&window.ECHO.receive(" + obj.toString() + ");",null);
        });
    }

    private final class Bridge {
        @JavascriptInterface public void lifeSnapshot(){ requestLife(); }
        @JavascriptInterface public void lifeConfigure(String service,String identifier,String key) {
            worker.execute(()->{
                try {life.configure(service,identifier,key);requestLife();status("Configuração salva apenas neste aparelho. Agora toque em Sincronizar.",false);}
                catch(Exception e){status("Conexão: "+e.getMessage(),true);}
            });
        }
        @JavascriptInterface public void lifeSync(String service) {
            if(!"letterboxd".equals(service)&&!"steam".equals(service)&&!"youtube".equals(service))return;
            status("Buscando dados de "+service+"...",false);
            worker.execute(()->{
                try {life.sync(service);requestLife();status("Dados de "+service+" atualizados!",false);}
                catch(Exception e){status("Falha na sincronização de "+service+": "+e.getMessage(),true);}
            });
        }
        @JavascriptInterface public void lifeDisconnect(String service) {
            worker.execute(()->{life.disconnect(service);requestLife();status("Dados e credenciais locais removidos de "+service+".",false);});
        }
        @JavascriptInterface public void lifeImportLetterboxd() {
            runOnUiThread(()->{
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/csv","application/zip","application/x-zip-compressed","application/octet-stream","text/comma-separated-values"});
                startActivityForResult(i,REQUEST_LETTERBOXD);
            });
        }
        @JavascriptInterface public void lifeOpen(String url) {
            if(url==null||url.length()>1200)return;
            try {
                Uri u=Uri.parse(url);String host=u.getHost();
                if(!"https".equals(u.getScheme())||host==null||!(host.equals("letterboxd.com")||host.equals("www.letterboxd.com")||host.equals("steamcommunity.com")||host.equals("store.steampowered.com")||host.equals("www.youtube.com")||host.equals("youtube.com")||host.equals("youtu.be")||host.equals("developers.google.com")))return;
                runOnUiThread(()->startActivity(new Intent(Intent.ACTION_VIEW,u)));
            }catch(Exception ignored){}
        }

        @JavascriptInterface public void refresh(String period) {
            if (!period.matches("(7d|30d|90d|365d|all)")) period="30d";
            requestDashboard(period);
        }
        @JavascriptInterface public void connect(String clientId) {
            runOnUiThread(()->{
                try {
                    Uri auth=spotify.startAuthorization(clientId.trim());
                    startActivity(new Intent(Intent.ACTION_VIEW,auth));
                } catch(Exception e) { status(e.getMessage(),true); }
            });
        }
        @JavascriptInterface public void sync() {
            status("Atualizando dados do Spotify...",false);
            worker.execute(()->syncSpotify());
        }
        @JavascriptInterface public void importHistory() {
            runOnUiThread(()->{
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","application/zip","application/octet-stream","application/x-zip-compressed"});
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                startActivityForResult(i,REQUEST_IMPORT);
            });
        }
        @JavascriptInterface public void exportCsv() {
            runOnUiThread(()->{
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("text/csv");
                i.putExtra(Intent.EXTRA_TITLE,"echo_historico.csv");
                startActivityForResult(i,REQUEST_EXPORT);
            });
        }
        @JavascriptInterface public void share(String text) {
            runOnUiThread(()->{
                Intent intent=new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain"); intent.putExtra(Intent.EXTRA_TEXT,text);
                startActivity(Intent.createChooser(intent,"Compartilhar resumo do ECHO"));
            });
        }
        @JavascriptInterface public void signOut() {
            worker.execute(()->{
                spotify.signOut();
                requestDashboard(selectedPeriod);
                status("Conta desconectada. Histórico importado continua no celular.",false);
            });
        }
        @JavascriptInterface public void clearHistory() {
            worker.execute(()->{
                stats.clear();
                requestDashboard(selectedPeriod);
                status("Histórico local apagado.",false);
            });
        }
        @JavascriptInterface public void openSpotify(String url) {
            if (!url.startsWith("https://open.spotify.com/")) return;
            runOnUiThread(()->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url))));
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK || data==null) return;
        if(requestCode==REQUEST_IMPORT) {
            List<Uri> uris=new ArrayList<>();
            ClipData clip=data.getClipData();
            if(clip!=null) for(int i=0;i<clip.getItemCount();i++) uris.add(clip.getItemAt(i).getUri());
            else if(data.getData()!=null) uris.add(data.getData());
            if (uris.isEmpty()) return;
            status("Lendo e organizando seu histórico...",false);
            worker.execute(()->{
                try {
                    JSONObject report=new HistoryImporter(this,stats).importFiles(uris);
                    requestDashboard(selectedPeriod);
                    status("Importação concluída: " + report.optLong("added") +
                        " registros novos em " + report.optLong("files") + " arquivo(s).",false);
                } catch(Exception e) { status("Erro ao importar histórico: " + e.getMessage(),true); }
            });
        }
        if(requestCode==REQUEST_LETTERBOXD && data.getData()!=null) {
            Uri uri=data.getData();status("Importando seus filmes e avaliações do Letterboxd...",false);
            worker.execute(()->{
                try {JSONObject report=life.importLetterboxd(uri);requestLife();status("Letterboxd importado: "+report.optInt("importCount")+" entradas lidas.",false);}
                catch(Exception e){status("Erro no Letterboxd: "+e.getMessage(),true);}
            });
        }
        if(requestCode==REQUEST_EXPORT && data.getData()!=null) {
            Uri target=data.getData();
            worker.execute(()->{
                try(OutputStream out=getContentResolver().openOutputStream(target)) {
                    if(out==null) throw new IllegalStateException("Não foi possível abrir arquivo.");
                    out.write(stats.csv().getBytes(StandardCharsets.UTF_8));
                    status("CSV salvo no local escolhido.",false);
                } catch(Exception e) { status("Falha ao exportar: " + e.getMessage(),true); }
            });
        }
    }

    @Override protected void onDestroy() {
        if(web!=null) { web.removeJavascriptInterface("EchoNative"); web.destroy(); web=null; }
        worker.shutdown(); stats.close();
        super.onDestroy();
    }
}
