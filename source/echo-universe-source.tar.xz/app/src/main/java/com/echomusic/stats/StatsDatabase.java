package com.echomusic.stats;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.HashSet;
import java.util.Set;

/** Data stays on-device in SQLite. Imported ms_played represents measured listening time. */
public final class StatsDatabase extends SQLiteOpenHelper {
    StatsDatabase(Context context) { super(context, "echo_history.db", null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE plays (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT, played_at TEXT NOT NULL, title TEXT NOT NULL, " +
            "artist TEXT NOT NULL, album TEXT NOT NULL DEFAULT '', ms_played INTEGER NOT NULL DEFAULT 0, " +
            "track_uri TEXT NOT NULL DEFAULT '', platform TEXT NOT NULL DEFAULT '', " +
            "skipped INTEGER NOT NULL DEFAULT -1, shuffle INTEGER NOT NULL DEFAULT -1, offline INTEGER NOT NULL DEFAULT -1, " +
            "source TEXT NOT NULL)");
        db.execSQL("CREATE UNIQUE INDEX plays_dedupe ON plays(played_at, title, artist, source)");
        db.execSQL("CREATE INDEX plays_date ON plays(played_at)");
        db.execSQL("CREATE INDEX plays_artist ON plays(artist)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    SQLiteStatement insertStatement(SQLiteDatabase db) {
        return db.compileStatement("INSERT OR IGNORE INTO plays " +
            "(played_at,title,artist,album,ms_played,track_uri,platform,skipped,shuffle,offline,source) " +
            "VALUES(?,?,?,?,?,?,?,?,?,?,?)");
    }

    static long insert(SQLiteStatement stmt, String at, String title, String artist, String album,
                       long ms, String uri, String platform, int skipped, int shuffle, int offline, String source) {
        stmt.clearBindings();
        stmt.bindString(1, at); stmt.bindString(2, title); stmt.bindString(3, artist);
        stmt.bindString(4, album == null ? "" : album);
        stmt.bindLong(5, Math.max(ms, 0));
        stmt.bindString(6, uri == null ? "" : uri);
        stmt.bindString(7, platform == null ? "" : platform);
        stmt.bindLong(8, skipped); stmt.bindLong(9, shuffle); stmt.bindLong(10, offline);
        stmt.bindString(11, source);
        return stmt.executeInsert();
    }

    int addRecent(JSONArray recent) throws Exception {
        if (recent == null) return 0;
        SQLiteDatabase db = getWritableDatabase(); int added = 0;
        db.beginTransaction();
        try (SQLiteStatement stmt = insertStatement(db)) {
            for (int i=0; i<recent.length(); i++) {
                JSONObject item = recent.optJSONObject(i);
                if (item == null) continue;
                JSONObject track = item.optJSONObject("track");
                if (track == null) continue;
                String at = item.optString("played_at", "");
                String title = track.optString("name", "");
                JSONArray singers = track.optJSONArray("artists");
                String artist = singers != null && singers.length() > 0 ? singers.optJSONObject(0).optString("name", "") : "";
                if (at.isEmpty() || title.isEmpty() || artist.isEmpty()) continue;
                JSONObject album = track.optJSONObject("album");
                String albumName = album == null ? "" : album.optString("name", "");
                // The Web API does NOT tell how many milliseconds were actually listened to.
                if (insert(stmt, at, title, artist, albumName, 0, track.optString("uri", ""), "", -1, -1, -1, "api") >= 0) added++;
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        return added;
    }

    void clear() { getWritableDatabase().delete("plays", null, null); }

    static String timeWhere(String period) {
        int days;
        switch (period) {
            case "7d": days=7; break;
            case "30d": days=30; break;
            case "90d": days=90; break;
            case "365d": days=365; break;
            default: return "1=1";
        }
        return "played_at >= '" + Instant.now().minus(days, ChronoUnit.DAYS).toString() + "'";
    }

    JSONObject dashboard(String period) throws Exception {
        SQLiteDatabase db = getReadableDatabase();
        String where = timeWhere(period);
        JSONObject data = new JSONObject();
        data.put("period", period);
        JSONObject summary = new JSONObject();
        try (Cursor c = db.rawQuery("SELECT " +
            "COUNT(*), SUM(CASE WHEN ms_played>=30000 OR source='api' THEN 1 ELSE 0 END), " +
            "COALESCE(SUM(ms_played),0), " +
            "COUNT(DISTINCT artist), COUNT(DISTINCT title || '|' || artist), " +
            "COUNT(DISTINCT date(played_at,'localtime')), " +
            "SUM(CASE WHEN source='export' THEN 1 ELSE 0 END), " +
            "SUM(CASE WHEN skipped=1 THEN 1 ELSE 0 END), " +
            "SUM(CASE WHEN shuffle=1 THEN 1 ELSE 0 END), " +
            "SUM(CASE WHEN offline=1 THEN 1 ELSE 0 END) " +
            "FROM plays WHERE " + where, null)) {
            c.moveToFirst();
            summary.put("entries", c.getLong(0));
            summary.put("plays", c.getLong(1));
            summary.put("minutes", c.getLong(2) / 60000L);
            summary.put("artists", c.getLong(3));
            summary.put("songs", c.getLong(4));
            summary.put("activeDays", c.getLong(5));
            summary.put("exactEntries", c.getLong(6));
            summary.put("skips", c.getLong(7));
            summary.put("shuffle", c.getLong(8));
            summary.put("offline", c.getLong(9));
        }
        data.put("summary", summary);
        data.put("topArtists", queryArray(db, "SELECT artist name, COUNT(*) plays, SUM(ms_played)/60000 minutes " +
            "FROM plays WHERE " + where + " AND (ms_played>=30000 OR source='api') GROUP BY artist " +
            "ORDER BY SUM(ms_played) DESC, COUNT(*) DESC LIMIT 150", "name", "plays", "minutes"));
        data.put("topTracks", queryArray(db, "SELECT title name, artist, album, COUNT(*) plays, SUM(ms_played)/60000 minutes, MAX(track_uri) uri " +
            "FROM plays WHERE " + where + " AND (ms_played>=30000 OR source='api') GROUP BY artist,title " +
            "ORDER BY SUM(ms_played) DESC, COUNT(*) DESC LIMIT 150", "name","artist","album","plays","minutes","uri"));
        data.put("topAlbums", queryArray(db, "SELECT album name, artist, COUNT(*) plays, SUM(ms_played)/60000 minutes " +
            "FROM plays WHERE " + where + " AND album <> '' GROUP BY album,artist " +
            "ORDER BY SUM(ms_played) DESC, COUNT(*) DESC LIMIT 90", "name","artist","plays","minutes"));
        data.put("hours", queryArray(db, "SELECT CAST(strftime('%H',played_at,'localtime') AS INTEGER) hour, " +
            "COUNT(*) plays, SUM(ms_played)/60000 minutes FROM plays WHERE " + where + " GROUP BY hour ORDER BY hour", "hour", "plays", "minutes"));
        data.put("weekdays", queryArray(db, "SELECT CAST(strftime('%w',played_at,'localtime') AS INTEGER) day, " +
            "COUNT(*) plays, SUM(ms_played)/60000 minutes FROM plays WHERE " + where + " GROUP BY day ORDER BY day", "day", "plays", "minutes"));
        data.put("months", queryArray(db, "SELECT strftime('%Y-%m',played_at,'localtime') month, " +
            "COUNT(*) plays, SUM(ms_played)/60000 minutes FROM plays WHERE " + where + " GROUP BY month ORDER BY month", "month", "plays", "minutes"));
        data.put("heatmap", queryArray(db, "SELECT CAST(strftime('%w',played_at,'localtime') AS INTEGER) day, " +
            "CAST(strftime('%H',played_at,'localtime') AS INTEGER) hour, COUNT(*) plays " +
            "FROM plays WHERE " + where + " GROUP BY day,hour", "day", "hour", "plays"));
        data.put("days", queryArray(db, "SELECT date(played_at,'localtime') date, COUNT(*) plays, " +
            "SUM(ms_played)/60000 minutes FROM plays WHERE " + where + " GROUP BY date ORDER BY date", "date", "plays", "minutes"));
        data.put("topDays", queryArray(db, "SELECT date(played_at,'localtime') date, COUNT(*) plays, " +
            "SUM(ms_played)/60000 minutes FROM plays WHERE " + where + " GROUP BY date ORDER BY minutes DESC, plays DESC LIMIT 7", "date", "plays", "minutes"));
        data.put("platforms", queryArray(db, "SELECT platform name, COUNT(*) plays FROM plays " +
            "WHERE " + where + " AND platform <> '' GROUP BY platform ORDER BY plays DESC LIMIT 8", "name", "plays"));
        data.put("years", queryArray(db, "SELECT strftime('%Y',played_at,'localtime') year, COUNT(*) plays, " +
            "SUM(ms_played)/60000 minutes FROM plays GROUP BY year ORDER BY year DESC", "year", "plays", "minutes"));
        data.put("monthlyFavorites", queryArray(db, "SELECT month,name,artist,plays,minutes FROM (" +
            "SELECT strftime('%Y-%m',played_at,'localtime') AS month, title AS name, artist, " +
            "COUNT(*) AS plays, COALESCE(SUM(ms_played)/60000,0) AS minutes " +
            "FROM plays WHERE " + where + " GROUP BY month,title,artist) " +
            "GROUP BY month HAVING minutes=MAX(minutes) ORDER BY month DESC LIMIT 120", "month", "name", "artist", "plays", "minutes"));
        int[] streak = streaks(data.getJSONArray("days"));
        summary.put("currentStreak", streak[0]);
        summary.put("bestStreak", streak[1]);
        return data;
    }

    private static int[] streaks(JSONArray days) {
        int max=0, run=0, current=0;
        Set<LocalDate> dates = new HashSet<>();
        for (int i=0; i<days.length(); i++) {
            try { dates.add(LocalDate.parse(days.getJSONObject(i).getString("date"))); }
            catch (Exception ignored) {}
        }
        if (dates.isEmpty()) return new int[]{0,0};
        LocalDate d = dates.stream().min(LocalDate::compareTo).orElse(LocalDate.now());
        LocalDate end = dates.stream().max(LocalDate::compareTo).orElse(d);
        while (!d.isAfter(end)) {
            if (dates.contains(d)) { run++; max=Math.max(max,run); }
            else run=0;
            d=d.plusDays(1);
        }
        LocalDate today = LocalDate.now();
        if (!dates.contains(today)) today=today.minusDays(1);
        while (dates.contains(today)) { current++; today=today.minusDays(1); }
        return new int[]{current,max};
    }

    private static JSONArray queryArray(SQLiteDatabase db, String sql, String... columns) throws Exception {
        JSONArray array = new JSONArray();
        try (Cursor c = db.rawQuery(sql, null)) {
            while (c.moveToNext()) {
                JSONObject obj = new JSONObject();
                for (String col : columns) {
                    int idx = c.getColumnIndexOrThrow(col);
                    if (c.isNull(idx)) obj.put(col, JSONObject.NULL);
                    else if (c.getType(idx) == Cursor.FIELD_TYPE_INTEGER) obj.put(col, c.getLong(idx));
                    else if (c.getType(idx) == Cursor.FIELD_TYPE_FLOAT) obj.put(col, c.getDouble(idx));
                    else obj.put(col, c.getString(idx));
                }
                array.put(obj);
            }
        }
        return array;
    }

    String csv() {
        StringBuilder b = new StringBuilder("data_utc,musica,artista,album,minutos,origem,plataforma\n");
        try (Cursor c = getReadableDatabase().rawQuery("SELECT played_at,title,artist,album,ms_played,source,platform FROM plays ORDER BY played_at DESC", null)) {
            while (c.moveToNext()) {
                for (int col=0; col<7; col++) {
                    if (col>0) b.append(',');
                    String value = col == 4 ? String.valueOf(c.getLong(col)/60000.0) : c.getString(col);
                    b.append('"').append((value==null?"":value).replace("\"", "\"\"")).append('"');
                }
                b.append('\n');
            }
        }
        return b.toString();
    }
}
