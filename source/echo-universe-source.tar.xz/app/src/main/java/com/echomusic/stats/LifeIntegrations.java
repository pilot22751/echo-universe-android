package com.echomusic.stats;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/** Read-only personal data imports. Nothing is uploaded to an ECHO server. */
final class LifeIntegrations {
    private static final String STORE="echo_life_v1", KEY_ALIAS="echo.life.key.v1";
    private final Context context;
    private final SharedPreferences prefs;
    LifeIntegrations(Context ctx){context=ctx.getApplicationContext();prefs=context.getSharedPreferences(STORE,Context.MODE_PRIVATE);}

    private static boolean has(String s){return s!=null&&!s.trim().isEmpty();}
    private static String enc(String s){try{return java.net.URLEncoder.encode(s,"UTF-8");}catch(Exception e){throw new IllegalStateException(e);}}
    private static String str(JSONObject j,String name){return j.optString(name,"").trim();}
    private static String token(String s,int max){if(s==null||s.length()>max||!s.matches("[a-zA-Z0-9_@.\\-]+"))throw new IllegalArgumentException("Identificador inválido.");return s.trim();}
    private File path(String s){return new File(context.getFilesDir(),"echo_life_"+s+".json");}
    private JSONObject read(String s){try(FileInputStream in=new FileInputStream(path(s))){return new JSONObject(new String(readLimited(in,8_000_000),StandardCharsets.UTF_8));}catch(Exception e){return new JSONObject();}}
    private void save(String s,JSONObject o)throws Exception{
        File dest=path(s),tmp=new File(context.getFilesDir(),"echo_life_"+s+".tmp");
        byte[] bytes=o.toString().getBytes(StandardCharsets.UTF_8);
        try(FileOutputStream out=new FileOutputStream(tmp)){out.write(bytes);out.getFD().sync();}
        if(!tmp.renameTo(dest))throw new IllegalStateException("Não foi possível salvar os dados no celular.");
    }
    private SecretKey secretKey()throws Exception{
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(ks.containsAlias(KEY_ALIAS))return (SecretKey)ks.getKey(KEY_ALIAS,null);
        KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        g.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());
        return g.generateKey();
    }
    private void putSecret(String name,String value)throws Exception{
        if(!has(value)){prefs.edit().remove("secret_"+name).apply();return;}
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,secretKey());
        byte[] encrypted=c.doFinal(value.getBytes(StandardCharsets.UTF_8)),iv=c.getIV(),result=new byte[iv.length+encrypted.length];
        System.arraycopy(iv,0,result,0,iv.length);System.arraycopy(encrypted,0,result,iv.length,encrypted.length);
        prefs.edit().putString("secret_"+name,Base64.encodeToString(result,Base64.NO_WRAP)).apply();
    }
    private String getSecret(String name){
        try{String s=prefs.getString("secret_"+name,"");if(!has(s))return "";
            byte[] data=Base64.decode(s,Base64.DEFAULT);if(data.length<28)return "";
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,secretKey(),new GCMParameterSpec(128,data,0,12));
            return new String(c.doFinal(data,12,data.length-12),StandardCharsets.UTF_8);
        }catch(Exception e){return "";}
    }
    void configure(String service,String identifier,String key)throws Exception{
        if("letterboxd".equals(service)){
            String u=token(identifier.replace("https://letterboxd.com/","").replaceAll("/$",""),35);
            if(u.startsWith("@"))u=u.substring(1);
            prefs.edit().putString("letterboxd_user",u).apply();
        }else if("steam".equals(service)){
            String id=identifier.trim();if(!id.matches("[0-9]{17}"))throw new IllegalArgumentException("Use o SteamID64 de 17 dígitos (não o nome de usuário).");
            if(!has(key)&&!has(getSecret("steam")))throw new IllegalArgumentException("Informe sua Steam Web API Key.");
            if(has(key))putSecret("steam",key.trim());prefs.edit().putString("steam_id",id).apply();
        }else if("youtube".equals(service)){
            String ch=identifier.trim();
            if(!ch.matches("UC[a-zA-Z0-9_-]{20,35}")&&!ch.matches("@[a-zA-Z0-9_.-]{3,50}"))throw new IllegalArgumentException("Use o ID do canal (UC...) ou @handle.");
            if(!has(key)&&!has(getSecret("youtube")))throw new IllegalArgumentException("Informe sua chave da YouTube Data API v3.");
            if(has(key))putSecret("youtube",key.trim());prefs.edit().putString("youtube_channel",ch).apply();
        }else throw new IllegalArgumentException("Serviço desconhecido.");
    }
    void disconnect(String service){
        if(!"letterboxd".equals(service)&&!"steam".equals(service)&&!"youtube".equals(service))return;
        String id="letterboxd".equals(service)?"letterboxd_user":"steam".equals(service)?"steam_id":"youtube_channel";
        prefs.edit().remove(id).remove("secret_"+service).apply();path(service).delete();
    }
    JSONObject snapshot()throws Exception{
        JSONObject o=new JSONObject();
        JSONObject configured=new JSONObject();
        configured.put("letterboxd",prefs.getString("letterboxd_user",""));
        configured.put("steam",prefs.getString("steam_id",""));
        configured.put("steamKey",has(getSecret("steam")));
        configured.put("youtube",prefs.getString("youtube_channel",""));
        configured.put("youtubeKey",has(getSecret("youtube")));
        o.put("configured",configured);
        o.put("letterboxd",read("letterboxd"));o.put("steam",read("steam"));o.put("youtube",read("youtube"));
        return o;
    }
    private static byte[] http(String address,int max)throws Exception{
        URL url=new URL(address);
        if(!"https".equals(url.getProtocol()))throw new IllegalArgumentException("Apenas HTTPS é permitido.");
        HttpURLConnection c=(HttpURLConnection)url.openConnection();
        c.setConnectTimeout(12000);c.setReadTimeout(18000);c.setInstanceFollowRedirects(false);
        c.setRequestProperty("User-Agent","ECHO-Universe-Personal/3.0");
        c.setRequestProperty("Accept","application/json, application/rss+xml, application/xml");
        try{
            int status=c.getResponseCode();
            if(status<200||status>=300){String msg="HTTP "+status;try(InputStream es=c.getErrorStream()){
                if(es!=null){String detail=new String(readLimited(es,2048),StandardCharsets.UTF_8);
                    if(detail.trim().startsWith("{")){JSONObject json=new JSONObject(detail);msg+=": "+json.optJSONObject("error").optString("message","");}}}
                catch(Exception ignored){}
                throw new IllegalStateException("Serviço não respondeu: "+msg);
            }
            try(InputStream in=c.getInputStream()){return readLimited(in,max);}
        }finally{c.disconnect();}
    }
    private static byte[] readLimited(InputStream in,int cap)throws Exception{
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
        while((n=in.read(buf))!=-1){if(out.size()+n>cap)throw new IllegalStateException("Arquivo ou resposta acima do limite de segurança.");out.write(buf,0,n);}return out.toByteArray();
    }
    JSONObject sync(String service)throws Exception{
        if("letterboxd".equals(service))return syncLetterboxd();
        if("steam".equals(service))return syncSteam();
        if("youtube".equals(service))return syncYouTube();
        throw new IllegalArgumentException("Fonte inválida.");
    }
    private static String xmlField(Element e,String ns,String tag){
        NodeList nodes=e.getElementsByTagNameNS(ns,tag);if(nodes.getLength()>0)return nodes.item(0).getTextContent().trim();
        nodes=e.getElementsByTagNameNS("*",tag);return nodes.getLength()>0?nodes.item(0).getTextContent().trim():"";
    }
    private JSONObject syncLetterboxd()throws Exception{
        String username=prefs.getString("letterboxd_user","");if(!has(username))throw new IllegalStateException("Cadastre seu usuário Letterboxd.");
        byte[] data=http("https://letterboxd.com/"+enc(username)+"/rss/",3_000_000);
        DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();f.setNamespaceAware(true);
        f.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);
        f.setFeature("http://xml.org/sax/features/external-general-entities",false);
        f.setFeature("http://xml.org/sax/features/external-parameter-entities",false);
        f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,true);
        f.setExpandEntityReferences(false);f.setXIncludeAware(false);
        Document doc=f.newDocumentBuilder().parse(new ByteArrayInputStream(data));
        NodeList items=doc.getElementsByTagName("item");
        JSONArray fresh=new JSONArray();
        for(int i=0;i<items.getLength()&&i<160;i++){
            Element e=(Element)items.item(i);
            String title=xmlField(e,"https://letterboxd.com","filmTitle");
            String year=xmlField(e,"https://letterboxd.com","filmYear");
            String rating=xmlField(e,"https://letterboxd.com","memberRating");
            String watched=xmlField(e,"https://letterboxd.com","watchedDate");
            String link=xmlField(e,"","link");
            if(!has(title))continue;
            JSONObject row=new JSONObject().put("title",title).put("year",year).put("rating",rating)
                .put("date",watched).put("url",link.startsWith("https://letterboxd.com/")?link:"")
                .put("kind","diary").put("source","rss");
            fresh.put(row);
        }
        JSONObject old=read("letterboxd");JSONArray merged=merge(old.optJSONArray("items"),fresh,6500,true);
        JSONObject result=new JSONObject().put("items",merged).put("user",username).put("lastSync",System.currentTimeMillis())
            .put("rssFetched",fresh.length());
        save("letterboxd",result);return result;
    }
    private static JSONArray merge(JSONArray first,JSONArray second,int max,boolean diary){
        LinkedHashMap<String,JSONObject> map=new LinkedHashMap<>();
        for(JSONArray a:new JSONArray[]{first,second})if(a!=null)for(int i=0;i<a.length();i++){
            JSONObject r=a.optJSONObject(i);if(r==null)continue;
            String title=r.optString("title","").toLowerCase(Locale.ROOT),year=r.optString("year","");
            String date=r.optString("date","");
            String kind=r.optString("kind","watched");
            String key=title+"|"+year+"|"+date+"|"+kind;
            JSONObject existing=map.get(key);
            if(existing!=null){
                if(!has(r.optString("rating"))&&has(existing.optString("rating")))continue;
                if(!has(r.optString("url"))&&has(existing.optString("url")))try{r.put("url",existing.optString("url"));}catch(Exception ignored){}
            }
            map.put(key,r);
        }
        JSONArray out=new JSONArray();int count=0;for(JSONObject v:map.values()){if(count++>=max)break;out.put(v);}return out;
    }
    JSONObject importLetterboxd(Uri uri)throws Exception{
        String name=uri.getLastPathSegment()==null?"":uri.getLastPathSegment().toLowerCase(Locale.ROOT);
        byte[] bytes;try(InputStream in=context.getContentResolver().openInputStream(uri)){
            if(in==null)throw new IllegalStateException("Arquivo não encontrado.");bytes=readLimited(in,24_000_000);
        }
        JSONArray imported=new JSONArray();
        if(name.endsWith(".zip")||bytes.length>3&&bytes[0]==0x50&&bytes[1]==0x4b){
            int processed=0;try(ZipInputStream zin=new ZipInputStream(new ByteArrayInputStream(bytes),StandardCharsets.UTF_8)){
                ZipEntry entry;while((entry=zin.getNextEntry())!=null&&processed<150){
                    processed++;String path=entry.getName().replace('\\','/').toLowerCase(Locale.ROOT);
                    if(!entry.isDirectory()&&path.endsWith(".csv")&&(path.contains("diary")||path.contains("watched")||path.contains("rating")||path.contains("watchlist"))){
                        byte[] b=readLimited(zin,8_000_000);parseLetterboxdCsv(new String(b,StandardCharsets.UTF_8),path,imported);
                    }zin.closeEntry();
                }
            }
        }else parseLetterboxdCsv(new String(bytes,StandardCharsets.UTF_8),name,imported);
        if(imported.length()==0)throw new IllegalStateException("Não encontrei entradas de diário, avaliações, assistidos ou watchlist no arquivo.");
        JSONObject old=read("letterboxd");JSONArray merged=merge(old.optJSONArray("items"),imported,6500,true);
        old.put("items",merged).put("lastImport",System.currentTimeMillis()).put("importCount",imported.length());
        save("letterboxd",old);return old;
    }
    private static void parseLetterboxdCsv(String text,String path,JSONArray dest)throws Exception{
        List<List<String>> rows=csvRows(text);if(rows.size()<2)return;
        List<String> head=rows.get(0),names=new ArrayList<>();for(String h:head)names.add(h.trim().toLowerCase(Locale.ROOT).replace("\ufeff",""));
        int title=names.indexOf("name"),year=names.indexOf("year"),rating=names.indexOf("rating"),date=names.indexOf("watched date"),url=names.indexOf("letterboxd uri");
        if(title<0)title=names.indexOf("title");
        if(date<0)date=names.indexOf("date");
        if(title<0)return;
        String kind=path.contains("watchlist")?"watchlist":path.contains("rating")?"rating":path.contains("diary")?"diary":"watched";
        for(int i=1;i<rows.size()&&dest.length()<6500;i++){
            List<String> row=rows.get(i);String t=field(row,title);if(!has(t))continue;
            String link=field(row,url);if(!link.startsWith("https://letterboxd.com/"))link="";
            dest.put(new JSONObject().put("title",t).put("year",field(row,year)).put("rating",field(row,rating))
                .put("date",field(row,date)).put("kind",kind).put("source","export").put("url",link));
        }
    }
    private static String field(List<String> a,int idx){return idx>=0&&idx<a.size()?a.get(idx).trim():"";}
    private static List<List<String>> csvRows(String s){
        List<List<String>> rows=new ArrayList<>();List<String> row=new ArrayList<>();StringBuilder cell=new StringBuilder();boolean quoted=false;
        for(int i=0;i<s.length();i++){
            char c=s.charAt(i);
            if(c=='"'){if(quoted&&i+1<s.length()&&s.charAt(i+1)=='"'){cell.append('"');i++;}else quoted=!quoted;}
            else if(c==','&&!quoted){row.add(cell.toString());cell.setLength(0);}
            else if((c=='\n'||c=='\r')&&!quoted){if(c=='\r'&&i+1<s.length()&&s.charAt(i+1)=='\n')i++;row.add(cell.toString());cell.setLength(0);if(!row.isEmpty()&&row.size()>1)rows.add(row);row=new ArrayList<>();}
            else if(cell.length()<10000)cell.append(c);
        }
        row.add(cell.toString());if(row.size()>1)rows.add(row);return rows;
    }
    private JSONObject syncSteam()throws Exception{
        String steamId=prefs.getString("steam_id","");String key=getSecret("steam");
        if(!has(steamId)||!has(key))throw new IllegalStateException("Informe SteamID64 e Steam Web API Key.");
        String u="https://api.steampowered.com/IPlayerService/GetOwnedGames/v1/?key="+enc(key)+"&steamid="+enc(steamId)+"&include_appinfo=1&include_played_free_games=1";
        JSONObject response=new JSONObject(new String(http(u,3_000_000),StandardCharsets.UTF_8)).optJSONObject("response");
        if(response==null)throw new IllegalStateException("A Steam não devolveu dados da biblioteca.");
        JSONArray games=response.optJSONArray("games");
        if(games==null)games=new JSONArray();
        if(games.length()>3500)throw new IllegalStateException("A biblioteca excedeu o limite do ECHO.");
        JSONObject result=new JSONObject().put("games",games).put("count",response.optInt("game_count",games.length()))
            .put("steamId",steamId).put("lastSync",System.currentTimeMillis());
        save("steam",result);return result;
    }
    private JSONObject getYouTube(String path,String key)throws Exception{
        return new JSONObject(new String(http("https://www.googleapis.com/youtube/v3/"+path+"&key="+enc(key),3_000_000),StandardCharsets.UTF_8));
    }
    private JSONObject syncYouTube()throws Exception{
        String channel=prefs.getString("youtube_channel","");String key=getSecret("youtube");
        if(!has(channel)||!has(key))throw new IllegalStateException("Informe canal e chave da YouTube Data API.");
        String actualChannel=channel;
        if(channel.startsWith("@")){
            JSONObject response=getYouTube("channels?part=id%2Csnippet&forHandle="+enc(channel),key);
            JSONArray a=response.optJSONArray("items");if(a==null||a.length()==0)throw new IllegalStateException("Canal não encontrado. Confira o @handle.");
            actualChannel=a.getJSONObject(0).optString("id","");
        }
        JSONArray playlists=new JSONArray();String next="";int pages=0;
        do{
            JSONObject r=getYouTube("playlists?part=snippet%2CcontentDetails&maxResults=50&channelId="+enc(actualChannel)+(has(next)?"&pageToken="+enc(next):""),key);
            JSONArray a=r.optJSONArray("items");if(a!=null)for(int i=0;i<a.length()&&playlists.length()<200;i++)playlists.put(a.getJSONObject(i));
            next=r.optString("nextPageToken","");pages++;
        }while(has(next)&&pages<4);
        JSONArray videos=new JSONArray();
        for(int i=0;i<Math.min(4,playlists.length());i++){
            String id=playlists.getJSONObject(i).optString("id","");if(!has(id))continue;
            JSONObject r=getYouTube("playlistItems?part=snippet%2CcontentDetails&maxResults=50&playlistId="+enc(id),key);
            JSONArray a=r.optJSONArray("items");if(a!=null)for(int j=0;j<a.length();j++){
                JSONObject video=a.getJSONObject(j);video.put("echoPlaylistId",id);videos.put(video);
            }
        }
        JSONObject result=new JSONObject().put("channel",channel).put("channelId",actualChannel)
            .put("playlists",playlists).put("videos",videos).put("lastSync",System.currentTimeMillis());
        save("youtube",result);return result;
    }
}
