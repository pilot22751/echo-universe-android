package com.echomusic.stats;

import android.content.ContentResolver;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.util.JsonReader;
import android.util.JsonToken;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PushbackInputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Supports Spotify Account StreamingHistory*.json and Extended endsong_*.json, also ZIP. */
final class HistoryImporter {
    private final Context ctx;
    private final StatsDatabase stats;
    private long processed=0, added=0, ignored=0, files=0;
    private static final long MAX_RECORDS = 2_000_000;

    HistoryImporter(Context ctx, StatsDatabase stats) { this.ctx=ctx; this.stats=stats; }

    JSONObject importFiles(List<Uri> uris) throws Exception {
        SQLiteDatabase db = stats.getWritableDatabase();
        db.beginTransaction();
        try (SQLiteStatement stmt=stats.insertStatement(db)) {
            for (Uri uri:uris) {
                ContentResolver resolver=ctx.getContentResolver();
                String name = getName(resolver,uri).toLowerCase();
                try (InputStream raw=resolver.openInputStream(uri)) {
                    if (raw==null) continue;
                    PushbackInputStream sniff=new PushbackInputStream(new BufferedInputStream(raw),4);
                    byte[] signature=new byte[4]; int n=sniff.read(signature);
                    if (n>0) sniff.unread(signature,0,n);
                    boolean zip = name.endsWith(".zip") || (n>=4 && signature[0]=='P' && signature[1]=='K');
                    if (zip) importZip(sniff,stmt);
                    else { importJson(sniff,stmt); files++; }
                }
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        JSONObject report=new JSONObject();
        report.put("processed",processed); report.put("added",added);
        report.put("ignored",ignored); report.put("files",files);
        return report;
    }

    private void importZip(InputStream input, SQLiteStatement stmt) throws Exception {
        ZipInputStream zin=new ZipInputStream(input, StandardCharsets.UTF_8);
        ZipEntry entry;
        while ((entry=zin.getNextEntry()) != null) {
            String name=entry.getName().toLowerCase();
            if (!entry.isDirectory() && name.endsWith(".json") &&
                (name.contains("streaming") || name.contains("endsong") || name.contains("audio"))) {
                // JsonReader closes its own stream, not the ZIP outer stream.
                try { importJson(new FilterInputStream(zin) { @Override public void close() {} },stmt); files++; }
                catch (IllegalStateException e) { /* Other unrelated Spotify account JSON: skip. */ }
            }
            zin.closeEntry();
        }
    }

    private void importJson(InputStream input, SQLiteStatement stmt) throws Exception {
        JsonReader reader=new JsonReader(new InputStreamReader(input, StandardCharsets.UTF_8));
        if (reader.peek()!=JsonToken.BEGIN_ARRAY) throw new IllegalStateException("O arquivo não tem o formato de histórico do Spotify.");
        reader.beginArray();
        while(reader.hasNext()) {
            if (++processed>MAX_RECORDS) throw new IllegalStateException("Limite de 2 milhões de registros por importação atingido.");
            if (reader.peek()!=JsonToken.BEGIN_OBJECT) { reader.skipValue(); ignored++; continue; }
            String at="",title="",artist="",album="",uri="",platform="";
            long ms=0; int skipped=-1,shuffle=-1,offline=-1;
            reader.beginObject();
            while(reader.hasNext()) {
                String key=reader.nextName();
                switch(key) {
                    case "ts": at=nextText(reader); break;
                    case "endTime": at=nextText(reader); break;
                    case "master_metadata_track_name": title=nextText(reader); break;
                    case "trackName": title=nextText(reader); break;
                    case "master_metadata_album_artist_name": artist=nextText(reader); break;
                    case "artistName": artist=nextText(reader); break;
                    case "master_metadata_album_album_name": album=nextText(reader); break;
                    case "spotify_track_uri": uri=nextText(reader); break;
                    case "platform": platform=nextText(reader); break;
                    case "ms_played": case "msPlayed": ms=nextLong(reader); break;
                    case "skipped": skipped=nextFlag(reader); break;
                    case "shuffle": shuffle=nextFlag(reader); break;
                    case "offline": offline=nextFlag(reader); break;
                    default: reader.skipValue();
                }
            }
            reader.endObject();
            if (!at.isEmpty() && !title.isEmpty() && !artist.isEmpty() && ms>0) {
                at=normalizeAt(at);
                // When possible replace API placeholder whose precise listening duration was unknown.
                // API timestamps may differ in ms precision, so the two feeds are also explicitly marked.
                if (StatsDatabase.insert(stmt,at,title,artist,album,ms,uri,platform,skipped,shuffle,offline,"export")>=0) added++;
            } else ignored++;
        }
        reader.endArray();
    }

    private static String normalizeAt(String s) {
        if (s.length()==16 && s.charAt(10)==' ') return s.replace(' ','T')+":00Z";
        if (s.length()==19 && s.charAt(10)==' ') return s.replace(' ','T')+"Z";
        if (s.length()==16 && s.charAt(10)=='T') return s+":00Z";
        return s;
    }
    private static String nextText(JsonReader reader) throws IOException {
        JsonToken t=reader.peek();
        if(t==JsonToken.NULL) { reader.nextNull(); return ""; }
        if(t==JsonToken.STRING || t==JsonToken.NUMBER) return reader.nextString();
        reader.skipValue(); return "";
    }
    private static long nextLong(JsonReader reader) throws IOException {
        String text=nextText(reader);
        try { return Long.parseLong(text); } catch(Exception e) { return 0; }
    }
    private static int nextFlag(JsonReader reader) throws IOException {
        if(reader.peek()==JsonToken.NULL) {reader.nextNull(); return -1;}
        if(reader.peek()==JsonToken.BOOLEAN) return reader.nextBoolean()?1:0;
        String value=nextText(reader);
        if("true".equals(value) || "1".equals(value))return 1;
        if("false".equals(value) || "0".equals(value))return 0;
        return -1;
    }
    private static String getName(ContentResolver resolver, Uri uri) {
        try (Cursor c=resolver.query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)) {
            if(c!=null && c.moveToFirst()) return c.getString(0);
        } catch(Exception ignored) {}
        return uri.getLastPathSegment()==null?"historico.json":uri.getLastPathSegment();
    }
}
