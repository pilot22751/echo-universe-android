package com.echomusic.stats;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Locale;

/** Spotify Web API: OAuth 2.0 Authorization Code + PKCE. No client secret on device. */
public final class SpotifyClient {
    public static final String REDIRECT = "echomusicapp://auth/callback";
    private static final String SCOPES = "user-top-read user-read-recently-played user-read-currently-playing user-read-private";
    private final Context ctx;
    private final SharedPreferences prefs;
    private final File cacheFile;

    SpotifyClient(Context context) {
        ctx = context.getApplicationContext();
        prefs = ctx.getSharedPreferences("spotify_auth", Context.MODE_PRIVATE);
        cacheFile = new File(ctx.getFilesDir(), "spotify_cache.json");
    }

    boolean isConnected() {
        return !prefs.getString("refresh", "").isEmpty() || !prefs.getString("access", "").isEmpty();
    }

    String getClientId() { return prefs.getString("clientId", ""); }

    Uri startAuthorization(String clientId) throws Exception {
        if (clientId == null || !clientId.matches("(?i)[a-f0-9]{32}")) {
            throw new IllegalArgumentException("Informe o Client ID de 32 caracteres do Spotify for Developers.");
        }
        String verifier = randomBase64(64);
        String state = randomBase64(24);
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII));
        String challenge = Base64.encodeToString(digest, Base64.URL_SAFE | Base64.NO_PADDING | Base64.NO_WRAP);
        prefs.edit().putString("clientId", clientId).putString("verifier", verifier)
            .putString("oauthState", state).apply();
        return Uri.parse("https://accounts.spotify.com/authorize").buildUpon()
            .appendQueryParameter("client_id", clientId)
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("redirect_uri", REDIRECT)
            .appendQueryParameter("scope", SCOPES)
            .appendQueryParameter("state", state)
            .appendQueryParameter("code_challenge_method", "S256")
            .appendQueryParameter("code_challenge", challenge).build();
    }

    void finishAuthorization(Uri redirect) throws Exception {
        if (!REDIRECT.substring(0, REDIRECT.indexOf('/', REDIRECT.indexOf("://") + 3)).equals(
            redirect.getScheme() + "://" + redirect.getHost())) {
            throw new IllegalArgumentException("Callback do Spotify inválido.");
        }
        if (!"/callback".equals(redirect.getPath())) throw new IllegalArgumentException("Caminho de retorno incorreto.");
        String state = redirect.getQueryParameter("state");
        String expected = prefs.getString("oauthState", "");
        if (state == null || expected.isEmpty() || !MessageDigest.isEqual(
                state.getBytes(StandardCharsets.UTF_8), expected.getBytes(StandardCharsets.UTF_8))) {
            throw new IllegalArgumentException("O login expirou ou não passou na verificação de segurança.");
        }
        if (redirect.getQueryParameter("error") != null) throw new IllegalStateException("Autorização não concluída: " + redirect.getQueryParameter("error"));
        String code = redirect.getQueryParameter("code");
        if (code == null || code.isEmpty()) throw new IllegalArgumentException("Spotify não retornou um código de acesso.");
        String body = "grant_type=authorization_code&code=" + enc(code)
            + "&redirect_uri=" + enc(REDIRECT)
            + "&client_id=" + enc(getClientId())
            + "&code_verifier=" + enc(prefs.getString("verifier", ""));
        JSONObject response = tokenPost(body);
        saveTokens(response);
        prefs.edit().remove("oauthState").remove("verifier").apply();
    }

    JSONObject getCached() {
        try (FileInputStream in = new FileInputStream(cacheFile)) {
            return new JSONObject(readFully(in));
        } catch (Exception e) { return new JSONObject(); }
    }

    JSONObject sync() throws Exception {
        JSONObject result = new JSONObject();
        result.put("profile", get("/me"));
        JSONObject tracks = new JSONObject();
        JSONObject artists = new JSONObject();
        for (String period : new String[]{"short_term", "medium_term", "long_term"}) {
            tracks.put(period, get("/me/top/tracks?limit=50&time_range=" + period).optJSONArray("items"));
            artists.put(period, get("/me/top/artists?limit=50&time_range=" + period).optJSONArray("items"));
        }
        result.put("topTracks", tracks);
        result.put("topArtists", artists);
        result.put("recent", get("/me/player/recently-played?limit=50").optJSONArray("items"));
        try { result.put("nowPlaying", get("/me/player/currently-playing")); }
        catch (Exception ignored) { result.put("nowPlaying", new JSONObject()); }
        result.put("lastSync", System.currentTimeMillis());
        try (FileOutputStream out = new FileOutputStream(cacheFile)) {
            out.write(result.toString().getBytes(StandardCharsets.UTF_8));
        }
        return result;
    }

    void signOut() {
        prefs.edit().remove("access").remove("refresh").remove("expiry").remove("oauthState").remove("verifier").apply();
        // Keep imported history, and remove profile/rankings cached via API.
        if (cacheFile.exists()) cacheFile.delete();
    }

    private JSONObject get(String path) throws Exception {
        String token = getValidAccessToken();
        HttpURLConnection conn = (HttpURLConnection) new URL("https://api.spotify.com/v1" + path).openConnection();
        conn.setConnectTimeout(15000); conn.setReadTimeout(20000);
        conn.setRequestProperty("Authorization", "Bearer " + token);
        conn.setRequestProperty("Accept", "application/json");
        try {
            int status = conn.getResponseCode();
            if (status == 204) return new JSONObject();
            String body = readFully(status < 400 ? conn.getInputStream() : conn.getErrorStream());
            if (status == 429) throw new IllegalStateException("Spotify atingiu o limite temporário de requisições. Tente novamente mais tarde.");
            if (status >= 400) throw new IllegalStateException("Spotify API HTTP " + status + ": " + shorten(body));
            return new JSONObject(body);
        } finally { conn.disconnect(); }
    }

    private String getValidAccessToken() throws Exception {
        String access = prefs.getString("access", "");
        long expiry = prefs.getLong("expiry", 0L);
        if (!access.isEmpty() && System.currentTimeMillis() < expiry - 90_000L) return access;
        String refresh = prefs.getString("refresh", "");
        if (refresh.isEmpty()) throw new IllegalStateException("Conecte sua conta ao Spotify novamente.");
        JSONObject response = tokenPost("grant_type=refresh_token&refresh_token=" + enc(refresh)
            + "&client_id=" + enc(getClientId()));
        saveTokens(response);
        return prefs.getString("access", "");
    }

    private JSONObject tokenPost(String form) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL("https://accounts.spotify.com/api/token").openConnection();
        conn.setRequestMethod("POST"); conn.setDoOutput(true);
        conn.setConnectTimeout(15000); conn.setReadTimeout(20000);
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        byte[] bytes = form.getBytes(StandardCharsets.UTF_8);
        conn.setFixedLengthStreamingMode(bytes.length);
        try (OutputStream out = conn.getOutputStream()) { out.write(bytes); }
        try {
            int status = conn.getResponseCode();
            String body = readFully(status < 400 ? conn.getInputStream() : conn.getErrorStream());
            if (status >= 400) throw new IllegalStateException("Erro na autorização Spotify (" + status + "): " + shorten(body));
            return new JSONObject(body);
        } finally { conn.disconnect(); }
    }

    private void saveTokens(JSONObject response) {
        SharedPreferences.Editor edit = prefs.edit();
        edit.putString("access", response.optString("access_token", ""));
        if (response.has("refresh_token")) edit.putString("refresh", response.optString("refresh_token", ""));
        edit.putLong("expiry", System.currentTimeMillis() + response.optLong("expires_in", 3600) * 1000L);
        edit.apply();
    }

    private static String randomBase64(int count) {
        byte[] random = new byte[count]; new SecureRandom().nextBytes(random);
        return Base64.encodeToString(random, Base64.URL_SAFE | Base64.NO_PADDING | Base64.NO_WRAP);
    }
    private static String enc(String value) throws Exception {
        return java.net.URLEncoder.encode(value, "UTF-8");
    }
    private static String readFully(InputStream input) throws Exception {
        if (input == null) return "";
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        }
    }
    private static String shorten(String body) {
        return body.length() > 250 ? body.substring(0, 250) : body;
    }
}
