# VIDAVERSO — Simulador de vida original

Jogo Android offline, totalmente gratuito, sem anúncios e sem compras internas.

## O que já está jogável

- Do nascimento à velhice e continuidade como descendente.
- Criador de personagem: países, identidade, nome, modo livre ou realeza.
- 109 profissões em mais de 10 setores, com remuneração, promoções e desenvolvimento de habilidades.
- Formação universitária, pós-graduação, doutorado, 12 habilidades, 18 hobbies.
- Ações e eventos por faixa etária, consequências de decisões e registro da história.
- Amizades, romances, casamento, separação, filhos, adoção e pets.
- Empresas com faturamento, funcionários, valor de mercado e possibilidade de venda.
- Investimentos simulados, imóveis, aluguéis, veículos, dívida e custo de vida anual.
- Campanhas e cargos políticos fictícios, criação artística, fama, audiência e competições esportivas.
- Crime e consequência penal fictícia, prisão e recursos.
- 164 eventos narrativos com decisões, 67 conquistas, estatísticas, árvore genealógica e obituário.
- Salvamento automático local, slots, exportação/importação JSON.

## Instalar / construir

JDK 17, Android SDK 35, Android Gradle Plugin 8.7.3, Gradle 8.11.1.

```
gradle assembleDebug
```

APK resultante: `app/build/outputs/apk/debug/app-debug.apk`.

A compilação automatizada roda na aba Actions do repositório, usando o arquivo `.github/workflows/build-lifeverse.yml`. Após sucesso, baixe o artefato `VIDAVERSO-APK`.

## Escopo e direitos

VIDAVERSO é **um jogo novo, independente e original**. Não é o app BitLife, não tem relação com seus criadores, e **não altera, desbloqueia ou distribui** conteúdo premium pertencente a terceiros. O jogo contém recursos próprios de personalização, carreiras especiais e dinastias disponibilizados gratuitamente. Esta primeira versão contém um conjunto substancial de sistemas; não afirma possuir a totalidade das funções do jogo comercial.

Os dados ficam no aparelho via WebView localStorage. Não pede login nem acesso à internet. Antes de trocar de APK/aparelho, use exportação JSON para conservar sua história. APK de debug é para testes; distribuição pública requer assinatura de lançamento estável e testes de segurança e compatibilidade.
