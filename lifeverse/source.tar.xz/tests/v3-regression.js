/* Regressão 3.0: rodar com Node 22, sem dependências externas. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'../app/src/main/assets');const storage=new Map(),nodes={};
function el(id){return nodes[id]||(nodes[id]={value:'',innerHTML:'',textContent:'',checked:false,classList:{add(){},remove(){},toggle(){},contains(){return false}},append(){},select(){}});}
const ctx=vm.createContext({console,Date,Math,setTimeout(){return 0},clearTimeout(){},
 localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},
 document:{getElementById:el,documentElement:{classList:{toggle(){},contains(){return false}}},addEventListener(){},execCommand(){return true},body:{append(){}}},
 window:{addEventListener(){},scrollTo(){}},Blob,URL:{createObjectURL(){return 'blob://test';},revokeObjectURL(){}}
});
for(const f of ['data.js','events.js','game.js','expansion.js','content2.js','universe.js','ui.js','v3-data.js','v3-engine.js','v3-events.js','v3-ui.js','v3-special.js','v3-hooks.js'])vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),ctx,{filename:f});
function run(src){return vm.runInContext(src,ctx);}
function same(a,b,msg){assert.equal(a,b,msg);}
function yes(v,msg){assert(v,msg);}
const counts=run('({jobs:DB.jobs.length,distinct:new Set(DB.jobs.map(x=>x[0])).size,events:EV.length+V2_EVENT_PACK.length+V3_EVENTS.length,v3Events:V3_EVENTS.length,medals:DB.challenges.length,degrees:DB.degrees.length,conditions:V3_CONDITIONS.length,properties:DB.property.length,ventures:DB.ventures.length,countries:DB.countries.length})');
console.log("AUDITORIA PRELIMINAR",JSON.stringify(counts));
yes(counts.jobs>=250&&counts.jobs===counts.distinct,'Profissões repetidas ou abaixo de 250');yes(counts.degrees>=60&&counts.ventures>=40&&counts.properties>=25,'Conteúdo novo não carregado');
run("makeLife({name:'Lia',gender:'F',mode:'normal',startAdult:true,aspiration:'ciencia'});closeModal()");same(run('S.v3.version'),3);same(run('S.v2.version'),2);same(run('S.v3.school.graduated'),true);
for(const name of ['motor3','carreira3','formacao3','pessoas3','patrimonio3','saude3','auditoria3','especiais3']){
 run(`go('universo',${JSON.stringify(name)})`);yes(el('app').innerHTML.includes('VIDAVERSO 3.0'),name);yes(el('app').innerHTML.length>700,'Tela vazia: '+name);
}
// Regras antifarm, persistência e interação com NPCs.
const parentId=run('S.parents[0].id');const firstBond=run('S.parents[0].bond');
run(`action('v2Relationship',${JSON.stringify(parentId+'|talk')})`);const bondAfter=run('S.parents[0].bond');yes(bondAfter>firstBond,'Primeira conversa deveria afetar vínculo');
const energyAfter=run('S.stats.energy');run(`action('v2Relationship',${JSON.stringify(parentId+'|talk')})`);same(run('S.parents[0].bond'),bondAfter,'Conversar duas vezes no ano aumentou o vínculo');same(run('S.stats.energy'),energyAfter,'Conversa bloqueada gastou energia');
run('save(); S=null;restore()');same(run('S.parents[0].bond'),bondAfter,'Relacionamento não persistiu');run(`action('v2Relationship',${JSON.stringify(parentId+'|talk')})`);same(run('S.parents[0].bond'),bondAfter,'Reiniciar burlou o limite anual');
const second=run('S.parents[1].id');run(`action('v2Relationship',${JSON.stringify(second+'|talk')})`);yes(run('S.parents[1].bond')>0,'Outro NPC deve permitir conversa');
run('ageOneYear();closeModal()');const nextYear=run('S.year');run(`action('v2Relationship',${JSON.stringify(parentId+'|talk')})`);same(run('S.v3.limits[v3LimitKey("relationship_talk","person:"+S.parents[0].id)]'),1,'Conversa não liberou no ano seguinte');
// Pessoa falecida não participa.
run('S.parents[1].alive=false');const oldBond=run('S.parents[1].bond');run(`action('v2Relationship',${JSON.stringify(second+'|talk')})`);same(run('S.parents[1].bond'),oldBond);
// Formação não relacionada não permite profissão regulamentada.
const doctorIndex=run('DB.jobs.findIndex(j=>j[0]==="Médico")');
run("S.age=30; S.education.level=3;S.education.major='Engenharia';S.v3.diplomas.push({kind:'Graduação',major:'Engenharia',year:S.year})");
yes(run('v3JobEligibility(v3JobDef(DB.jobs['+doctorIndex+'])).some(x=>x.includes("Medicina"))'),'Medicina aceitou diploma errado');
const noJob=run('S.job');run(`applyJob(${doctorIndex})`);same(run('S.job'),noJob,'Contratação sem diploma específico');
// Ações anuais de estudo/trabalho são limitadas.
run("S.stats.energy=100;S.actionsUsed=0;S.cash=50000;S.job={name:'Atendente',sector:'Básico',salary:36000,level:1,years:0};v3UpgradeJob(S.job)");
run("action('overtime');");const c1=run('S.cash');const a1=run('S.stats.energy');run("action('overtime')");same(run('S.cash'),c1,'Hora extra duplicada');same(run('S.stats.energy'),a1,'Hora extra bloqueada gastou energia');
run("S.workQuality=95;S.stats.discipline=95;action('promotion')");same(run('S.job.level'),1,'Promoção instantânea sem experiência');
run('S.stats.energy=100;S.actionsUsed=0;S.cash=300000;v3BeforeYear();S.year++;S.age++;S.stats.energy=100;S.actionsUsed=0;S.job.years=4;S.job.lastPromotionYear=S.year-4;v3AnnualNPCs();delete S.v3._before;');
yes(run('S.parents[0].age')>0,'NPC não possui idade');
// Imóveis têm despesas, vacância e conservação.
run("S.homes.push({name:'Studio de teste',value:250000,rent:1900,rented:false,id:'home-test'});v3Home(S.homes[0])");
const cashBeforeRepair=run('S.cash');run("v3HomeAction(0,'reformar')");yes(run('S.cash')<cashBeforeRepair,'Reforma gratuita inesperada');
const spend=run('S.cash');run("v3HomeAction(0,'reformar')");same(run('S.cash'),spend,'Reforma repetida no mesmo ano não foi bloqueada');
// Saúde: condições persistem e tratamento não garante cura.
run("S.v3.conditions.push({id:'med_5',year:S.year,status:'active',severity:6,treatmentLevel:0});S.cash=80000;S.stats.energy=100;S.actionsUsed=0");
run('v3Treat(0)');yes(run('S.v3.conditions[0].treatmentLevel')>=1,'Tratamento não registrado');
// Eventos contextuais geram história, alguns têm consequência atrasada.
run('S.v3.events={};S.v3.seed=123456789;v3ChooseEvent()');yes(!!run('currentModal?.title'),'Evento não abriu');
run('currentModal.choices[0].action();closeModal();save()');yes(run('S.v3.eventLog.length')>=1,'Evento não persistiu');
const backup=run('JSON.stringify(S)');run('S=null;importBackup('+JSON.stringify(backup)+')');same(run('S.v3.version'),3);yes(run('S.v3.limits')!==null,'Limites se perderam após importação');
// Migrar backup 2.0 sem campos 3.0 preserva o motor e o progresso.
run('let old=JSON.parse(JSON.stringify(S));delete old.v3;importBackup(JSON.stringify(old));closeModal()');same(run('S.v3.version'),3);
// Carreiras especiais: projetos persistentes, custos, cooldown e conclusão em anos diferentes.
run("makeLife({name:'Bia',mode:'god',startAdult:true,gender:'F'});S.age=23;S.cash=250000;S.stats.energy=100;S.stats.discipline=85;S.skills['Tecnologia']=85;S.skills['Música']=85;S.skills['Ciências']=85;S.education.level=2;S.job={name:'Pesquisador',sector:'Ciências',salary:50000,years:2,level:1};v3UpgradeJob(S.job);closeModal()");
const projectStartCash=run('S.cash');run("action('v3Special','jogos|prototipo');closeModal()");
same(run('S.v3.special.jogos.projects.length'),1,'Estúdio não criou protótipo persistente');yes(run('S.cash')<projectStartCash,'Projeto sem custo');
const projectCash=run('S.cash');run("action('v3Special','jogos|prototipo');closeModal()");same(run('S.cash'),projectCash,'Protótipo duplicado no mesmo ano');
const firstProject=run('S.v3.special.jogos.projects[0].title');run('save();S=null;restore();closeModal()');same(run('S.v3.special.jogos.projects[0].title'),firstProject,'Projeto se perdeu após reinício');
let advancements=0;while(run('S.year < S.v3.special.jogos.projects[0].due')&&advancements<5){run('ageOneYear();closeModal()');advancements++;}
yes(advancements>=1,'Projeto não deveria ser concluído imediatamente');
run('S.cash=Math.max(S.cash,35000);S.stats.energy=100;S.actionsUsed=0');run("action('v3Special','jogos|lancar');closeModal()");
same(run('S.v3.special.jogos.released.length'),1,'Jogo pronto não foi lançado');same(run('S.v3.special.jogos.projects.length'),0,'Projeto finalizado continuou pendente');
const launchedCash=run('S.cash');run("action('v3Special','jogos|lancar');closeModal()");same(run('S.cash'),launchedCash,'Mesmo jogo lançado duas vezes');
run('S.stats.energy=100;S.actionsUsed=0');run("action('v3Special','musica|single');closeModal()");
same(run('S.v3.special.musica.released.length'),1,'Música não foi produzida');
run('S.stats.energy=100;S.actionsUsed=0');run("action('v3Special','ciencia|pesquisa');closeModal()");
same(run('S.v3.special.ciencia.projects.length'),1,'Pesquisa científica não foi iniciada');
const doBefore=run('S.v3.special.musica.released[0].lastPaid');run('ageOneYear();closeModal()');
yes(run('S.v3.special.musica.released[0].lastPaid')>doBefore,'Royalties não processados ao envelhecer');
const paidOnce=run('S.v3.special.musica.revenue');run('v3SpecialAnnual()');same(run('S.v3.special.musica.revenue'),paidOnce,'Royalties pagos duas vezes no mesmo ano');
// Simular múltiplas vidas e décadas, registrando ausência de números inválidos.
let years=0,lifeCount=0;
for(let life=0;life<5;life++){
 run(`makeLife({name:'Simulacao',mode:'normal',startAdult:false,gender:'F'});closeModal()`);
 for(let yr=0;yr<112;yr++){
  if(!run('S.alive'))break;
  run('ageOneYear();closeModal()');years++;
  const data=run('({age:S.age,cash:S.cash,debt:S.debt,worth:netWorth(S),year:S.year,health:S.stats.health,npcs:[...S.parents,...S.friends,...S.children].map(p=>p.age)})');
  yes(data.age>=0&&data.age<=113,'Idade inválida');yes(Number.isFinite(data.cash)&&data.cash>=0,'Dinheiro inválido');yes(Number.isFinite(data.debt)&&data.debt>=0,'Dívida inválida');yes(Number.isFinite(data.worth),'Patrimônio inválido');yes(data.npcs.every(a=>a>=0&&a<150),'Idade de NPC inválida');
 }
 lifeCount++;
}
yes(years>=200,'Simulação prolongada insuficiente');
console.log('VIDAVERSO 3.0 TESTES OK',JSON.stringify({counts,years,lifeCount,schemav3:run('S.v3.version')}));
