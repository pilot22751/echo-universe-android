/* Teste de regressão do jogo offline. Executar: node tests/smoke.js */
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('node:assert/strict');
const root=path.join(__dirname,'../app/src/main/assets');
const fakeStorage=new Map();
const dom={};function el(id){return dom[id]||(dom[id]={innerHTML:'',value:'',textContent:'',classList:{add(){},remove(){},toggle(){},contains(){return false}}});}
const context=vm.createContext({
 console,setTimeout(){return 0},clearTimeout(){},
 localStorage:{getItem:k=>fakeStorage.get(k)||null,setItem:(k,v)=>fakeStorage.set(k,v),removeItem:k=>fakeStorage.delete(k)},
 document:{getElementById:el,documentElement:{classList:{toggle(){},contains(){return false}}},addEventListener(){},execCommand(){return true}},
 window:{addEventListener(){},scrollTo(){}},
});
for(const f of ['data.js','events.js','game.js','expansion.js','content2.js','universe.js','ui.js'])vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),context,{filename:f});
const run=s=>vm.runInContext(s,context);
const stats=run('({jobs:DB.jobs.length,events:EV.length+V2_EVENT_PACK.length,sagas:V2_ARCS.length,medals:DB.challenges.length,countries:DB.countries.length})');
assert(stats.jobs>=170&&stats.events>=210&&stats.sagas>=25&&stats.medals>=100&&stats.countries>=25,JSON.stringify(stats));
run("makeLife({name:'Alice',gender:'F',startAdult:true,mode:'god',aspiration:'ciencia'});closeModal()");
assert.equal(run('S.v2.version'),2);assert.equal(run('S.v2.aspiration'),'ciencia');assert.equal(run('S.year'),2026);
for(const section of ['visao','sagas','carreira','economia','negocios','pessoas','identidade','habitos','cronicas','diario']){
 run(`go('universo','${section}')`);const html=el('app').innerHTML;assert(html.includes('VIDAVERSO 2.0'),section);assert(html.length>500,section);
}
run("S.cash=1200000;v2Act('v2StartSaga','startup');v2Act('v2SagaStep');currentModal.choices[0].action();closeModal()");
assert.equal(run('S.v2.saga.step'),1);
run("ageOneYear();closeModal();v2Act('v2SagaStep');currentModal.choices[0].action();closeModal();ageOneYear();closeModal();v2Act('v2SagaStep');currentModal.choices[0].action();closeModal()");
assert(run("S.v2.completedSagas.includes('startup')"),'Saga não concluída');
run('startBusiness(0);closeModal();go("universo","negocios")');assert.equal(run('S.businesses.length'),1);
run("v2Act('v2BizAction','0|marketing');v2Act('v2BizAction','0|qualidade')");
const trustBefore=run('S.parents[0].trust');run("v2Act('v2Relationship', S.parents[0].id+'|talk')");assert(run('S.parents[0].trust')>=trustBefore);
for(let i=0;i<30;i++){run('ageOneYear();closeModal()');}
const result=run('({age:S.age,worth:netWorth(S),y:S.v2.yearHistory.length,world:S.v2.world.phase,ach:S.achievements.length})');
assert.equal(result.age,50);assert.equal(result.y,32);assert(Number.isFinite(result.worth));
const backup=run('JSON.stringify(S)');assert(backup.includes('"v2"'));
run('S.v2=null;importBackup('+JSON.stringify(backup)+');closeModal()');assert.equal(run('S.v2.version'),2);
run('let oldS=JSON.parse(JSON.stringify(S));delete oldS.v2;importBackup(JSON.stringify(oldS));closeModal()');assert.equal(run('S.v2.version'),2);
console.log('VIDAVERSO 2.0 smoke OK',JSON.stringify({...stats,result}));
