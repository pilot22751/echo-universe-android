'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'../app/src/main/assets'),storage=new Map(),nodes={};
function el(id){return nodes[id]||(nodes[id]={value:'',innerHTML:'',textContent:'',checked:false,classList:{add(){},remove(){},toggle(){},contains(){return false}},append(){},select(){},setSelectionRange(){}});}
const ctx=vm.createContext({console,Date,Math,setTimeout(){return 0},clearTimeout(){},Intl,localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},document:{getElementById:el,querySelector(){return null},documentElement:{classList:{toggle(){},contains(){return false}}},addEventListener(){},execCommand(){return true},body:{append(){}}},window:{addEventListener(){},scrollTo(){}},Blob,URL:{createObjectURL(){return 'blob://test';},revokeObjectURL(){}}});
const modules=['data.js','events.js','game.js','expansion.js','content2.js','universe.js','ui.js','v3-data.js','v3-engine.js','v3-events.js','v3-ui.js','v3-special.js','v3-hooks.js','v4-data.js','v4-engine.js','v4-ui.js','v4-hooks.js','v5-coverage.js','v5-engine.js','v5-ui.js','v5-hooks.js','v5-extras.js','v5-extras-ui.js'];
for(const f of modules)vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),ctx,{filename:f});
const run=s=>vm.runInContext(s,ctx),ok=(v,msg)=>assert(v,msg),eq=(a,b,msg)=>assert.equal(a,b,msg);
run("makeLife({name:'Ana',country:'Brasil',mode:'god',startAdult:true});closeModal();S.cash=2000000;save()");
eq(run('S.v5.schema'),5);eq(run('V5_REQUIREMENTS.length'),400);const coverage=run('V5_REQUIREMENTS.map(x=>x.id)');eq(new Set(coverage).size,400);
// Transfer conservation and migration
let worth=run('netWorth(S)');ok(run("v5FinanceMove('deposit',100000)"),'deposit');eq(run('S.v5.finance.savings'),100000);eq(run('S.cash'),1900000);eq(run('netWorth(S)'),worth);
ok(run("v5FinanceMove('withdraw',25000)"));eq(run('S.v5.finance.savings'),75000);eq(run('netWorth(S)'),worth);
ok(run("v5FinanceMove('checking',5000)"));ok(run("v5FinanceMove('cashout',3000)"));eq(run('netWorth(S)'),worth);
run('save();S=null;restore()');eq(run('S.v5.finance.savings'),75000);eq(run('S.v5.schema'),5);
// Interest and idempotence
const y=run('S.year');run('ageOneYear();closeModal()');ok(run('S.v5.finance.savings')>75000,'savings did not yield');const bankAfter=run('S.v5.finance.savings');run('v5AfterYear()');eq(run('S.v5.finance.savings'),bankAfter,'annual finance charged twice');eq(run('S.v5.processedYear'),y+1);
// Loans and assets: borrowing adds equal cash/liability except fee
run('S.cash=2000000;S.v5.finance.score=750');const before=run('netWorth(S)');ok(run('v5CreditLoan(12000,4)'),'loan rejected unexpectedly');ok(run('S.v5.finance.loans[0].balance===12000'),'loan balance missing');ok(run('netWorth(S)')<=before&&run('netWorth(S)')>before-300,'borrowed funds created wealth');
const loanBalance=run('S.v5.finance.loans[0].balance');run("v5RepayLoan(S.v5.finance.loans[0].id,2000)");eq(run('S.v5.finance.loans[0].balance'),loanBalance-2000);
// Card credit and annual interests
run('S.v5.finance.card.limit=30000');const cashBefore=run('S.cash');ok(run("v5CardBuy('curso')"));eq(run('S.cash'),cashBefore,'Credit card purchase wrongly used cash');ok(run('S.v5.finance.card.balance>0'));run('v5CardPayment(900)');ok(run('S.v5.finance.card.balance>=0'));run('save();S=null;restore()');ok(run('S.v5.finance.card.limit>=5000'),'Card not saved');
// Documents and travel: can't travel without passport, visa approval uses social profile
run('S.v5.travel.passport=null');const historyBefore=run('S.v5.travel.visits.length');run("v5Travel('Japão')");eq(run('S.v5.travel.visits.length'),historyBefore);ok(run('v5Passport()'),'passport failed');run("S.v5.travel.visas.push({country:'Japão',issued:S.year,expires:S.year+5})");ok(run("v5Travel('Japão')"),'travel with passport and authorization failed');
run('S.stats.reputation=95;S.stats.intel=95;S.cash=1000000');ok(run("v5Visa('Estados Unidos')")||run('S.v5.travel.visas.length>=0'),'visa logic crashed');
run("S.v5.travel.visas.push({country:'Estados Unidos',issued:S.year,expires:S.year+5})");ok(run("v5Immigrate('Estados Unidos','Detroit (Michigan)')"),'legal migration failed');eq(run('S.country'),'Estados Unidos');eq(run('S.v5.travel.residence'),'Estados Unidos');run('save();S=null;restore()');eq(run('S.country'),'Estados Unidos');
// No money should appear for bank transfers and personal loans; identity stable
run('S.age=25;S.cash=200000;v3Init()');const friendId=run('S.parents[0].id');ok(run('v5SocialLoan('+JSON.stringify(friendId)+',1500)'),'social lending failed');const social=run('S.v5.social.loans[0]');eq(social.balance,1500);run('save();S=null;restore()');eq(run('S.v5.social.loans[0].balance'),1500);const previousCount=run('S.v5.social.loans.length');run('v5SocialLoan('+JSON.stringify(friendId)+',1500)');eq(run('S.v5.social.loans.length'),previousCount,'repeated lending allowed same year');
// Education: exam limited per year, club has real effects and saves
run('S.age=16;S.stats.energy=100;S.actionsUsed=0');const score=run('v5EntranceExam()');ok(Number.isFinite(score),'exam failed');const examCount=run('S.v5.school.entrance.length');run('v5EntranceExam()');eq(run('S.v5.school.entrance.length'),examCount);
run('S.cash=20000;S.stats.energy=100;S.actionsUsed=0');ok(run("v5SchoolClub('robotica')"),'club failed');const clubCount=run('S.v5.school.clubs.length');run("v5SchoolClub('robotica')");eq(run('S.v5.school.clubs.length'),clubCount);
// Interview gated by degree (no physician shortcut), hire persists
run('S.age=28;S.education.level=0');const doctor=run('DB.jobs.findIndex(j=>j[0]==="Médico clínico")');if(doctor>=0){const n=run('S.v5.interviews.length');run("v5MeetInterview("+doctor+",'competencia')");eq(run('S.v5.interviews.length'),n,'unqualified physician interview happened');}
const general=run('DB.jobs.findIndex(j=>j[2]<=18&&j[3]===0)');ok(general>=0,'no entry position');run("S.stats.energy=100;S.actionsUsed=0;S.skills['Comunicação']=95;S.stats.discipline=95;");run('v5MeetInterview('+general+',"competencia")');ok(run('S.v5.interviews.length')>=1,'interview not saved');
// Asset production: inventory purchased and annual sales, no free stock
run('S.age=35;S.cash=1000000;S.stats.energy=100;S.actionsUsed=0');run("S.businesses.push({id:'b5',name:'Loja da Ana',revenue:90000,margin:.17,staff:3,value:100000,sector:'Comércio'})");
const stockBefore=run('S.cash');ok(run('v5BusinessPurchase(S.businesses.length-1,3500)'),'inventory purchase failed');ok(run('S.cash')<stockBefore,'inventory was free');const goods=run('S.businesses.at(-1).v5.stock');run('ageOneYear();closeModal()');ok(run('S.businesses.at(-1).v5.stock')<=goods,'inventory increased for free');
// Fictional legal system: opening a case generates delayed adjudication; counsel is costly
run('S.age=30;S.cash=1000000;S.stats.energy=100;S.actionsUsed=0');
ok(run("v5OpenCase('disputa')"),'civil case failed');const case0=run('S.v5.legal.cases[0].id');eq(run('S.v5.legal.cases[0].status'),'petição');
const defenseCash=run('S.cash');ok(run('v5HireCounsel('+JSON.stringify(case0)+',"basico")'),'defense failed');ok(run('S.cash')<defenseCash,'counsel was free');
const caseDup=run('S.v5.legal.cases.length');run("v5OpenCase('fraude')");eq(run('S.v5.legal.cases.length'),caseDup,'cases unlimited in a year');
run('ageOneYear();closeModal()');eq(run('S.v5.legal.cases[0].status'),'encerrado','case not resolved after one year');run('save();S=null;restore()');ok(run('S.v5.legal.cases[0].verdict'),'case verdict not persistent');
// Creator career: actual channel, limited publishing, follower count, sponsor gates
run('S.age=30;S.cash=1000000;S.stats.energy=100;S.actionsUsed=0');ok(run("v5CreateChannel('video')"),'channel creation failed');ok(run("v5ChannelPost('video','vídeo')"),'publishing failed');const posts0=run('S.v5.channels.posts.length');
run("v5ChannelPost('video','vídeo')");run("v5ChannelPost('video','vídeo')");eq(run('S.v5.channels.posts.length'),posts0+1,'channel posting farm');
run('save();S=null;restore()');ok(run('S.v5.channels.accounts.some(a=>a.id==="video")'),'channel not restored');
// All new deep UI routes render; no action button without a handler
for(const [t,s] of [['bens','v5banco'],['mundo','v5viagens'],['estudos','v5escola'],['trabalho','v5entrevistas'],['relacoes','v5familia'],['bens','v5negocios'],['universo','v5auditoria'],['mundo','v5justica'],['universo','v5redes']]){run(`go(${JSON.stringify(t)},${JSON.stringify(s)})`);ok(el('app').innerHTML.length>600,'page failed: '+s);ok(el('app').innerHTML.includes('5.0'),'v5 page absent: '+s);}
// 50 years on five continents, finance invariant, ability to load/save each stage
let years=0;for(const country of ['Brasil','Japão','Canadá','Austrália','França']){run('makeLife({name:"Stress5",country:'+JSON.stringify(country)+',startAdult:true});closeModal()');for(let n=0;n<42;n++){if(!run('S.alive'))break;run('ageOneYear();closeModal()');const snap=run('({cash:S.cash,debt:S.debt,savings:S.v5.finance.savings,checking:S.v5.finance.checking,score:S.v5.finance.score,worth:netWorth(S),processed:S.v5.processedYear,year:S.year})');ok(Number.isFinite(snap.cash)&&snap.cash>=0&&snap.debt>=0&&snap.savings>=0&&snap.checking>=0&&Number.isFinite(snap.worth)&&snap.score>=300&&snap.score<=900&&snap.processed===snap.year,'invalid annual finance '+country);years++;if(n%15===0){run('save();S=null;restore()');ok(run('S.v5.schema')===5,'save migration failed');}}}
ok(years>=170,'not enough multiyear coverage');
console.log('VIDAVERSO 5.0 REGRESSION OK',JSON.stringify({requirements:coverage.length,years,modules:modules.length,coverageStatuses:run('V5_REQUIREMENTS.reduce((a,x)=>(a[x.status]=(a[x.status]||0)+1,a),{})')}));
