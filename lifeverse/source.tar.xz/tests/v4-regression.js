/* Regression 4.0: runs all features offline with deterministic local storage. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'../app/src/main/assets'),storage=new Map(),nodes={};
function el(id){return nodes[id]||(nodes[id]={value:'',innerHTML:'',textContent:'',checked:false,classList:{add(){},remove(){},toggle(){},contains(){return false}},append(){},select(){},setSelectionRange(){}});}
const ctx=vm.createContext({console,Date,Math,setTimeout(){return 0},clearTimeout(){},
 localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},
 document:{getElementById:el,querySelector(){return null},documentElement:{classList:{toggle(){},contains(){return false}}},addEventListener(){},execCommand(){return true},body:{append(){}}},
 window:{addEventListener(){},scrollTo(){}},Blob,URL:{createObjectURL(){return 'blob://test';},revokeObjectURL(){}}
});
const modules=['data.js','events.js','game.js','expansion.js','content2.js','universe.js','ui.js','v3-data.js','v3-engine.js','v3-events.js','v3-ui.js','v3-special.js','v3-hooks.js','v4-data.js','v4-engine.js','v4-ui.js','v4-hooks.js'];
for(const file of modules)vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),ctx,{filename:file});
function run(src){return vm.runInContext(src,ctx)};function same(a,b,msg){assert.equal(a,b,msg)};function truth(x,msg){assert(x,msg)};
const catalog=run('({countries:V4_COUNTRY_LINES.length,cities:V4_COUNTRY_LINES.reduce((n,c)=>n+c.cities.length,0),jobs:DB.jobs.length,degrees:DB.degrees.length,models:V4_VEHICLE_CATALOG.length,perCity:v4Listings("Brasil","São Paulo").length,allBrazil:v4Listings("Brasil").length})');
truth(catalog.countries>=50,'Minimum 50 countries required');truth(catalog.cities>=200,'World must contain cities');truth(catalog.perCity>=60&&catalog.allBrazil>=300,'Hundreds of listings per country');truth(catalog.jobs>291,'New local jobs missing');truth(catalog.degrees>=90,'Education catalog decreased');
// Born in a republic: reject royal mode, allow monarchy.
nodes.newCountry=el('newCountry');nodes.newMode=el('newMode');nodes.newName=el('newName');nodes.newGender=el('newGender');
el('newCountry').value='Brasil';el('newMode').value='royal';el('newName').value='Tester';el('newGender').value='F';run("action('newLife')");same(run('S'),null,'Royal start should be blocked in Brazil');
run("makeLife({name:'Yuki',country:'Japão',mode:'royal',startAdult:true});closeModal()");truth(run('S.royal'),'Royal not enabled in Japan');same(run('S.v4.version'),4);truth(run('S.v4.countryEvents.length===0'),'Unexpected event');
run("makeLife({name:'Bea',country:'Brasil',mode:'royal',startAdult:true});closeModal()");same(run('S.royal'),false,'Direct royal API bypassed Brazil restriction');
// Legacy save migration and output currency.
run("makeLife({name:'Bea',country:'Brasil',mode:'god',startAdult:true});closeModal();S.cash=1000000;save();");same(run('v4Country().currency'),'BRL');truth(run('money(50000).includes("R$")'),'Brazil currency UI incorrect');
const originalCredit=run('S.cash');const originalWorth=run('netWorth(S)');
truth(run("v4Move('Estados Unidos','Detroit (Michigan)')"),'Immigration failed');same(run('S.country'),'Estados Unidos');same(run('v4Country().currency'),'USD');truth(run('money(S.cash).includes("$")'),'Dollar UI is missing');truth(run('S.v4.fxHistory.length===1'),'FX record missing');truth(run('S.cash') < originalCredit && run('S.cash')>originalCredit-30000,'Migration cost invalid');
truth(run('S.v4.fxHistory[0].before!==S.v4.fxHistory[0].after'),'Conversion did not change currency amount');
const actualWorth=run('netWorth(S)');truth(actualWorth<originalWorth,'Migration had no cost');
// Shop offers differ between cities and countries, consistent hashes after render.
const michigan=run('v4Listings("Estados Unidos","Detroit (Michigan)").find(x=>x.type==="Casa de família" && x.variant===1)');
const la=run('v4Listings("Estados Unidos","Los Angeles").find(x=>x.type==="Casa de família" && x.variant===1)');truth(michigan.price<la.price,'LA real estate should be pricier in the simulation');
same(run('v4PropertyById('+JSON.stringify(michigan.id)+').price'),michigan.price,'Offers must be stable within year');
// Buy and finance with down payment, persist through reload.
run('S.cash=20000000;S.stats.energy=100;S.actionsUsed=0');const moneyBefore=run('S.cash');const homesBefore=run('S.homes.length');
truth(run('v4BuyProperty('+JSON.stringify(michigan.id)+',true)'),'Financed house purchase failed');same(run('S.homes.length'),homesBefore+1);truth(run('S.cash')<moneyBefore,'Home did not charge deposit');truth(run('S.debt')>0,'Mortgage did not create a debt');const debtBefore=run('S.debt');run('save();S=null;restore()');same(run('S.v4.version'),4);same(run('S.homes.length'),homesBefore+1);same(run('S.v4.mortgages.length'),1);
// Rent a place with deposit and rent due once yearly.
run('S.stats.energy=100;S.actionsUsed=0');const studio=run('v4Listings("Estados Unidos","Detroit (Michigan)").find(x=>x.type==="Studio")');
truth(run('v4RentProperty('+JSON.stringify(studio.id)+')'),'Could not rent property');same(run('S.v4.rental.name'),studio.name);const rentalYear=run('S.year');run('ageOneYear();closeModal()');truth(run('S.v4.rental.lastPaidYear')===rentalYear+1,'Rent not billed annually');truth(run('S.v4.mortgages.length===0||S.v4.mortgages[0].balance<= '+debtBefore),'Mortgage principal did not change');
// Vehicles change money and persist, no decorative action.
run('S.stats.energy=100;S.actionsUsed=0');const carBefore=run('S.vehicles.length');const cashBeforeCar=run('S.cash');run('v4BuyVehicle(2)');same(run('S.vehicles.length'),carBefore+1,'Vehicle missing');truth(run('S.cash')<cashBeforeCar,'Vehicle was free');
// Local professional restrictions: Mangaka Japan only.
const mangakaIdx=run('DB.jobs.findIndex(j=>j[0]==="Mangaká")');truth(mangakaIdx>=0,'Mangaka missing');truth(run('v3JobEligibility(v3JobDef(DB.jobs['+mangakaIdx+'])).some(s=>s.includes("Japão"))'),'Mangaka should be region-restricted');
run('S.country="Japão";S.city="Tóquio";save()');truth(!run('v3JobEligibility(v3JobDef(DB.jobs['+mangakaIdx+'])).some(s=>s.includes("Japão"))'),'Mangaka job still region restricted in Japan');
run('S.education.level=0');run("enroll('Graduação|Manga e Ilustração Japonesa')"); // Education details may reject age or funds; validate country-specific block separately.
run('S.country="Brasil";S.city="São Paulo"');const majorBefore=run('S.education.major');run("enroll('Graduação|Manga e Ilustração Japonesa')");same(run('S.education.major'),majorBefore,'Specialized degree entered outside Japan');
// Casino five per year; settlement really moves funds.
run('S.age=27;S.cash=1000000;S.stats.energy=100;S.actionsUsed=0');const bank=run('S.cash');run("v4CasinoStart('roulette','vermelho',100)");truth(run('S.v4.casino.games')===1,'Casino game missing');truth(run('S.cash')!==bank||run('S.v4.casino.history[0].payout')===100,'No casino settlement');
run("v4CasinoStart('slots','spin',100)");truth(run('S.v4.casino.games')===2,'Slots game missing');
run("v4CasinoStart('blackjack','start',100)");truth(run('S.v4.casino.round?.player.length')===2,'Blackjack should give 2 cards');run("v4BlackjackAction('stand')");same(run('S.v4.casino.round'),null,'Blackjack round did not end');
const gameCount=run('S.v4.casino.games');run('save();S=null;restore()');same(run('S.v4.casino.games'),gameCount,'Casino save did not persist');
// Nightlife displays concrete film title and limits annual gains.
run('S.stats.energy=100;S.actionsUsed=0;S.age=28');run("v4NightOut('Cinema','')");truth(run('S.v4.filmDiary.length===1'),'Movie diary missing');truth(run('V4_MEDIA[S.country].includes(S.v4.filmDiary[0].title)'),'Fictional fake movie was logged');const films=run('S.v4.filmDiary.length');run("v4NightOut('Cinema','')");same(run('S.v4.filmDiary.length'),films,'Cinema farm was not blocked');
// Mature romance checks adulthood and consent without graphic content.
run('S.age=15;S.stats.energy=100;S.actionsUsed=0;S.partner={name:"Alex",bond:70,alive:true,age:20}');run("v4RomanceAction('intimidade')");same(run('S.v4.relationshipDiary.length'),0,'Minors must not have adult intimacy');
run('S.age=28;v3Init()');run("v4RomanceAction('intimidade')");same(run('S.v4.relationshipDiary.length'),1,'Adult relationship entry should be persistent');
// UI subpages load and render safely.
for(const [tab,section] of [['bens','v4mercado'],['bens','v4aluguel'],['bens','v4veiculos'],['mundo','v4pais'],['mundo','v4cassino'],['mundo','v4noite'],['mundo','v4identidade'],['universo','v4auditoria']]){
 run('go('+JSON.stringify(tab)+','+JSON.stringify(section)+')');truth(el('app').innerHTML.length>650,'View was too short: '+section);truth(el('app').innerHTML.includes('4.0'),'View did not show v4 UI: '+section);
}
// Annual simulations in distinct countries are stable.
let years=0;for(const name of ['Brasil','Japão','Canadá','Estados Unidos','França']){run('makeLife({name:"StressTest",country:'+JSON.stringify(name)+',mode:"normal",startAdult:true});closeModal()');for(let i=0;i<45;i++){if(!run('S.alive'))break;run('ageOneYear();closeModal()');const x=run('({age:S.age,cash:S.cash,debt:S.debt,worth:netWorth(S),year:S.year})');truth(Number.isFinite(x.cash)&&x.cash>=0&&Number.isFinite(x.debt)&&x.debt>=0&&Number.isFinite(x.worth)&&x.age<115,'Invalid annual state for '+name);years++;}}
truth(years>=140,'Long simulation coverage insufficient');
console.log('VIDAVERSO 4.0 REGRESSION OK',JSON.stringify({catalog,years,modules:modules.length}));
