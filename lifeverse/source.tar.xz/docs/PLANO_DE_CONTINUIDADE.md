# Continuidade depois da versão 5.0 — itens ainda não concluídos

**Fonte:** os 400 requisitos do usuário. Não declarar concluído por existir somente um botão.

1. **Modelo/arquitetura** — separar regras em APIs internas com contratos validados, registrar transações por lançamento duplo em todos os sistemas, consolidar save versionado e migrações testáveis para mais de uma geração.
2. **Pessoas/família** — árvore de parentesco estável, adoção/tutela, coabitação, disputa de guarda, netos, heranças e interações entre NPCs sem jogador.
3. **Mundo/localização** — dados configuráveis por país de direito, idade, trabalho, previdência, escola e residência, sem tratá-los como leis reais. Cidades com crises e economias regionais ligadas ao mercado de trabalho.
4. **Educação** — calendário, instituições, disciplinas, vestibulares com múltiplas tentativas, bolsas condicionais, financiamento e profissões regulamentadas.
5. **Carreiras especiais** — aprofundar individualmente: atletas por modalidade, cantor/banda com discografia, ator/diretor com filmografia, magistratura, espionagem fictícia, forças armadas, política, astronauta, chef, diplomata, game developer, moda e e-sports.
6. **Empresas/finanças** — separar caixa empresarial do pessoal, lotes/estoque/custos, equipe com NPCs persistentes, múltiplos produtos, balanços, concorrência, crédito, investidores e sucessão.
7. **Saúde** — condições com diagnósticos, sintomas, clínica/seguradora, procedimentos, tratamento e limitações de idade/país. Evitar estigmatização.
8. **Justiça** — provas abstratas, fase de investigação, defensores NPCs, recursos, diferentes regimes de cumprimento de pena, responsabilidade civil e reintegração.
9. **Vida cotidiana** — mais atividades e dilemas situados no contexto, sem manipulação infinita de atributos.
10. **Teste e polimento** — campanhas completas de 100+ anos em múltiplas gerações, teste de reinstalação e backup em celulares físicos, auditoria de UX e análise de cobertura item a item.

Cada próxima versão deve escolher um conjunto de requisitos, implementar de verdade, adicionar testes e atualizar a matriz CSV. Requisitos não verificados não devem ser promovidos a "implementados".
