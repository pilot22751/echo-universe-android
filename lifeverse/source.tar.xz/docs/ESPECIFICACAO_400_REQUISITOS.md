# PROJETO LIFE SIMULATOR — VERSÃO 4.0 DEFINITIVA

## MISSÃO PRINCIPAL

Você é um desenvolvedor sênior de jogos, arquiteto de software, game designer, especialista em simulação social, economia, inteligência artificial e interfaces interativas.

Estamos desenvolvendo um simulador de vida baseado em escolhas, inspirado na profundidade de BitLife, mas com identidade própria e mecânicas mais avançadas.

**O objetivo não é criar outro protótipo. É evoluir o jogo existente até que ele ofereça uma experiência de simulação de vida ampla, profunda, variada, persistente e realmente jogável.**

O jogador deve poder nascer, crescer, estudar, trabalhar, empreender, enriquecer, falir, namorar, casar, constituir família, cometer crimes, viajar, mudar de país, alcançar a fama, administrar bens, envelhecer e morrer.

O principal diferencial será a imersão: centenas de possibilidades, milhares de combinações e consequências acumuladas ao longo de gerações.

### REGRAS INEGOCIÁVEIS

- Não reescreva o projeto inteiro sem necessidade.
- Não remova funcionalidades existentes.
- Não utilize botões decorativos ou ações que não funcionem.
- Não crie opções que apenas exibam textos sem afetar a simulação.
- Não transforme sistemas complexos em números aleatórios sem lógica.
- Não utilize valores financeiros iguais em todos os países.
- Não permita dinheiro, objetos ou relacionamentos surgirem sem uma origem.
- Não ignore idade, legislação, localização, saúde ou histórico dos personagens.
- Não gere os mesmos eventos em todas as vidas.
- Não afirme ter implementado funcionalidades que ainda não estejam funcionando.
- Não replique textos, interface, logotipo ou recursos protegidos de outros jogos. Reproduza a profundidade das mecânicas com conteúdo e identidade originais.
- Todos os recursos de jogabilidade, inclusive equivalentes aos recursos premium do BitLife, devem estar disponíveis gratuitamente, sem compras reais, anúncios obrigatórios ou bloqueios artificiais.

Se algum sistema já estiver presente, audite, corrija e aprofunde esse sistema. Não o duplique.

Os 400 requisitos abaixo são especificações obrigatórias para orientar o desenvolvimento da versão 4.0.

---

# PARTE 1 — MOTOR PRINCIPAL E ARQUITETURA

### 001. Preservação do projeto existente
Antes de modificar qualquer arquivo, analise a estrutura completa do jogo, suas dependências, seus sistemas e seus dados salvos. Identifique o que já funciona e preserve tudo que for compatível.

### 002. Arquitetura modular
Separe os sistemas de personagem, mundo, carreira, educação, relacionamento, patrimônio, crime, saúde, economia, eventos, interface e salvamento. Cada módulo deve poder evoluir sem comprometer os demais.

### 003. Estado centralizado do personagem
Crie uma fonte única de verdade que armazene todos os dados do personagem. Nenhuma tela deve manter um valor financeiro, familiar ou profissional independente do estado principal.

### 004. Persistência integral
Todas as escolhas importantes devem sobreviver a atualizações, recarregamentos e fechamento do jogo. Isso inclui patrimônio, familiares, dívidas, processos, profissões, amizades e eventos pendentes.

### 005. Sistema de eventos orientado por condições
Cada evento deve possuir pré-requisitos, probabilidades, opções, efeitos e consequências futuras. Uma demissão, por exemplo, precisa considerar desempenho, comportamento, mercado e histórico profissional.

### 006. Motor de consequências
Toda decisão relevante deve poder afetar múltiplos sistemas.

6.1. Uma traição pode gerar divórcio, perda financeira e conflitos familiares.

6.2. Um crime pode gerar prisão, antecedentes e dificuldades profissionais.

6.3. Um investimento pode modificar patrimônio, renda passiva e oportunidades futuras.

### 007. Sistema de probabilidades ponderadas
Não utilize aleatoriedade pura para todas as situações. Calcule resultados considerando estatísticas, idade, contexto social, recursos, histórico, esforço e sorte.

### 008. Controle de ações anuais
Implemente limites que façam o tempo parecer relevante. Algumas ações podem ser repetidas, mas seus benefícios não devem ser acumulados infinitamente.

### 009. Resolução anual de eventos
Ao avançar um ano, processe os acontecimentos em ordem lógica: salários, despesas, investimentos, mudanças familiares, saúde, evolução profissional, acontecimentos externos e envelhecimento.

### 010. Registro histórico permanente
Mantenha um diário cronológico dos acontecimentos relevantes, com idade, data, local e participantes.

### 011. Identidade persistente dos NPCs
Cada personagem secundário deve possuir identificador único, dados próprios, personalidade, relacionamentos, histórico, profissão e localização.

### 012. Simulação independente dos NPCs
Familiares, amigos, colegas e parceiros devem continuar vivendo mesmo quando o jogador não interage com eles. Eles podem casar, mudar de emprego, envelhecer, enriquecer e morrer.

### 013. Sistema de regras parametrizáveis
Centralize idade mínima, impostos, salários, taxas, probabilidades, limites e fórmulas em configurações editáveis, evitando números espalhados pelo código.

### 014. Economia sem inconsistências
Toda movimentação deve possuir origem e destino. Comprar um carro reduz o saldo e aumenta os ativos; receber salário aumenta o saldo e registra receita.

### 015. Validação de operações
Impeça compras impossíveis, matrículas sem requisitos, relacionamentos inválidos, patrimônio negativo não permitido e ações incompatíveis com o personagem.

### 016. Compatibilidade com salvamentos anteriores
Se o modelo de dados mudar, implemente migração automática, valores padrão e tratamento para campos antigos sem perder o progresso do jogador.

### 017. Aleatoriedade reproduzível
Adicione a possibilidade técnica de usar uma semente aleatória para reproduzir bugs e testar resultados, sem tornar as vidas previsíveis.

### 018. Separação entre lógica e interface
As regras de negócios devem funcionar independentemente da tela. Botões devem chamar serviços existentes, não conter toda a lógica da simulação.

### 019. Otimização de desempenho
Mantenha o sistema eficiente mesmo quando o personagem possuir dezenas de imóveis, empresas, centenas de conhecidos e várias gerações familiares.

### 020. Padrão mínimo de funcionalidade
Uma funcionalidade só estará concluída quando possuir interface, regras, condições, consequências, persistência e testes de funcionamento.

---

# PARTE 2 — CRIAÇÃO DE PERSONAGEM E IDENTIDADE

### 021. Criação de vidas aleatórias
Permita gerar um personagem com nome, sobrenome, país, cidade, sexo, gênero, características físicas, família, condição financeira e circunstâncias de nascimento.

### 022. Criação personalizada
Permita selecionar manualmente características do personagem, incluindo nome, origem, aparência, atributos e talentos, sem cobrar por essas opções.

### 023. Nacionalidades variadas
Inclua países reais de diferentes continentes, com possibilidades de nascimento, imigração, viagens e mudança de residência.

### 024. Cidades reais
Cada país deve conter diversas cidades reais, com diferentes custos de vida, oportunidades, universidades, criminalidade e características econômicas.

### 025. Sistema de regiões
Diferencie estados, províncias, regiões metropolitanas, cidades e bairros quando isso afetar a simulação.

### 026. Nomes culturalmente coerentes
Gere nomes e sobrenomes associados às regiões de nascimento, mantendo variedade e evitando combinações repetitivas.

### 027. Características físicas
Inclua cor dos olhos, cabelo, altura, constituição física, aparência, estilo e outras características relevantes.

### 028. Genética
Filhos biológicos devem herdar características dos pais com variações realistas, sem serem cópias exatas.

### 029. Inteligência
Implemente inteligência como atributo que influencia aprendizado, exames e algumas oportunidades, mas sem determinar sozinho o sucesso.

### 030. Aparência
A aparência deve influenciar determinadas interações sociais e atividades, respeitando os limites de uma simulação equilibrada.

### 031. Saúde inicial
O personagem pode nascer com diferentes condições físicas, predisposições e necessidades de saúde, sem transformar todas as condições em destinos inevitáveis.

### 032. Felicidade
Calcule felicidade considerando acontecimentos, relacionamentos, condições materiais, expectativas e características psicológicas.

### 033. Disciplina
Crie uma característica que influencia dedicação, hábitos, estudos, desempenho profissional e resistência a impulsos.

### 034. Força de vontade
Inclua capacidade de persistência diante de dificuldades, vícios, desafios profissionais e mudanças pessoais.

### 035. Sorte
Crie um modificador de eventos imprevisíveis, sem permitir que ele substitua mérito, recursos e condições concretas.

### 036. Talentos naturais
Personagens podem nascer com aptidão para música, atuação, esportes, comunicação, negócios, ciência e outras áreas.

### 037. Personalidade complexa
Inclua traços como ambição, empatia, sociabilidade, impulsividade, honestidade, coragem, criatividade e estabilidade emocional.

### 038. Orientação sexual
Permita diferentes orientações sexuais e experiências de descoberta pessoal, sem associá-las a penalidades arbitrárias.

### 039. Identidade de gênero
Permita personalização de gênero, identidade e pronome, com tratamento consistente nos textos e relacionamentos.

### 040. História de origem
Gere uma situação inicial única: nascimento em família rica, pobre, classe média, monoparental, adotiva, numerosa, influente ou com outras circunstâncias.

---

# PARTE 3 — TEMPO, IDADE E PROGRESSÃO DA VIDA

### 041. Botão de avançar idade
Mantenha o avanço de um ano como mecanismo central, claramente visível e sempre acessível quando não houver uma decisão pendente.

### 042. Progressão desde o nascimento
O jogo deve iniciar no nascimento, salvo quando houver uma opção específica para começar em outra idade.

### 043. Fases de desenvolvimento
Diferencie bebê, criança, pré-adolescente, adolescente, jovem adulto, adulto, meia-idade e idoso.

### 044. Ações adequadas à idade
Cada fase precisa desbloquear e encerrar atividades. Bebês não procuram emprego; crianças têm escolhas limitadas; adultos possuem responsabilidades financeiras.

### 045. Eventos ao envelhecer
Cada avanço deve gerar acontecimentos plausíveis, sem obrigar a ocorrência de grandes tragédias ou mudanças todos os anos.

### 046. Eventos opcionais durante o ano
O jogador pode executar atividades antes de envelhecer, respeitando disponibilidade, limites e condições do personagem.

### 047. Acontecimentos simultâneos
Um mesmo ano pode envolver casamento, promoção, nascimento de filhos, despesas inesperadas e mudança de residência.

### 048. Mudanças graduais
Atributos devem evoluir progressivamente. Um único treino não torna alguém atleta profissional.

### 049. Efeitos de longo prazo
Decisões tomadas na infância ou adolescência podem influenciar habilidades, oportunidades, relações e hábitos na idade adulta.

### 050. Eventos dependentes do passado
Uma escolha anterior deve poder criar eventos futuros, mesmo depois de muitos anos.

### 051. Datas de acontecimentos
Registre ano de nascimento, casamento, formação, aquisição de bens, falecimentos e outros marcos.

### 052. Expectativa de vida variável
A longevidade deve depender de fatores biológicos, comportamentos, acidentes, ambiente e aleatoriedade.

### 053. Envelhecimento físico
Inclua mudanças na aparência, força, condicionamento, fertilidade e vulnerabilidades associadas à idade.

### 054. Envelhecimento profissional
Algumas carreiras possuem auge precoce, enquanto outras podem se desenvolver até idades avançadas.

### 055. Aposentadoria
Permita aposentadoria voluntária ou compulsória onde fizer sentido, com regras locais e benefícios acumulados.

### 056. Morte natural
Crie um sistema coerente de mortalidade sem estabelecer uma idade obrigatória de falecimento.

### 057. Morte acidental
Acidentes podem ocorrer conforme riscos reais das atividades, localização e circunstâncias.

### 058. Encerramento da vida
Ao morrer, apresente resumo, idade, causa, patrimônio, familiares sobreviventes, conquistas e eventos marcantes.

### 059. Continuação por descendentes
Permita assumir a vida de filhos e outros herdeiros elegíveis, preservando a árvore genealógica e a herança.

### 060. Histórico multigeracional
Mantenha registros das gerações anteriores para que sobrenomes, fortunas, empresas, reputações e relações familiares tenham continuidade.

---

# PARTE 4 — SAÚDE, CORPO E PSICOLOGIA

### 061. Sistema de saúde completo
A saúde deve resultar de genética, hábitos, alimentação, doenças, tratamentos, ambiente, idade e acontecimentos.

### 062. Doenças variadas
Inclua condições agudas, crônicas, infecciosas, congênitas e relacionadas ao envelhecimento, cada uma com comportamentos próprios.

### 063. Sintomas
Doenças podem produzir sintomas que levam o personagem a procurar atendimento, em vez de sempre aparecerem diagnosticadas automaticamente.

### 064. Consultas médicas
Permita consultar médicos, receber avaliação, realizar exames e escolher tratamentos.

### 065. Especialidades médicas
Inclua clínica geral, pediatria, cardiologia, dermatologia, psiquiatria, odontologia, ortopedia, ginecologia e outras especialidades.

### 066. Custos de saúde
Tratamentos devem ter preços distintos conforme o país, o serviço, a cobertura de saúde e a complexidade do procedimento.

### 067. Sistemas públicos de saúde
Simule diferentes modelos nacionais, incluindo o SUS no Brasil e diferentes formatos de seguro e assistência no exterior.

### 068. Medicamentos e tratamentos
Tratamentos devem apresentar eficácia variável, custos, possíveis efeitos adversos e necessidade de continuidade.

### 069. Saúde mental
Inclua estresse, ansiedade, depressão, esgotamento e outras condições, com tratamento respeitoso e sem resultados deterministas.

### 070. Psicoterapia
Permita acompanhamento psicológico que pode ajudar na adaptação e no bem-estar ao longo do tempo.

### 071. Exercícios físicos
Inclua musculação, caminhada, corrida, natação, ciclismo, yoga e outras atividades que influenciem condicionamento e saúde.

### 072. Alimentação
Crie escolhas alimentares e padrões de dieta com custos, efeitos graduais e possíveis consequências.

### 073. Peso e composição corporal
Permita variações conforme hábitos, genética, idade, condições clínicas e nível de atividade.

### 074. Sono e recuperação
Privação de sono e excesso de atividades devem afetar energia, concentração e desempenho.

### 075. Cirurgias
Inclua cirurgias clínicas e eletivas, com indicação, custos, recuperação e riscos.

### 076. Procedimentos estéticos
Permita tratamentos de beleza, cirurgias plásticas e mudanças de aparência, com resultados e riscos variáveis.

### 077. Dependências
Modele possíveis dependências relacionadas a álcool, substâncias e jogos, com efeitos financeiros, sociais e de saúde.

### 078. Reabilitação
Permita buscar ajuda e tratamento, com possibilidade de recuperação, recaídas e mudanças graduais.

### 079. Deficiências e acessibilidade
Inclua condições físicas e sensoriais com possíveis adaptações, tecnologias assistivas e oportunidades de vida significativas.

### 080. Histórico médico persistente
Mantenha diagnósticos, tratamentos, cirurgias, lesões e condições relevantes ao longo da vida.

---

# PARTE 5 — INFÂNCIA, FAMÍLIA E ADOLESCÊNCIA

### 081. Pais como personagens independentes
Pai, mãe ou responsáveis precisam ter nome, idade, profissão, renda, personalidade, relacionamento e acontecimentos próprios.

### 082. Condição financeira familiar
A renda e o patrimônio dos responsáveis devem influenciar acesso a bens e oportunidades, sem impedir trajetórias de ascensão social.

### 083. Relacionamento com os pais
Permita pedir presentes, dinheiro, conversar, passar tempo juntos, discutir, demonstrar afeto e solicitar apoio.

### 084. Irmãos
Gere irmãos biológicos, adotivos, meios-irmãos e irmãos por afinidade, com diferenças de idade e personalidade.

### 085. Nascimento de novos irmãos
Os pais podem ter outros filhos durante a infância do jogador, alterando a estrutura familiar.

### 086. Divórcio dos pais
A separação dos responsáveis deve poder gerar mudanças de residência, convivência, situação financeira e relações familiares.

### 087. Novos relacionamentos dos pais
Inclua padrastos, madrastas e familiares adquiridos por novos casamentos ou uniões.

### 088. Adoção
O personagem pode nascer em família adotiva, ser adotado posteriormente ou conhecer parte de sua história de origem.

### 089. Orfandade
Se responsáveis falecerem, implemente guarda por familiares, responsáveis legais ou acolhimento, conforme o contexto.

### 090. Brincadeiras e infância
Inclua brinquedos, festas de aniversário, atividades escolares, brincadeiras com amigos e acontecimentos infantis.

### 091. Desenvolvimento de habilidades
Aulas de música, esportes, idiomas, artes e outras atividades podem começar durante a infância.

### 092. Pedidos aos responsáveis
Crianças podem solicitar animais, cursos, presentes, viagens ou transferência de escola, com respostas dependentes de recursos e relacionamento.

### 093. Amizades infantis
Crie colegas com quem o personagem possa formar amizades que durem décadas.

### 094. Conflitos escolares
Inclua bullying, rivalidades, desentendimentos, suspensões e medidas disciplinares com consequências proporcionais.

### 095. Puberdade
Implemente mudanças físicas, emocionais e sociais relacionadas ao desenvolvimento, sem situações sexuais envolvendo crianças.

### 096. Primeiros relacionamentos adolescentes
Permita paqueras, namoros e términos compatíveis com a idade e a legislação, com abordagem não explícita.

### 097. Autonomia progressiva
A liberdade para sair, trabalhar, dirigir ou administrar dinheiro aumenta de acordo com a idade e as regras locais.

### 098. Mesada
Responsáveis podem oferecer mesada, condicionar pagamentos a tarefas ou negar pedidos.

### 099. Trabalhos permitidos para jovens
Inclua atividades legalmente permitidas, estágio e aprendizagem profissional, respeitando a legislação de cada país.

### 100. Emancipação e independência
Quando permitido, personagens podem conquistar autonomia legal e financeira antes da idade adulta padrão, assumindo as responsabilidades correspondentes.

---

# PARTE 6 — EDUCAÇÃO E FORMAÇÃO PROFISSIONAL

### 101. Sistema educacional por país
Cada país deve ter etapas, duração, calendário, requisitos e custos educacionais próprios.

### 102. Educação infantil
Inclua creche, pré-escola e preparação para etapas posteriores.

### 103. Ensino fundamental
Crie matérias, notas, professores, colegas, comportamento e desempenho.

### 104. Ensino médio
Permita desenvolver especializações acadêmicas, preparação para universidades, esportes e atividades extracurriculares.

### 105. Escolas públicas e privadas
Diferencie custo, recursos, qualidade e oportunidades, sem garantir resultados apenas pela mensalidade.

### 106. Escolhas de estudo
Permita estudar mais, fazer tarefas, frequentar biblioteca, pedir ajuda e participar de atividades.

### 107. Sistema de notas
Notas devem evoluir segundo dedicação, capacidade, dificuldades, frequência e acontecimentos.

### 108. Professores individuais
Crie professores com personalidades e estilos diferentes, permitindo relações positivas ou conflitos.

### 109. Clubes escolares
Inclua grêmio estudantil, teatro, coral, robótica, debate, xadrez, jornal e clubes esportivos.

### 110. Bolsas de estudo
Conceda bolsas baseadas em desempenho, esportes, necessidades socioeconômicas e critérios institucionais.

### 111. Vestibulares e exames
Inclua exames de admissão coerentes com o país, como ENEM e vestibulares no Brasil, sem exigir o mesmo sistema em todo o mundo.

### 112. Universidades reais ou fictícias coerentes
Ofereça instituições reconhecíveis e alternativas fictícias, respeitando localização, áreas de estudo e requisitos.

### 113. Cursos superiores
Inclua medicina, direito, engenharia, administração, economia, computação, psicologia, arquitetura, jornalismo e dezenas de outros cursos.

### 114. Duração dos cursos
Cada formação deve exigir um período realista, levando em conta regras nacionais e possíveis reprovações.

### 115. Mensalidades e financiamento estudantil
Permita pagar cursos, solicitar apoio familiar, bolsas, crédito estudantil ou utilizar programas públicos disponíveis.

### 116. Pós-graduação
Inclua especialização, mestrado, doutorado e outras qualificações relevantes.

### 117. Formação técnica
Permita seguir caminhos profissionais sem universidade, incluindo cursos técnicos e certificações.

### 118. Mudança de curso
O jogador pode abandonar, trocar, trancar ou retomar uma formação, com impactos de tempo e dinheiro.

### 119. Educação continuada
Mesmo depois dos 40, 60 ou 80 anos, permita estudar novamente, respeitando a natureza do curso.

### 120. Histórico acadêmico
Guarde diplomas, instituições, anos de conclusão, desempenho, certificados e qualificações que influenciam futuras oportunidades.

---

# PARTE 7 — EMPREGO E CARREIRAS TRADICIONAIS

### 121. Catálogo extenso de profissões
Implemente inicialmente centenas de profissões distribuídas por educação, saúde, segurança, tecnologia, indústria, comércio, serviços, artes, governo, transportes e outras áreas.

### 122. Banco de vagas dinâmico
As vagas devem variar conforme cidade, país, economia, escolaridade, experiência e acontecimentos do mercado.

### 123. Candidatura a vagas
Permita selecionar profissões disponíveis, analisar requisitos e enviar candidaturas.

### 124. Entrevistas de emprego
Crie perguntas e situações com respostas que afetem a chance de contratação conforme o perfil da empresa.

### 125. Requisitos profissionais
Exija qualificações, experiência, licenças e formação quando necessários, sem impedir toda contratação inicial por falta de experiência.

### 126. Salários contextualizados
Utilize remunerações compatíveis com país, região, cargo, experiência e setor.

### 127. Evolução salarial
Inclua aumentos, promoções, bônus, reajustes, negociação salarial e perdas de remuneração.

### 128. Progressão hierárquica
Crie níveis de carreira, como auxiliar, assistente, analista, especialista, coordenador, gerente, diretor e executivo, quando aplicáveis.

### 129. Desempenho profissional
Avalie produtividade, habilidades, assiduidade, relacionamento com a equipe e qualidade do trabalho.

### 130. Jornada de trabalho
Diferencie cargas horárias, turnos, empregos de meio período, trabalho remoto e horas extras.

### 131. Chefes individuais
Chefes devem possuir exigência, competência, temperamento, favoritismos e decisões próprias.

### 132. Colegas de trabalho
Permita amizades, rivalidades, romances entre adultos, colaboração e conflitos com colegas.

### 133. Ações no trabalho
Inclua trabalhar mais, pedir aumento, solicitar promoção, elogiar colegas, reclamar, denunciar irregularidades e pedir transferência.

### 134. Demissões
Demissões podem resultar de desempenho, crises econômicas, fechamento de empresas, comportamentos ou decisões arbitrárias contestáveis.

### 135. Pedido de demissão
O jogador pode sair voluntariamente, perdendo remuneração e eventualmente benefícios, mas preservando seu histórico profissional.

### 136. Desemprego
O desemprego deve afetar renda, despesas, felicidade e oportunidades, com possíveis benefícios sociais conforme o país.

### 137. Trabalho autônomo
Permita trabalhar por conta própria como profissional liberal ou prestador de serviços, com renda variável e custos.

### 138. Múltiplos empregos
Permita combinar empregos compatíveis, respeitando horários, energia, contratos e limites legais.

### 139. Aposentadoria profissional
Calcule benefícios conforme histórico de contribuição e regras nacionais, além de permitir aposentadorias privadas.

### 140. Catálogo de carreiras configurável
Todas as profissões devem ser cadastradas em uma estrutura de dados expansível, contendo nome, setor, escolaridade, salário, progressão, requisitos e eventos próprios.

---

# PARTE 8 — CARREIRAS ESPECIAIS E SISTEMAS PROFUNDOS

### 141. Atleta profissional
Implemente treinamento, seletivas, contratação por clubes, posição, desempenho, lesões, patrocínios, transferência e aposentadoria esportiva.

### 142. Futebol profissional
Inclua clubes, divisões, temporadas, campeonatos, desempenho individual, contratos, transferências e seleção nacional.

### 143. Outros esportes profissionais
Inclua basquete, tênis, automobilismo, beisebol, futebol americano, vôlei e modalidades compatíveis com diferentes países.

### 144. Artes marciais profissionais
Permita desenvolver técnicas, contratar treinadores, disputar lutas, avançar em rankings e conquistar títulos.

### 145. Cantor solo
Crie sistema de aulas, gravadoras, contratos, singles, álbuns, vendas, streaming, shows, turnês e premiações.

### 146. Bandas musicais
Permita entrar em bandas, formar grupos, lidar com integrantes, dividir receitas, substituir membros e encerrar projetos.

### 147. Ator
Inclua audições, agentes, contratos, séries, filmes, cachets, reputação, premiações e evolução profissional.

### 148. Diretor de cinema
Permita escolher roteiros, gêneros, orçamento, elenco, equipe, cronograma, marketing e lançamento de filmes, com resultados de bilheteria.

### 149. Modelo profissional
Inclua agências, testes, campanhas, passarelas, contratos publicitários, portfólio, prestígio e concorrência.

### 150. Político
Crie campanhas, doações, eleições, mandatos, popularidade, propostas, debates, escândalos e possibilidade de reeleição.

### 151. Presidente ou chefe de governo
Implemente políticas públicas, crises econômicas, diplomacia, decisões governamentais e aprovação popular, conforme as instituições do país.

### 152. Astronauta
Exija formação e treinamento, permitindo missões espaciais, pesquisas, acidentes e progressão em organizações espaciais.

### 153. Militar
Inclua alistamento, patentes, promoções, diferentes forças, treinamentos, missões, condecorações e aposentadoria.

### 154. Agente secreto
Crie carreira de espionagem com organização, agentes, missões fictícias, inteligência, cobertura e risco de descoberta.

### 155. Integrante de organização criminosa
Permita uma trajetória narrativa de baixo escalão até liderança, envolvendo reputação, riscos, dinheiro, rivalidades e investigação policial.

### 156. Trabalhador informal urbano
Inclua apresentações de rua, vendas ambulantes, pequenos serviços e outras atividades com renda variável.

### 157. Comerciante de atividades ilegais
Modele uma carreira criminosa abstrata de comércio clandestino, com consequências legais e sociais, sem depender de instruções operacionais reais.

### 158. Empresário profissional
Crie uma carreira empresarial completa, desde pequenos negócios até grandes companhias, vinculada ao sistema de economia e investimentos.

### 159. Celebridade de múltiplas áreas
Permita que pessoas alcancem fama como escritores, chefs, jornalistas, influenciadores, artistas, empresários e profissionais de outras áreas.

### 160. Progressão exclusiva por profissão
Carreiras especiais não podem ser apenas uma escolha de emprego com salário alto. Cada uma deve possuir telas, ações, níveis, riscos, eventos e objetivos próprios.

---

# PARTE 9 — RELACIONAMENTOS, FAMÍLIA E CONVIVÊNCIA SOCIAL

### 161. Sistema completo de relacionamentos
Mantenha indicadores próprios de proximidade, confiança, respeito, atração, conflitos e histórico para cada relação.

### 162. NPCs com personalidade
A mesma ação pode produzir respostas diferentes dependendo de personalidade, humor, valores e histórico com o jogador.

### 163. Conversar
Permita conversar sobre temas variados, com efeitos dependentes da compatibilidade entre os personagens.

### 164. Limite anual de conversas
Reproduza uma restrição de progressão: a primeira conversa significativa com uma pessoa pode melhorar a relação; conversas adicionais no mesmo ano não devem aumentar indefinidamente o indicador.

### 165. Efeitos decrescentes das interações
Aplique retornos decrescentes a presentes, elogios, momentos juntos e outras ações repetidas, evitando explorar o jogo com cliques ilimitados.

### 166. Passar tempo juntos
Permita escolher atividades de convivência, como jantar, viajar, assistir a filmes e visitar lugares.

### 167. Presentear
Implemente presentes com preços e preferências individuais, sem garantir que objetos caros sempre provoquem melhores resultados.

### 168. Elogiar
Elogios podem fortalecer relações ou causar desconforto se forem inadequados, repetitivos ou incompatíveis com o contexto.

### 169. Insultar
Insultos devem poder provocar discussões, rompimentos, rivalidades ou outras respostas.

### 170. Pedir dinheiro
Permita pedir ajuda financeira a conhecidos com base em recursos, confiança, histórico e disposição de ajudar.

### 171. Emprestar dinheiro
Crie empréstimos pessoais que possam ser quitados, atrasados, perdoados ou disputados.

### 172. Amigos
Permita formar amizades, escolher melhores amigos e cultivar laços duradouros.

### 173. Inimizades
Inclua rivais, antigos amigos e pessoas ressentidas que possam reaparecer em diferentes momentos da vida.

### 174. Reencontros
Amigos e familiares distantes podem retornar depois de anos, gerando oportunidades de reconciliação ou novos conflitos.

### 175. Reconciliação
Permita pedir desculpas, tentar recuperar confiança e resolver conflitos, sem garantir perdão automático.

### 176. Memória relacional
Cada NPC deve lembrar acontecimentos importantes, como traições, ajuda financeira, agressões, abandono e apoio emocional.

### 177. Relações familiares ampliadas
Inclua avós, tios, primos, sobrinhos, netos, sogros, cunhados e outros familiares.

### 178. Eventos familiares
Crie aniversários, casamentos, formaturas, festas, reuniões, funerais e conflitos entre parentes.

### 179. Evolução autônoma dos familiares
Familiares podem mudar de cidade, casar, divorciar, ter filhos, trocar de emprego e passar por dificuldades independentemente do jogador.

### 180. Rede social persistente
O círculo social deve evoluir de forma orgânica. Amigos mudam, colegas se afastam, parentes envelhecem e relacionamentos podem terminar naturalmente.

---

# PARTE 10 — ROMANCE, SEXUALIDADE, CASAMENTO E FILHOS

### 181. Sistema de namoro
Permita procurar parceiros, conhecer pessoas, conversar, convidar para encontros e iniciar relacionamentos.

### 182. Aplicativos de relacionamento
Crie aplicativos fictícios de namoro com filtros de idade, localização, preferências e interesses.

### 183. Compatibilidade romântica
Calcule compatibilidade considerando personalidade, objetivos, interesses, atração, estilo de vida e valores.

### 184. Encontros
Inclua restaurantes, cinema, cafés, viagens, parques e outras atividades com resultados diferentes.

### 185. Vida sexual adulta
Implemente um sistema de intimidade entre adultos consentindo livremente, com abordagem não gráfica, afetando satisfação, relacionamento e possíveis consequências.

### 186. Relacionamentos casuais
Permita encontros ocasionais entre adultos, respeitando consentimento e oferecendo consequências sociais e de saúde plausíveis.

### 187. Fidelidade e traição
Parceiros podem ser fiéis ou infiéis, dependendo da personalidade, dos acordos do casal e de decisões narrativas.

### 188. Descoberta de traições
Inclua suspeitas, revelações, discussões, separações e reconciliações.

### 189. Pedido de casamento
Permita escolher momento, local e anel, levando em conta relacionamento, objetivos do casal e condições financeiras.

### 190. Casamento
Inclua cerimônias, custos, convidados, lua de mel e diferentes regimes patrimoniais conforme a legislação.

### 191. Divórcio
Implemente separação, divisão de bens, pensão, guarda dos filhos e possíveis disputas judiciais.

### 192. União estável e coabitação
Permita morar com parceiros sem casamento formal, compartilhando custos e responsabilidades.

### 193. Planejamento familiar
Permita decidir se deseja ter filhos, quando tentar engravidar, quais métodos contraceptivos utilizar e como administrar a vida familiar.

### 194. Gravidez
Modele fertilidade, gestação, consultas e nascimento com variações por idade e condições de saúde.

### 195. Nascimento de filhos
Crie crianças com nomes, características herdadas, personalidade inicial e relações familiares persistentes.

### 196. Adoção de filhos
Permita processos de adoção conforme regras de cada país, incluindo custos administrativos, avaliação e disponibilidade.

### 197. Tratamentos de fertilidade
Inclua métodos médicos de reprodução assistida e suas diferenças de custo, requisitos e probabilidade de sucesso.

### 198. Guarda e criação dos filhos
Implemente convivência, educação, apoio financeiro, cuidados e relações familiares durante o crescimento.

### 199. Sexualidade e identidade na vida adulta
Permita descoberta pessoal, mudanças de relacionamento e escolhas de identidade com respeito e consequências sociais contextuais, sem discriminação mecânica arbitrária.

### 200. Histórias românticas não repetitivas
Desenvolva romances com evolução gradual, objetivos diferentes, conflitos plausíveis, separações, novas oportunidades e consequências de longo prazo.

---

# PARTE 11 — PATRIMÔNIO, IMÓVEIS E VEÍCULOS

### 201. Catálogo imobiliário massivo
Implemente centenas de tipos e combinações de imóveis, distribuídos geograficamente. Diferencie padrão construtivo, tamanho, idade, conservação, localização e demanda.

### 202. Imóveis por cidades e bairros reais
Crie mercados imobiliários específicos para São Paulo, Rio de Janeiro, Curitiba, Florianópolis, Jaraguá do Sul, Los Angeles, Nova York, Miami, Detroit, Londres, Tóquio e muitas outras localidades.

### 203. Preços regionais de imóveis
Os valores devem depender da localização, metragem, características e condições de mercado. Bairros valorizados devem, em geral, possuir preços superiores aos de regiões econômicas da mesma cidade.

### 204. Diversidade habitacional
Inclua quitinetes, studios, apartamentos, casas simples, sobrados, coberturas, mansões, sítios, fazendas, chácaras, lofts, casas de praia e propriedades históricas.

### 205. Qualidade e conservação
Cada imóvel deve possuir estado de conservação, ano de construção, necessidades de manutenção e possíveis defeitos.

### 206. Compra de imóveis
Permita filtrar anúncios, escolher propriedades, negociar valores, comprar à vista e financiar conforme as condições disponíveis.

### 207. Financiamento imobiliário
Implemente entrada, taxa de juros, prazo, prestações, saldo devedor, amortização, inadimplência e retomada por falta de pagamento.

### 208. Aluguel residencial
O jogador pode alugar uma residência sem precisar comprá-la, pagando aluguel, eventuais taxas e contas mensais.

### 209. Mudança de residência
Permita trocar de casa, bairro, cidade ou país, levando em consideração custos de mudança, contratos e composição familiar.

### 210. Venda de imóveis
Permita anunciar imóveis, escolher preços, receber propostas, negociar e realizar vendas, com impostos e despesas de transação aplicáveis.

### 211. Valorização e desvalorização
Os imóveis devem oscilar de valor segundo localização, inflação, oferta, demanda, manutenção e acontecimentos econômicos.

### 212. Imóveis para investimento
Permita comprar casas e apartamentos para alugar, acumulando rendimentos e administrando vários contratos.

### 213. Administração de inquilinos
Inclua seleção de inquilinos, contratos, atrasos, danos, inadimplência, reformas e disputas legais.

### 214. Reformas e construções
Permita reformar ambientes, ampliar imóveis e construir em terrenos quando possível, considerando orçamento, prazo, licenças e valorização.

### 215. Terrenos
Inclua terrenos urbanos, rurais, comerciais e industriais, com localização, área, zoneamento e possibilidades de aproveitamento.

### 216. Catálogo de carros reais
Inclua marcas e modelos de diferentes categorias, como Fiat Uno, Volkswagen Golf, Toyota Corolla, Honda Civic, Jeep Compass, BMW Série 3, Mercedes-Benz Classe C e Porsche 911, respeitando o contexto histórico.

### 217. Mercado automotivo
Carros devem possuir ano, quilometragem, conservação, combustível, consumo, manutenção, preço regional e depreciação.

### 218. Compra, venda e financiamento de veículos
Permita adquirir veículos novos ou usados, vender, trocar, financiar, contratar seguros e lidar com despesas recorrentes.

### 219. Veículos especiais
Inclua motocicletas, bicicletas, caminhonetes, caminhões, motorhomes, barcos, iates, helicópteros, aviões e outros veículos com requisitos próprios.

### 220. Gestão completa de patrimônio
Mantenha uma tela detalhada com todos os bens, valores, dívidas, contratos, rendimentos, despesas, estado de conservação e patrimônio líquido.

---

# PARTE 12 — ECONOMIA, MOEDAS E FINANÇAS PESSOAIS

### 221. Moedas nacionais
Cada país deve operar com sua moeda própria, como BRL, USD, EUR, GBP, JPY, CAD, AUD e outras moedas existentes.

### 222. Conversão monetária na imigração
Ao mudar de país, o dinheiro disponível deve ser apresentado e convertido contabilmente para a moeda local, usando taxas coerentes, sem gerar riqueza artificial.

### 223. Conversão de preços e salários
Depois da imigração, salários, serviços e produtos devem usar preços locais. Não basta substituir o símbolo da moeda.

### 224. Taxas de câmbio
Crie taxas de câmbio configuráveis, coerentes por período histórico, com possibilidade de variação e custos de conversão.

### 225. Custo de vida regional
Alimentação, transporte, educação, moradia, lazer e saúde devem ter custos diferentes por cidade e país.

### 226. Receitas anuais
Registre salários, bônus, aluguéis recebidos, rendimentos financeiros, pensões, lucros empresariais e outras receitas.

### 227. Despesas anuais
Registre moradia, alimentação, transporte, educação, saúde, impostos, dívidas e despesas com dependentes.

### 228. Orçamento doméstico
Permita acompanhar despesas fixas, variáveis, saldo disponível, orçamento planejado e capacidade de poupança.

### 229. Contas bancárias
Crie contas correntes e poupanças com saldo, movimentações e condições bancárias.

### 230. Bancos diferentes
Inclua instituições com juros, tarifas, opções de financiamento e critérios de concessão de crédito distintos.

### 231. Cartões de crédito
Permita utilizar limite, pagar fatura, parcelar compras e acumular dívida caso não pague corretamente.

### 232. Empréstimos pessoais
Implemente crédito com principal, taxa, prazo, parcelas, garantias e consequências de inadimplência.

### 233. Score de crédito
Crie reputação financeira influenciada por pagamentos, atrasos, endividamento e histórico bancário.

### 234. Inflação
A inflação deve afetar gradualmente preços, salários, poder de compra e retornos reais dos investimentos.

### 235. Impostos
Implemente tributação compatível com países e tipos de renda, incluindo impostos sobre salários, investimentos, propriedades e heranças.

### 236. Desemprego e benefícios
Inclua mecanismos de assistência e seguro-desemprego onde existirem, sujeitos a requisitos.

### 237. Previdência
Crie contribuições previdenciárias, aposentadoria pública e planos privados.

### 238. Patrimônio líquido
Calcule corretamente o valor dos ativos menos passivos, sem confundir dinheiro disponível com patrimônio total.

### 239. Falência pessoal
O personagem pode entrar em crise financeira, perder bens e renegociar dívidas, com possibilidade de recuperação.

### 240. Histórico financeiro
Mantenha registros de renda, patrimônio, dívidas, investimentos, compras e vendas ao longo dos anos.

---

# PARTE 13 — EMPRESAS, EMPREENDEDORISMO E INVESTIMENTOS

### 241. Abertura de empresas
Permita escolher o setor, nome, cidade, investimento inicial, estrutura societária e modelo de negócio.

### 242. Setores empresariais
Inclua restaurantes, tecnologia, varejo, indústria, logística, consultoria, imobiliárias, construção civil, mídia, serviços e vários outros mercados.

### 243. Empresas de diferentes portes
O jogador pode começar com um pequeno negócio e expandir até uma companhia de grande porte.

### 244. Funcionários e equipes
Permita contratar, promover, treinar, remunerar e demitir funcionários, considerando suas habilidades e desempenho.

### 245. Produtos e serviços
Cada empresa deve oferecer produtos ou serviços com preços, demanda, custos, concorrência e margem de lucro.

### 246. Estoques e produção
Negócios que vendem produtos físicos devem administrar inventário, fornecedores, desperdícios e capacidade produtiva.

### 247. Marketing empresarial
Permita investir em publicidade, branding e aquisição de clientes, com resultados dependentes do setor.

### 248. Concorrência
Empresas rivais devem competir por consumidores, profissionais e participação de mercado.

### 249. Demonstrações financeiras
Exiba faturamento, custos, despesas, lucro, fluxo de caixa, dívidas e valor estimado do negócio.

### 250. Expansão empresarial
Permita abrir filiais, desenvolver produtos, entrar em novos mercados e operar internacionalmente.

### 251. Sócios e investidores
Inclua divisão societária, aportes de capital, conflitos entre sócios, diluição e compra de participações.

### 252. Venda de empresas
Permita negociar a venda parcial ou total do negócio, recebendo valores coerentes com desempenho e riscos.

### 253. Falência empresarial
Empresas podem fechar por prejuízo, dívidas, má gestão, crises econômicas ou perda de clientes.

### 254. Mercado de ações
Permita comprar e vender ações, acompanhar empresas, receber dividendos e enfrentar variações de preços.

### 255. Fundos e renda fixa
Inclua investimentos de diferentes riscos e prazos, adequados aos mercados financeiros dos países simulados.

### 256. Criptomoedas
Inclua moedas digitais fictícias ou reais de forma representativa, com alta volatilidade, riscos e eventos próprios.

### 257. Investimento imobiliário
Permita diversificar patrimônio entre imóveis, terrenos, aluguéis e empreendimentos.

### 258. Colecionáveis
Inclua relógios, joias, obras de arte, antiguidades e itens raros que podem valorizar ou desvalorizar.

### 259. Leilões
Permita participar de leilões de bens, imóveis e colecionáveis, escolhendo lances, limites e estratégias abstratas de avaliação.

### 260. Dinastias empresariais
Empresas familiares podem ser herdadas, administradas por descendentes e continuar operando por várias gerações.

---

# PARTE 14 — ATIVIDADES, LAZER, VIDA NOTURNA E CASSINO

### 261. Centro de atividades
Crie um menu completo, organizado por categorias, com dezenas de ações disponíveis conforme idade, localização e recursos.

### 262. Biblioteca e leitura
Permita ler livros de gêneros variados, estudar temas específicos e desenvolver conhecimento, cultura e habilidades.

### 263. Cinema e entretenimento
Inclua filmes, teatro, museus, exposições, festivais, shows, parques e eventos culturais.

### 264. Esportes recreativos
Permita jogar futebol, tênis, beach tennis, basquete, vôlei, golfe e outras modalidades sem depender de uma carreira profissional.

### 265. Hobbies
Inclua jardinagem, fotografia, culinária, pintura, escrita, pesca, programação, artesanato e colecionismo.

### 266. Instrumentos musicais
Permita aprender violão, piano, guitarra, bateria, violino e outros instrumentos, com níveis de habilidade.

### 267. Viagens nacionais
Permita selecionar destinos reais, transporte, duração, hospedagem e atividades durante a viagem.

### 268. Viagens internacionais
Inclua passaporte, visto, custos, moeda local e possibilidade de acontecimentos durante a viagem.

### 269. Cruzeiros e turismo de luxo
Permita realizar viagens com categorias diferentes, desde opções econômicas até experiências de altíssimo padrão.

### 270. Vida noturna adulta
Inclua bares, baladas, boates, festas privadas, festivais e eventos sociais, com custos, encontros e consequências.

### 271. Eventos em bares e clubes
Gere situações como conhecer pessoas, discutir, iniciar romances, perder objetos, gastar demais ou fazer novos contatos.

### 272. Consumo de álcool
Permita escolhas de consumo por adultos conforme regras locais, com consequências de saúde, comportamento e segurança.

### 273. Festas e eventos privados
O jogador pode organizar festas em casa, convidar pessoas, definir orçamento e enfrentar acontecimentos inesperados.

### 274. Sistema de cassino
Crie uma área de jogos de azar com apostas exclusivamente virtuais, saldo fictício, limites e resultados probabilísticos consistentes.

### 275. Blackjack
Implemente regras funcionais de blackjack, incluindo cartas, mão do jogador, mão da banca, vitória, derrota e empate.

### 276. Roleta
Inclua apostas em números, cores e outros resultados válidos, calculando pagamentos com base nas regras da roleta.

### 277. Máquinas caça-níqueis
Crie máquinas virtuais com símbolos, probabilidades, combinações vencedoras e tabelas de pagamento transparentes.

### 278. Loterias e corridas
Permita comprar bilhetes de loteria e fazer apostas fictícias em corridas, com chances, prêmios e riscos financeiros.

### 279. Consequências financeiras das apostas
Ganhos e perdas devem ser registrados. Repetir apostas não pode manipular a aleatoriedade ou garantir lucro.

### 280. Hábitos e riscos relacionados ao jogo
Implemente possíveis problemas financeiros e comportamentais associados às apostas, incluindo opções de limites voluntários e busca de ajuda.

---

# PARTE 15 — CRIMINALIDADE, POLÍCIA, JUSTIÇA E PRISÃO

### 281. Sistema criminal baseado em escolhas
Inclua atividades ilícitas como possibilidades narrativas com diferentes níveis de gravidade, risco de descoberta e consequências legais.

### 282. Pequenos furtos
Permita tentativas de furtos simples, resolvidas por probabilidades e circunstâncias, sem fornecer instruções reais de execução.

### 283. Roubos e assaltos
Inclua eventos de crimes patrimoniais, com decisões abstratas e consequências financeiras, legais e pessoais.

### 284. Furto de veículos
Permita esse caminho narrativo com chances de captura, prejuízos e registros policiais, sem descrever técnicas operacionais.

### 285. Crimes financeiros
Inclua fraudes, corrupção, desvios e outros delitos como eventos simulados, sujeitos a investigação.

### 286. Crime organizado
Crie organizações criminosas fictícias com hierarquias, missões, reputação, rivalidades e riscos.

### 287. Investigação policial
Crimes podem gerar investigações, suspeitas, interrogatórios e consequências ao longo de anos.

### 288. Captura e prisão
A polícia pode prender personagens com base em eventos e nas leis do país.

### 289. Antecedentes criminais
Mantenha registros de condenações e situações legais que influenciem emprego, imigração e reputação.

### 290. Advogados
Permita contratar defesa jurídica com custos, especializações e qualidade de representação variáveis.

### 291. Julgamentos
Inclua acusações, defesa, provas abstratas, decisões judiciais, absolvições e condenações.

### 292. Penas
A gravidade da pena deve depender da legislação, natureza do delito, histórico e circunstâncias judiciais.

### 293. Vida na prisão
Crie rotinas prisionais, relacionamentos com detentos, atividades, conflitos, educação e disciplina.

### 294. Comportamento carcerário
Permita estudar, trabalhar, desenvolver habilidades, participar de atividades ou envolver-se em conflitos dentro da prisão.

### 295. Tentativas de fuga
Inclua minijogos originais de fuga, desvinculados de instruções reais, com risco de captura e aumento de pena.

### 296. Progressão de regime
Permita mudanças nas condições de cumprimento de pena quando previstas pelo sistema jurídico simulado.

### 297. Liberdade condicional
Inclua concessão, condições de acompanhamento, restrições e possibilidade de revogação.

### 298. Reintegração social
Ex-detentos podem enfrentar dificuldades de emprego, moradia e relacionamento, mas devem possuir caminhos de recuperação.

### 299. Processos civis
Permita processar ou ser processado por disputas contratuais, danos, questões familiares e outras situações.

### 300. Consequências jurídicas persistentes
Decisões ilegais precisam gerar riscos e efeitos duradouros, sem transformar o crime em um mecanismo garantido de enriquecimento.

---

# PARTE 16 — PAÍSES, IMIGRAÇÃO, CULTURA E MUNDO

### 301. Mundo geograficamente diversificado
Inclua países e cidades de todos os continentes habitados, cada um com características próprias.

### 302. Diferenças culturais
Considere costumes, idiomas, feriados, tradições, hábitos sociais e eventos locais, evitando estereótipos simplistas.

### 303. Idiomas
Personagens devem ter idiomas nativos e poder aprender outros, afetando determinadas oportunidades de comunicação e trabalho.

### 304. Cidadania
Permita cidadania por nascimento, ascendência, naturalização e outros caminhos conforme regras simuladas.

### 305. Dupla nacionalidade
Inclua possibilidade de possuir múltiplas cidadanias quando as regras dos países envolvidos permitirem.

### 306. Passaportes
Cada personagem deve possuir documentos de viagem adequados, com validade e possíveis restrições.

### 307. Vistos
Viagens e imigração devem considerar necessidade de visto, propósito da viagem, condições de permanência e autorizações.

### 308. Imigração legal
Permita solicitar residência, trabalho, estudo ou reunião familiar em outro país, com custos e condições variáveis.

### 309. Imigração irregular
Inclua como possibilidade narrativa sujeita a consequências jurídicas, sem fornecer métodos operacionais para evitar controles migratórios.

### 310. Mudança definitiva de país
Ao emigrar, transfira a residência do personagem, atualize moeda, custo de vida, opções profissionais e contexto cultural.

### 311. Conversão patrimonial internacional
Dinheiro disponível, investimentos e propriedades devem manter valores economicamente consistentes durante mudanças de moeda.

### 312. Bens mantidos no exterior
Um personagem pode morar nos Estados Unidos e continuar possuindo imóveis alugados no Brasil, por exemplo.

### 313. Empregabilidade internacional
Diplomas, experiência, idiomas, licenças profissionais e situação migratória devem influenciar oportunidades.

### 314. Transferência de empresas
Permita expandir ou transferir operações empresariais para outros países, conforme custos e requisitos.

### 315. Eventos econômicos nacionais
Crises, crescimento, inflação, desemprego e mudanças econômicas devem alterar o cenário dos países.

### 316. Conflitos e instabilidade
Inclua acontecimentos geopolíticos abstratos que possam afetar migração, economia, segurança e oportunidades.

### 317. Desastres naturais
Inclua eventos climáticos ou geológicos com probabilidades relacionadas à localização e consequências apropriadas.

### 318. Diferenças legais
Idade de maioridade, regras de casamento, impostos, direitos profissionais e outras condições devem acompanhar o país.

### 319. Diferenças históricas
Caso o personagem nasça em décadas diferentes, adapte disponibilidade de produtos, tecnologias, profissões e circunstâncias históricas.

### 320. Comparação entre países
Crie uma tela que apresente moeda, idioma, custo estimado de vida, oportunidades e regras migratórias antes de uma mudança.

---

# PARTE 17 — FAMA, REDES SOCIAIS E REPUTAÇÃO

### 321. Indicador de fama
Crie um atributo próprio de notoriedade, separado de felicidade, dinheiro, reputação e sucesso profissional.

### 322. Caminhos variados para fama
Permita alcançar notoriedade por entretenimento, esportes, negócios, política, mídia, literatura e produção digital.

### 323. Redes sociais fictícias
Crie plataformas inspiradas nas funções de redes conhecidas, mas com nomes e identidade próprios.

### 324. Criação de conteúdo
Permita publicar fotos, vídeos, textos, transmissões e conteúdo especializado, conforme habilidades e recursos.

### 325. Seguidores
O número de seguidores deve depender de alcance, qualidade, frequência, relevância, fama prévia e eventos.

### 326. Engajamento
Simule curtidas, comentários, compartilhamentos e visualizações de forma relacionada ao público e ao conteúdo.

### 327. Crescimento orgânico
Contas devem evoluir gradualmente, com possibilidade de crescimento acelerado por conteúdos populares.

### 328. Viralização
Algumas publicações podem alcançar públicos enormes, mas não devem viralizar automaticamente com tentativas repetidas.

### 329. Monetização
Permita receber receitas por anúncios, assinaturas, patrocínios, produtos e contratos publicitários.

### 330. Parcerias com marcas
Inclua propostas comerciais, negociação de valores, reputação de patrocinadores e riscos contratuais.

### 331. Entrevistas
Celebridades podem conceder entrevistas e influenciar a imagem pública conforme suas respostas.

### 332. Aparições públicas
Inclua programas de televisão, eventos, palestras, convenções, tapetes vermelhos e outras aparições.

### 333. Polêmicas
Crie controvérsias que possam afetar reputação, seguidores, contratos e relacionamentos.

### 334. Cancelamento público
Simule crises de reputação com respostas variadas, evitando um único resultado automático.

### 335. Recuperação de imagem
Permita reconstruir reputação por meio de comportamentos, campanhas, mudanças e passagem do tempo.

### 336. Paparazzi e imprensa
Pessoas famosas podem ter acontecimentos de sua vida noticiados, criando oportunidades e dificuldades.

### 337. Fama internacional
O reconhecimento pode variar conforme região, idioma, profissão e alcance da carreira.

### 338. Influência da fama na vida pessoal
A fama deve afetar oportunidades de relacionamento, privacidade, eventos, contratos e interações sociais.

### 339. Queda de popularidade
A notoriedade pode diminuir com o tempo, especialmente após longos períodos sem novas atividades públicas.

### 340. Legado público
Ao falecer, o personagem pode ser lembrado por suas contribuições, carreira, patrimônio, escândalos ou acontecimentos importantes.

---

# PARTE 18 — ANIMAIS, REALEZA E SISTEMAS EXTRAORDINÁRIOS

### 341. Animais de estimação
Permita adotar ou comprar animais compatíveis com a legislação local, considerando despesas e responsabilidades.

### 342. Espécies variadas
Inclua cães, gatos, aves, peixes, pequenos mamíferos, cavalos e animais exóticos legalmente permitidos.

### 343. Raças e características
Diferencie raças, tamanho, temperamento, expectativa de vida e necessidades específicas dos animais.

### 344. Cuidados com animais
Implemente alimentação, higiene, veterinário, treinamento, passeios e interação.

### 345. Saúde veterinária
Animais podem adoecer, necessitar de tratamento, envelhecer e morrer.

### 346. Comportamento animal
Cada animal deve ter personalidade, obediência, energia, humor e relação própria com o tutor.

### 347. Criação responsável
Permita reprodução de animais apenas em contextos apropriados, considerando custos, condições e regras legais.

### 348. Fazendas e propriedades rurais
Inclua criação de animais, produção rural, manutenção de terrenos e despesas operacionais.

### 349. Administração de zoológico
Crie uma atividade empresarial de zoológico com funcionários, infraestrutura, bem-estar animal, visitantes e custos.

### 350. Proteção e conservação
Permita apoiar projetos ambientais, resgates legais e programas de preservação de espécies.

### 351. Nascimento em família real
Em países com monarquias, o personagem pode nascer integrante de uma família real fictícia ou inspirada em estruturas institucionais reais.

### 352. Hierarquia nobre
Inclua diferentes títulos, posições sucessórias, responsabilidades e regras de herança.

### 353. Deveres reais
Permita participar de cerimônias, visitas oficiais, atividades beneficentes e compromissos públicos.

### 354. Casamento com membros da realeza
Crie possibilidades de relacionamento entre adultos, respeitando as regras dinásticas simuladas.

### 355. Abdicação
O personagem pode renunciar a posições reais quando permitido, com consequências pessoais e patrimoniais.

### 356. Sucessão ao trono
Inclua acontecimentos de sucessão com base em parentesco e regras institucionais.

### 357. Mercado de luxo
Permita comprar joias raras, obras de arte, relógios de luxo, embarcações e propriedades extraordinárias.

### 358. Coleções históricas
Crie museus pessoais, exposições, avaliações de colecionáveis e eventos de aquisição ou perda.

### 359. Modos extraordinários opcionais
Se o jogo possuir conteúdo sobrenatural ou fantástico, mantenha-o como modo separado, sem interferir no realismo da simulação tradicional.

### 360. Experiências raras
Inclua oportunidades especiais como expedições, viagens exclusivas, projetos científicos e acontecimentos extraordinários, dependendo de recursos e contexto.

---

# PARTE 19 — INTERFACE, IMERSÃO E LIMITAÇÕES DE JOGABILIDADE

### 361. Interface familiar e intuitiva
A interface deve ser simples, rápida e organizada para permitir jogar por muitas gerações sem confusão.

### 362. Tela principal completa
Exiba nome, idade, ocupação, localização, patrimônio e os principais indicadores de estado do personagem.

### 363. Diário de vida
O histórico de acontecimentos deve ser legível, organizado por ano e capaz de apresentar narrativas diferentes.

### 364. Menus por categorias
Organize funções em áreas como atividades, relacionamentos, ocupações, bens, educação, finanças e configurações.

### 365. Indicadores visuais
Utilize barras, ícones e cores coerentes para representar atributos e relações, respeitando acessibilidade.

### 366. Janelas de decisão
Eventos devem apresentar descrição contextual, escolhas claras e possíveis custos quando conhecidos pelo personagem.

### 367. Respostas contextualizadas
Evite textos genéricos como “Você realizou a atividade”. Apresente consequências específicas de acordo com os participantes e circunstâncias.

### 368. Nomes reais em catálogos
Utilize nomes reconhecíveis de cidades, bairros, categorias e modelos de veículos quando apropriado, sem sugerir endosso de marcas.

### 369. Catálogos extensos
A loja de imóveis, veículos, empregos e atividades deve conter opções realmente diferentes, não apenas cinco alternativas reutilizadas.

### 370. Pesquisa e filtros
Permita procurar itens por preço, localização, categoria, características e outras informações relevantes.

### 371. Ações com limites realistas
Implemente limites anuais para benefícios de conversas, estudos, treinamentos e atividades. O jogador não deve maximizar atributos com cliques infinitos.

### 372. Repetição com consequências
Quando uma ação puder ser repetida, aplique custos, retornos decrescentes, desgaste ou outras consequências apropriadas.

### 373. Ações irreversíveis
Certas decisões, como vender um imóvel ou abandonar um emprego, devem ter consequências persistentes.

### 374. Confirmação de ações importantes
Compras caras, mudanças de país, casamentos, divórcios e decisões irreversíveis devem solicitar confirmação quando necessário.

### 375. Feedback econômico
Sempre exiba valores financeiros na moeda correta, identificando receitas, despesas e mudanças patrimoniais.

### 376. Histórico de relacionamentos
Permita consultar acontecimentos relevantes associados a cada pessoa, inclusive eventos de anos anteriores.

### 377. Interface responsiva
O jogo deve funcionar adequadamente em telas pequenas e grandes, sem menus inacessíveis ou sobreposições.

### 378. Personalização visual
Inclua configurações de tema, tamanho da fonte, idioma e preferências de acessibilidade.

### 379. Salvamento acessível
O progresso deve ser preservado regularmente e não depender de operações ocultas frágeis.

### 380. Identidade visual original
Crie uma identidade própria para o jogo, mantendo familiaridade de navegação com simuladores de vida, mas evitando copiar fielmente elementos visuais protegidos.

---

# PARTE 20 — QUALIDADE, BALANCEAMENTO, IMPLEMENTAÇÃO E EXPANSÃO

### 381. Diagnóstico inicial
Faça um levantamento do que existe, do que falta e do que apresenta bugs antes de iniciar alterações.

### 382. Plano de implementação
Separe os requisitos em sistemas, dependências, prioridades e entregas verificáveis.

### 383. Implementação incremental
Faça alterações em etapas que possam ser testadas, sem substituir a aplicação por versões incompletas.

### 384. Testes de criação de personagem
Verifique combinações de países, famílias, atributos, nomes e condições iniciais.

### 385. Testes de envelhecimento
Simule vidas inteiras para detectar erros de progressão, doenças, relações e acontecimentos anuais.

### 386. Testes financeiros
Verifique salários, impostos, compras, vendas, financiamento, patrimônio, aluguel, heranças e conversão monetária.

### 387. Testes de relacionamentos
Confirme limites de interação, continuidade dos NPCs, memória relacional e mudanças familiares.

### 388. Testes profissionais
Garanta que cargos exijam qualificações coerentes e que promoções, salários e demissões funcionem corretamente.

### 389. Testes de imigração
Verifique mudança de país, moeda, salário, custo de vida, propriedades no exterior e condições migratórias.

### 390. Testes de patrimônio
Confirme que imóveis, veículos, colecionáveis e empresas não sejam duplicados, perdidos ou avaliados incorretamente.

### 391. Testes de salvamento
Salve e recarregue vidas em diferentes fases, verificando continuidade integral dos dados.

### 392. Balanceamento de probabilidades
Evite eventos impossíveis frequentes, sucesso garantido por repetição e consequências extremas sem justificativa.

### 393. Balanceamento econômico
Não permita inflação descontrolada, riqueza infinita por bugs, salários irreais ou oportunidades de arbitragem sem custos.

### 394. Balanceamento social
Relacionamentos devem se desenvolver gradualmente e possuir limites, memória e personalidade.

### 395. Diversidade narrativa
Crie bancos extensos de eventos com variações de personagens, lugares, escolhas e resultados.

### 396. Sistema de conquistas
Inclua conquistas por profissões, patrimônio, família, viagens, desafios, sobrevivência e acontecimentos especiais.

### 397. Desafios de vida
Permita objetivos opcionais como formar-se em medicina, construir uma empresa bilionária ou completar uma carreira esportiva.

### 398. Estatísticas globais do jogador
Registre vidas concluídas, profissões exercidas, riqueza máxima, gerações, conquistas e diferentes trajetórias.

### 399. Expansibilidade permanente
Permita incluir novos países, profissões, imóveis, eventos e atividades por meio de estruturas de dados, sem reprogramar todo o simulador.

### 400. Critério final de conclusão
A versão 4.0 só poderá ser considerada concluída quando os sistemas prioritários estiverem integrados, testados, persistentes e jogáveis. Todo requisito pendente deve ser informado claramente, sem simular uma implementação inexistente.

---

# INSTRUÇÕES ADICIONAIS PARA IMPLEMENTAÇÃO

Os requisitos anteriores definem o escopo principal. As instruções seguintes determinam como desenvolver corretamente o jogo.

## A. MODELO DE DADOS E DEPENDÊNCIAS

Crie um modelo persistente e tipado, adaptado à tecnologia do projeto, contendo pelo menos:

- `Player`: identidade, atributos, idade, saúde, localização e estado atual.
- `Person`: dados de NPCs, características, histórico e situação pessoal.
- `Relationship`: participantes, natureza, intensidade, confiança e acontecimentos.
- `Family`: parentesco, guarda, casamento, descendência e sucessão.
- `EducationRecord`: instituições, cursos, notas, diplomas e qualificações.
- `Job`: profissão, cargo, empregador, salário, condições e desempenho.
- `Career`: experiência, habilidades, progressão e eventos profissionais.
- `BankAccount`: instituição, moeda, saldo e movimentações.
- `Asset`: tipo de bem, proprietário, localização, valor e estado.
- `Property`: imóvel, aluguel, financiamento, manutenção e valorização.
- `Vehicle`: marca, modelo, ano, condição, custo e titularidade.
- `Investment`: classe, quantidade, preço, risco e retorno.
- `Business`: setor, capital, funcionários, resultados e participação.
- `LegalCase`: natureza, envolvidos, andamento e consequência.
- `World`: países, cidades, regiões, moedas, economia e regras.
- `WorldEvent`: acontecimentos econômicos, culturais e sociais.
- `LifeEvent`: evento ocorrido, data, participantes, efeitos e escolhas.
- `ActionHistory`: ações realizadas, limites, resultados e período.
- `Achievement`: objetivos, requisitos, progresso e conclusão.
- `SaveGame`: versão do esquema, estado completo e informações de migração.

Essas entidades devem ser relacionadas por identificadores estáveis, não apenas por nomes exibidos na interface.

## B. ORDEM DO AVANÇO ANUAL

O mecanismo de envelhecimento deve seguir uma sequência consistente:

1. Validar e encerrar as atividades do ano atual.
2. Atualizar idade, ano e condições temporais.
3. Processar despesas, receitas e movimentações financeiras.
4. Atualizar empregos, desempenho e progressões.
5. Atualizar empresas, investimentos e propriedades.
6. Evoluir NPCs, relacionamentos e acontecimentos familiares.
7. Processar educação, saúde e condições de vida.
8. Resolver acontecimentos nacionais e locais relevantes.
9. Gerar eventos aleatórios condicionados pelo estado do mundo.
10. Identificar situações que exigem escolhas do jogador.
11. Registrar os resultados no histórico.
12. Verificar condições de falecimento e sucessão.
13. Persistir integralmente o estado atualizado.

Evite processar duas vezes o mesmo custo ou acontecimento.

## C. REGRAS DE IMERSÃO E REALISMO

O mundo deve parecer conectado.

**Exemplo 1 — Imóveis:** um jogador nascido no Brasil pode comprar uma residência econômica em uma cidade pequena, um apartamento em São Paulo ou uma propriedade de luxo no litoral. As opções precisam refletir diferenças reais de categoria, localização e custo, usando valores de referência configuráveis.

**Exemplo 2 — Imigração:** um jogador que possui R$ 500.000 no Brasil e muda para os Estados Unidos deve passar a visualizar seu dinheiro em dólares por uma conversão cambial adequada. Não pode simplesmente aparecer com US$ 500.000.

**Exemplo 3 — Carreira:** o jogador não pode tornar-se médico especialista sem formação. Entretanto, pode entrar na universidade depois de anos trabalhando em outra profissão e construir uma segunda carreira.

**Exemplo 4 — Relacionamentos:** conversar cem vezes com uma pessoa no mesmo ano não deve aumentar cem vezes a relação. Os benefícios devem obedecer a limites anuais ou retornos decrescentes.

**Exemplo 5 — Vida noturna:** ao sair para uma balada, o personagem pode conhecer alguém, gastar dinheiro, se divertir, discutir ou simplesmente voltar para casa. Nem todas as saídas precisam produzir eventos extraordinários.

**Exemplo 6 — Cassino:** apostas devem possuir regras matemáticas, saldo fictício e resultados persistentes. Não podem gerar prêmios arbitrários ou lucro garantido.

**Exemplo 7 — Família:** um filho que nasce na vida de um personagem precisa crescer, desenvolver personalidade, estudar, trabalhar e possivelmente formar sua própria família, mesmo que o jogador escolha não interagir constantemente.

**Exemplo 8 — Empresas:** uma empresa com prejuízos recorrentes não pode crescer indefinidamente sem financiamento ou justificativa econômica.

## D. PROFISSÕES QUE DEVEM EXISTIR NO CATÁLOGO

Além das carreiras especiais, implemente um catálogo amplo, incluindo, no mínimo, as seguintes opções e suas progressões quando apropriado:

**Saúde:** médico clínico, cirurgião, cardiologista, pediatra, neurologista, dermatologista, psiquiatra, oncologista, anestesista, ortopedista, ginecologista, radiologista, dentista, ortodontista, enfermeiro, técnico de enfermagem, farmacêutico, biomédico, fisioterapeuta, nutricionista, fonoaudiólogo, psicólogo, terapeuta ocupacional, veterinário, paramédico, socorrista, parteira, pesquisador clínico e técnico de laboratório.

**Direito e governo:** advogado, promotor, juiz, defensor público, procurador, delegado, policial civil, policial militar, policial federal, agente penitenciário, diplomata, auditor fiscal, analista legislativo, oficial de justiça, servidor público, agente administrativo, prefeito, vereador, deputado, senador, governador e presidente.

**Educação:** professor infantil, professor fundamental, professor de matemática, professor de história, professor de ciências, professor de idiomas, professor universitário, tutor, pesquisador acadêmico, coordenador pedagógico, orientador educacional, diretor escolar, bibliotecário, pedagogo e reitor.

**Tecnologia:** programador, desenvolvedor web, desenvolvedor mobile, engenheiro de software, desenvolvedor de jogos, designer de jogos, analista de sistemas, administrador de redes, especialista em segurança da informação, engenheiro de dados, cientista de dados, analista de dados, pesquisador de IA, engenheiro de machine learning, administrador de banco de dados, designer UX, designer UI, analista de suporte, gerente de produto e diretor de tecnologia.

**Engenharia e construção:** engenheiro civil, arquiteto, engenheiro mecânico, engenheiro elétrico, engenheiro químico, engenheiro de produção, engenheiro ambiental, engenheiro de petróleo, engenheiro aeronáutico, engenheiro de segurança, técnico em edificações, mestre de obras, pedreiro, carpinteiro, eletricista, encanador, pintor, soldador e operador de máquinas.

**Mercado imobiliário:** corretor de imóveis, avaliador imobiliário, administrador de locações, captador de imóveis, consultor imobiliário, gestor de patrimônio, incorporador, construtor, investidor imobiliário, gestor de condomínios e diretor de imobiliária.

**Finanças e negócios:** contador, economista, bancário, gerente bancário, analista financeiro, consultor financeiro, planejador financeiro, auditor, corretor de seguros, corretor de investimentos, analista de mercado, gestor de fundos, consultor empresarial, gerente comercial, diretor financeiro e diretor executivo.

**Comércio e serviços:** vendedor, caixa, estoquista, gerente de loja, recepcionista, atendente, operador de telemarketing, representante comercial, cabeleireiro, barbeiro, manicure, esteticista, massoterapeuta, personal trainer, instrutor esportivo, fotógrafo, mecânico, eletricista automotivo, motorista de aplicativo, entregador e auxiliar administrativo.

**Hotelaria e gastronomia:** cozinheiro, chef de cozinha, confeiteiro, padeiro, pizzaiolo, garçom, bartender, barista, gerente de restaurante, sommelier, recepcionista de hotel, concierge, guia turístico, agente de viagens, comissário de bordo e gerente de hotel.

**Transportes e logística:** motorista de ônibus, caminhoneiro, taxista, piloto comercial, copiloto, controlador de tráfego aéreo, maquinista, marinheiro, comandante de navio, operador portuário, gestor de logística, despachante, agente aeroportuário e mecânico aeronáutico.

**Artes e mídia:** escritor, jornalista, repórter, apresentador, ator, cantor, compositor, produtor musical, diretor de cinema, roteirista, editor de vídeo, cinegrafista, fotógrafo, designer gráfico, ilustrador, pintor artístico, escultor, DJ, humorista, dublador, locutor, influenciador digital e produtor de conteúdo.

**Segurança e emergência:** bombeiro, guarda municipal, segurança privado, investigador, detetive particular, perito criminal, salva-vidas, socorrista, agente de trânsito e profissional de resgate.

**Agropecuária e meio ambiente:** agricultor, agrônomo, pecuarista, zootecnista, biólogo, oceanógrafo, geólogo, engenheiro florestal, guarda-parque, técnico ambiental, pescador profissional e gestor de fazenda.

**Ciência e pesquisa:** físico, químico, matemático, astrônomo, geneticista, pesquisador, microbiologista, arqueólogo, historiador, antropólogo, sociólogo e cientista ambiental.

**Ocupações de entrada e outras atividades:** auxiliar de limpeza, cuidador, babá, jardineiro, porteiro, frentista, lavador de carros, assistente de cozinha, operador de caixa, trabalhador rural, auxiliar de depósito, vendedor ambulante, músico de rua e profissional autônomo.

Cada profissão deve possuir requisitos, faixas salariais, cargos, possibilidades de promoção e ao menos um conjunto de eventos característicos.

Não considere o catálogo completo apenas porque os nomes aparecem na tela. Cada carreira precisa ser acessível e funcional.

## E. RECURSOS ESPECIAIS GRATUITOS

Inclua, como parte nativa do jogo:

- Editor avançado de personagens.
- Controle opcional de atributos na criação.
- Escolha de talentos e características iniciais.
- Carreiras especiais.
- Administração de empresas.
- Sistema avançado de investimentos.
- Administração de imóveis.
- Cassino virtual.
- Recursos de fama.
- Recursos de realeza.
- Carreiras esportivas.
- Carreiras de entretenimento.
- Sistemas avançados de família.
- Histórico de gerações.
- Opções de personalização visual.
- Salvamentos de múltiplas vidas.
- Ferramentas de testes e modo sandbox opcional.

Não utilize telas de compra real, assinaturas ou anúncios obrigatórios.

## F. SISTEMAS NOVOS PARA SUPERAR O BITLIFE

Além dos 400 requisitos, crie recursos originais que aprofundem o simulador:

**1. Memória social avançada.** NPCs devem lembrar decisões importantes e utilizar essas informações em conversas e eventos futuros.

**2. Mercado imobiliário detalhado.** Diferencie oferta, demanda, bairros, qualidade urbana, imóveis para alugar, terrenos, condomínios e oportunidades de investimento.

**3. Mudança de padrão de vida.** A trajetória de alguém pobre até a riqueza deve refletir alterações graduais em moradia, consumo e círculo social, sem determinismo social.

**4. Relacionamentos com objetivos próprios.** Parceiros podem querer filhos, viagens, mudança de país, estabilidade ou crescimento profissional.

**5. Cidades economicamente dinâmicas.** Uma cidade pode passar por crescimento imobiliário, fechamento de indústrias ou expansão tecnológica.

**6. Empresas familiares reais.** Filhos podem participar da administração, discordar de decisões ou assumir negócios herdados.

**7. Crises financeiras pessoais.** Um personagem pode enfrentar desemprego, separação e dívidas simultaneamente, precisando reorganizar suas finanças.

**8. Decisões de carreira com custos de oportunidade.** Estudar medicina durante muitos anos pode gerar ganhos futuros, mas exigir sacrifícios financeiros e tempo.

**9. Possibilidade de vidas comuns interessantes.** O jogo não deve depender exclusivamente de riqueza, crimes ou fama. Construir uma família, trabalhar e envelhecer pode produzir histórias igualmente envolventes.

**10. Histórias pessoais emergentes.** O sistema deve combinar eventos e decisões para criar histórias imprevisíveis, sem depender apenas de textos escritos manualmente para cada combinação possível.

## G. PROTOCOLO DE IMPLEMENTAÇÃO PARA A IA

Ao receber este prompt, siga a sequência:

1. Leia os arquivos do projeto que estiverem disponíveis.
2. Identifique a tecnologia, estrutura e sistemas existentes.
3. Produza uma matriz de cobertura dos requisitos 001 a 400, marcando cada um como implementado, parcial, ausente ou não verificável.
4. Identifique bugs e problemas de integração que impeçam novas funcionalidades.
5. Defina dependências entre sistemas.
6. Priorize primeiro o motor do jogo, persistência, mundo, economia e personagens.
7. Implemente os sistemas em módulos pequenos e verificáveis.
8. Crie as telas necessárias para utilizar as funções implementadas.
9. Integre os módulos ao estado central.
10. Execute testes automáticos sempre que possível.
11. Faça testes de vidas completas e de salvamento.
12. Preserve compatibilidade com o progresso existente.
13. Registre arquivos alterados e funcionalidades concluídas.
14. Informe exatamente os requisitos ainda pendentes.
15. Continue pelos próximos requisitos conforme os recursos e o contexto disponíveis, sem declarar a versão completa prematuramente.

Se você não possuir acesso ao código ou aos arquivos necessários, peça o material específico. Não invente resultados de testes nem afirme que funções foram implementadas apenas por terem sido descritas.

Se houver limites de contexto, processamento ou tamanho da resposta, divida a implementação em etapas independentes e mantenha um registro de continuidade, para que outro turno possa prosseguir sem recomeçar o projeto.

## H. CRITÉRIOS DE ACEITAÇÃO

Cada sistema implementado deve passar pelos seguintes critérios:

- O jogador consegue encontrar a funcionalidade na interface.
- A funcionalidade oferece ações reais, não apenas elementos visuais.
- Os pré-requisitos são verificados.
- Custos e recompensas são calculados corretamente.
- As consequências são aplicadas ao estado central.
- A alteração aparece no histórico quando relevante.
- O progresso permanece correto após salvar e recarregar.
- A função respeita idade, país, contexto e limitações.
- A função interage com os demais sistemas que dependem dela.
- Existem testes para fluxos normais, casos extremos e condições inválidas.
- A experiência faz sentido para o jogador.
- A funcionalidade não remove ou quebra recursos anteriores.

## I. OBJETIVO FINAL DA VERSÃO 4.0

Quero que uma única vida consiga produzir dezenas de horas de experiências diferentes.

Quero que nascer no Brasil seja diferente de nascer nos Estados Unidos, que morar em uma mansão seja diferente de morar de aluguel, que trabalhar como médico seja diferente de trabalhar como ator e que administrar uma empresa seja diferente de simplesmente receber salário.

Quero profissões variadas, bens detalhados, relações humanas complexas, países coerentes, acontecimentos únicos e consequências reais.

**Profundidade é mais importante que quantidade superficial.** Ter 300 opções que realmente funcionam é melhor que apresentar 3.000 nomes que levam à mesma ação.

A implementação deve buscar tanto amplitude quanto qualidade, com prioridade para sistemas conectados, testáveis e expansíveis.

Não quero uma demonstração visual do que o simulador poderia ser.

**QUERO O JOGO EXISTENTE EVOLUINDO PARA UM SIMULADOR DE VIDA COMPLETO, FUNCIONAL, ORIGINAL, COESO E PROFUNDO.**

Comece auditando o projeto atual, apresente a matriz de cobertura e então implemente o primeiro conjunto de funcionalidades de maior impacto, com código real, testes e preservação dos sistemas existentes.