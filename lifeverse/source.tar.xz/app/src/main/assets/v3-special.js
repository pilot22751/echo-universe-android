/* Oficinas profissionais: sistemas próprios para profissões criativas, científicas e esportivas. */
'use strict';
const V3_SPECIAL_TRACKS=[
 ['cinema','🎬 Cinema','Audições, contratos, filmagens, críticas e prêmios'],
 ['musica','🎵 Música','Composição, lançamentos, fãs, turnês e direitos autorais simulados'],
 ['esporte','🏅 Esporte','Treino, temporadas, lesões, competições e patrocínio'],
 ['ciencia','🧪 Ciência','Pesquisa com duração, publicações e reconhecimento'],
 ['criador','📹 Conteúdo','Publicações, seguidores, patrocínio e reputação'],
 ['chef','🍲 Gastronomia','Receitas, avaliações, festivais e evolução de reputação'],
 ['jogos','🕹️ Estúdio de jogos','Protótipos, orçamento, lançamento, vendas e atualizações']
];
function v3SpecialInit(){if(!S?.v3)return;S.v3.special=S.v3.special||{};const all=S.v3.special;for(const [k]of V3_SPECIAL_TRACKS){if(!all[k])all[k]={skill:0,reputation:0,fans:0,projects:[],released:[],awards:0,revenue:0,lastResult:'Nenhum projeto concluído',followers:0};}return all;}
function v3TrackAllowed(track){if(!S?.alive)return 'Sua vida precisa estar ativa.';const age=S.age,j=S.job?.name||'';
 if(track==='cinema'&&age<16)return 'A partir dos 16 anos.';
 if(track==='musica'&&age<15)return 'A partir dos 15 anos.';
 if(track==='esporte'&&age<12)return 'A partir dos 12 anos.';
 if(track==='ciencia'&&!(S.job?.sector==='Ciências'||S.education.level>=1&&S.skills['Ciências']>=35))return 'É necessário formação científica ou trabalhar em pesquisa.';
 if(track==='criador'&&age<13)return 'A partir dos 13 anos.';
 if(track==='chef'&&age<16)return 'A partir dos 16 anos.';
 if(track==='jogos'&&age<16)return 'A partir dos 16 anos.';
 return '';
}
function v3SpecialActions(track){switch(track){
 case 'cinema':return [{id:'aula',label:'Estudar interpretação',cost:200,energy:12},{id:'audicao',label:'Fazer teste de elenco',cost:0,energy:15},{id:'filmar',label:'Gravar filme contratado',cost:0,energy:22}];
 case 'musica':return [{id:'treino',label:'Ensaiar música',cost:100,energy:12},{id:'single',label:'Produzir single',cost:1200,energy:20},{id:'turne',label:'Realizar show',cost:2500,energy:20}];
 case 'esporte':return [{id:'treino',label:'Treinar modalidade',cost:250,energy:15},{id:'torneio',label:'Participar de torneio',cost:420,energy:22},{id:'patrocinio',label:'Buscar patrocinador',cost:0,energy:10}];
 case 'ciencia':return [{id:'pesquisa',label:'Iniciar pesquisa',cost:2100,energy:20},{id:'publicar',label:'Publicar resultados',cost:450,energy:18},{id:'patente',label:'Solicitar patente',cost:3200,energy:15}];
 case 'criador':return [{id:'post',label:'Publicar conteúdo',cost:200,energy:12},{id:'colab',label:'Colaboração',cost:1200,energy:15},{id:'patrocinio',label:'Negociar publicidade',cost:0,energy:12}];
 case 'chef':return [{id:'receita',label:'Criar um prato',cost:430,energy:12},{id:'servico',label:'Participar de festival',cost:900,energy:17},{id:'concurso',label:'Disputar competição',cost:1200,energy:19}];
 case 'jogos':return [{id:'prototipo',label:'Desenvolver protótipo',cost:8000,energy:24},{id:'lancar',label:'Lançar jogo pronto',cost:4500,energy:22},{id:'atualizar',label:'Publicar atualização',cost:1800,energy:16}];
 default:return [];
}}
function v3SpecialAction(track,command){if(!requireLife())return;v3SpecialInit();const reason=v3TrackAllowed(track);if(reason){notify(reason,'warn');return;}
 const opts=v3SpecialActions(track),a=opts.find(x=>x.id===command);if(!a)return;
 const v=S.v3.special[track];const key='track_'+track+'_'+command;
 if(!v3Allow(key,'special',command==='treino'?2:1,{cost:a.cost,energy:a.energy,message:'Você já concluiu essa atividade na carreira especial neste ano.'}))return;
 const fail=msg=>{v3RefundLimit(key,'special');notify(msg,'warn');};
 if(command==='filmar'&&!v.projects.some(p=>p.type==='papel'&&p.status==='contracted'))return fail('Você precisa ser selecionado em uma audição primeiro.');
 if(command==='turne'&&v.released.length<2)return fail('Produza pelo menos duas músicas antes de sair em turnê.');
 if(command==='patrocinio'&&track==='esporte'&&v.awards<1)return fail('Ganhe uma competição antes de buscar patrocínio.');
 if(command==='patrocinio'&&track==='criador'&&v.followers<10000)return fail('Você precisa alcançar pelo menos 10 mil seguidores.');
 if(command==='publicar'&&!v.projects.some(p=>p.type==='pesquisa'&&p.due<=S.year))return fail('Conclua pelo menos um projeto de pesquisa antes de publicar.');
 if(command==='patente'&&!v.released.some(x=>x.type==='artigo'))return fail('Publique uma pesquisa antes de solicitar patente.');
 if(command==='concurso'&&v.released.length<3)return fail('Crie pelo menos três receitas antes de participar de um concurso.');
 if(command==='lancar'&&!v.projects.some(p=>p.type==='game'&&p.due<=S.year))return fail('Finalize um protótipo antes de lançar um jogo.');
 if(command==='atualizar'&&!v.released.length)return fail('Você precisa lançar um jogo primeiro.');
 if(!useEnergy(a.energy)){v3RefundLimit(key,'special');return;}if(a.cost)v3Paid(a.cost,track+' · '+command);
 let result='';const stat=n=>v3Clamp(n,0,100);const score=v3Int(-18,16)+v.skill*.35+S.stats.discipline*.25+S.stats.reputation*.16;
 if(track==='cinema'){
  if(command==='aula'){v.skill=stat(v.skill+v3Int(6,11));change('Artes',3);result='Você ensaiou interpretação, voz e expressão corporal.';}
  if(command==='audicao'){const chance=v3Clamp(.19+(S.skills['Artes']||0)*.004+v.skill*.005,.10,.82);if(v3Chance(chance)){const pay=v3Int(2400,18000)*(1+Math.floor(v.reputation/25));v.projects.push({type:'papel',name:v3Pick(['Projeto Aurora','Cena Final','Vidas Cruzadas','Cidade Invisível']),fee:pay,status:'contracted',year:S.year});result='Você conseguiu um papel! Contrato de '+money(pay)+' a receber após filmagem.';}else result='A audição não deu certo. Continue treinando ou busque outro papel.';}
  if(command==='filmar'){const p=v.projects.find(x=>x.type==='papel'&&x.status==='contracted');p.status='completed';p.score=stat(score+v3Int(16,55));S.cash+=p.fee;v.revenue+=p.fee;v.reputation=stat(v.reputation+Math.round((p.score-35)/8));change('fame',Math.max(0,Math.round(p.score/20)));if(p.score>=82&&v3Chance(.26)){v.awards++;S.counts.trophies++;}v.released.push(p);result='Filmagem concluída. Crítica: '+p.score+'/100; cachê '+money(p.fee)+'.';}
 }
 if(track==='musica'){
  if(command==='treino'){v.skill=stat(v.skill+v3Int(4,9));change('Música',4);result='Treino vocal e instrumental concluído.';}
  if(command==='single'){const quality=stat(score+(S.skills['Música']||0)*.35+20);const streams=Math.round((20+quality*18)*(1+v.fans/900));const paid=Math.round(streams*.09);v.fans+=Math.round(streams/20);v.released.push({type:'single',year:S.year,quality,streams,royalty:Math.round(streams*.018),lastPaid:S.year});S.cash+=paid;v.revenue+=paid;change('fame',quality>70?2:0);result='Single lançado: '+streams+' streams fictícios e '+money(paid)+' de receita inicial.';}
  if(command==='turne'){const attendance=Math.round(v.fans*.18+v3Int(50,600));const earnings=Math.max(0,Math.round(attendance*5-a.cost));S.cash+=earnings;v.revenue+=earnings;change('stress',8);change('health',-3);result='Show para '+attendance+' pessoas. Resultado adicional: '+money(earnings)+'.';}
 }
 if(track==='esporte'){
  if(command==='treino'){const gain=v3Int(3,8);v.skill=stat(v.skill+gain);change('Esportes',3);change('health',1);result='Você treinou técnica e preparo físico.';}
  if(command==='torneio'){const performance=stat(score+v.skill*.32+S.skills['Esportes']*.35-(S.age>38?(S.age-38)*1.5:0));const win=v3Chance(v3Clamp(performance/140,.06,.77));v.projects.push({type:'torneio',year:S.year,performance,win});if(win){const prize=v3Int(1000,7500);S.cash+=prize;v.revenue+=prize;v.awards++;S.counts.trophies++;change('fame',3);result='Você conquistou um título e ganhou '+money(prize)+'!';}else result='O torneio terminou sem título. Desempenho '+performance+'/100.';if(v3Chance(.08+(S.age>35?.07:0))){change('health',-v3Int(4,10));v.injuries=(v.injuries||0)+1;result+=' Uma lesão exige recuperação.';}}
  if(command==='patrocinio'){const paid=Math.round(1200+v.awards*500+v.reputation*25);S.cash+=paid;v.revenue+=paid;result='Patrocínio temporário firmado: '+money(paid)+'. Não é renda garantida no próximo ano.';}
 }
 if(track==='ciencia'){
  if(command==='pesquisa'){const topic=v3Pick(['Energia limpa','Tecnologia assistiva','Materiais inteligentes','Proteção ambiental','Saúde pública','Exploração espacial']);v.projects.push({type:'pesquisa',topic,due:S.year+v3Int(1,3),year:S.year,status:'ongoing'});result='Pesquisa iniciada: '+topic+'. Resultados disponíveis em anos futuros.';}
  if(command==='publicar'){const p=v.projects.find(x=>x.type==='pesquisa'&&x.due<=S.year);p.status='published';v.projects=v.projects.filter(x=>x!==p);const quality=stat(score+S.skills['Ciências']*.38);v.released.push({type:'artigo',year:S.year,topic:p.topic,quality});v.reputation=stat(v.reputation+Math.max(1,Math.round(quality/13)));change('Ciências',3);result='Artigo publicado sobre '+p.topic+'. Avaliação '+quality+'/100.';}
  if(command==='patente'){const chance=v3Clamp(.12+v.reputation/200+(S.skills['Ciências']||0)/350,.08,.7);if(v3Chance(chance)){v.awards++;const proceeds=v3Int(4000,18000);S.cash+=proceeds;v.revenue+=proceeds;result='Pedido de patente aprovado na simulação; licenciamento de '+money(proceeds)+'.';}else result='O pedido de patente foi recusado após análise.';}
 }
 if(track==='criador'){
  if(command==='post'){const quality=stat(score+S.skills['Comunicação']*.25);const reach=Math.max(20,Math.round((quality+10)*v3Int(12,85)*(1+v.followers/120000)));const gained=Math.round(reach*(.02+v3Rand()*.07));v.followers+=gained;v.released.push({type:'post',year:S.year,reach,gained});result='Publicação teve '+reach+' visualizações e trouxe '+gained+' seguidores.';}
  if(command==='colab'){const gained=Math.round(v3Int(120,950)*(1+v.followers/18000));v.followers+=gained;change('Comunicação',3);result='Colaboração trouxe '+gained+' seguidores; o custo da produção foi pago.';}
  if(command==='patrocinio'){const chance=v3Clamp(.35+v.reputation/300,.15,.75);if(v3Chance(chance)){const pay=Math.round(v.followers*.017);S.cash+=pay;v.revenue+=pay;result='Contrato de publicidade fechado: '+money(pay)+'.';}else result='A marca recusou a proposta. Crescimento e reputação importam.';}
 }
 if(track==='chef'){
  if(command==='receita'){const rating=stat(score+(S.skills['Criatividade']||0)*.40+v3Int(15,35));v.released.push({type:'prato',year:S.year,rating});v.skill=stat(v.skill+v3Int(3,8));result='Nova receita criada e testada: avaliação '+rating+'/100.';}
  if(command==='servico'){const rating=v.released.length?Math.round(v.released.reduce((n,r)=>n+(r.rating||45),0)/v.released.length):40;const fans=v3Int(80,400);const profit=Math.round((rating/100)*fans*9-500);if(profit<0&&S.cash+profit<0){S.debt+=-(S.cash+profit);S.cash=0;}else S.cash+=profit;v.revenue+=profit;v.fans+=Math.round(fans/4);result='Festival com '+fans+' visitantes. Resultado líquido '+money(profit)+'.';}
  if(command==='concurso'){const average=Math.round(v.released.reduce((n,r)=>n+(r.rating||0),0)/v.released.length);const success=v3Chance(v3Clamp(average/140,.1,.75));if(success){v.awards++;S.counts.trophies++;v.reputation=stat(v.reputation+7);result='Seu prato venceu a competição!';}else result='Sua receita não venceu, mas ganhou feedback dos jurados.';}
 }
 if(track==='jogos'){
  if(command==='prototipo'){const title=v3Pick(['Horizonte Pixel','Reinos de Aurora','Noite em Órbita','Dias de Verão','Táticas da Cidade']);const quality=stat(score+(S.skills['Tecnologia']||0)*.38+v3Int(15,35));v.projects.push({type:'game',title,quality,due:S.year+v3Int(1,3),cost:a.cost});result='Protótipo de '+title+' começou. Será concluído em um a três anos.';}
  if(command==='lancar'){const p=v.projects.find(x=>x.type==='game'&&x.due<=S.year);p.type='released';const reviews=stat(p.quality+v3Int(-19,17));const sales=Math.max(0,Math.round(reviews*reviews*v3Int(6,16)/4));const gross=Math.round(sales*5),net=Math.round(gross*.54);S.cash+=net;v.revenue+=net;v.released.push({...p,year:S.year,reviews,sales});v.projects=v.projects.filter(x=>x!==p);v.reputation=stat(v.reputation+Math.round((reviews-45)/9));result=p.title+' lançado: nota '+reviews+'/100, '+sales+' cópias e '+money(net)+' após custos e taxas.';}
  if(command==='atualizar'){const latest=v.released.at(-1);latest.reviews=stat(latest.reviews+v3Int(0,8));const sales=Math.round(latest.sales*.09*v3Rand());const cash=Math.round(sales*2);S.cash+=cash;v.revenue+=cash;result='Atualização lançada para '+latest.title+'. Novas vendas: '+sales+', receita '+money(cash)+'.';}
 }
 v.lastResult=result;logStory(V3_SPECIAL_TRACKS.find(x=>x[0]===track)?.[2]+': '+result,'work');save();render();openInfo('Carreira especial · '+track,result);
}
function v3SpecialAnnual(){v3SpecialInit();const music=S.v3.special.musica;for(const track of music.released.filter(x=>x.royalty>0&&x.lastPaid<S.year)){const years=S.year-track.year;const proceeds=Math.max(0,Math.round(track.royalty*Math.pow(.72,years)));S.cash+=proceeds;music.revenue+=proceeds;track.lastPaid=S.year;}
 for(const [key,v]of Object.entries(S.v3.special)){if(key==='criador'&&v.followers>0){v.followers=Math.max(0,Math.round(v.followers*(.98+v3Rand()*.022)));}if(key==='esporte'&&S.age>35)v.skill=Math.max(0,v.skill-(S.age-35)*.35);}
}
function v3SpecialView(){v3SpecialInit();return v3Box('⭐ Carreiras especiais com projetos',`<p class="muted">Módulos originais com requisitos, custos, riscos, estados persistentes e decisões em vários anos. Algumas ainda são protótipos de carreira, não simuladores completos de uma indústria inteira.</p>`)+V3_SPECIAL_TRACKS.map(([key,title,desc])=>{const v=S.v3.special[key],reason=v3TrackAllowed(key),opts=v3SpecialActions(key);return v3Box(title,`<p class="muted">${escapeHTML(desc)}</p><div class="v3-statrow">${v3Metric('Experiência',Math.round(v.skill))}${v3Metric(key==='criador'?'Seguidores':'Fãs',key==='criador'?v.followers:v.fans)}${v3Metric('Projetos',v.projects.length)}${v3Metric('Lançamentos',v.released.length)}${v3Metric('Reconhecimentos',v.awards)}${v3Metric('Receita acumulada',shortMoney(v.revenue))}</div>${reason?`<p class="v3-no">⚠ ${escapeHTML(reason)}</p>`:''}<div class="v3-flex">${opts.map(a=>button(a.label+(a.cost?' · '+shortMoney(a.cost):''),'v3Special',key+'|'+a.id,'small',!!reason)).join('')}</div>${v.projects.length?`<p class="muted">Em andamento: ${v.projects.slice(-3).map(x=>escapeHTML(x.title||x.topic||x.name||'Projeto')+' ('+(x.due||x.year)+')').join(' · ')}</p>`:''}<p class="muted">${escapeHTML(v.lastResult)}</p>`);}).join('');}
V2_NAV.push(['especiais3','Especiais']);
V3_PAGES.especiais3=v3SpecialView;
