/* VIDAVERSO: catalogos de simulacao originais. Nao afiliado a outros jogos. */
const DB={
 namesM:['Lucas','Arthur','Miguel','Pedro','Gabriel','Rafael','Enzo','João','Theo','Davi','Caio','Mateus','Bruno','Leonardo','Guilherme','Samuel','Henrique','Felipe','Heitor','Daniel','Murilo','Antônio','Lorenzo','Noah','Vicente','Benjamin','Eduardo','Ian','Yuri','Oliver'],
 namesF:['Alice','Helena','Laura','Valentina','Sofia','Cecília','Isabela','Luna','Heloísa','Manuela','Beatriz','Júlia','Ana','Elisa','Luiza','Marina','Clara','Lívia','Rafaela','Gabriela','Carolina','Giovana','Vitória','Sarah','Bianca','Maya','Lorena','Bruna','Camila','Olívia'],
 surnames:['Silva','Oliveira','Santos','Souza','Costa','Almeida','Pereira','Lima','Ferreira','Rodrigues','Ribeiro','Carvalho','Araújo','Gomes','Martins','Barbosa','Monteiro','Fernandes','Rocha','Cardoso','Melo'],
 countries:[['Brasil','São Paulo','BRL',1],['Portugal','Lisboa','EUR',1.25],['Estados Unidos','Nova York','USD',1.65],['Canadá','Toronto','CAD',1.35],['Japão','Tóquio','JPY',1.42],['Itália','Roma','EUR',1.25],['Reino Unido','Londres','GBP',1.6],['Coreia do Sul','Seul','KRW',1.5],['Argentina','Buenos Aires','ARS',.85],['França','Paris','EUR',1.4],['Alemanha','Berlim','EUR',1.37],['Austrália','Sydney','AUD',1.55],['México','Cidade do México','MXN',.9],['Espanha','Madri','EUR',1.15],['Suíça','Zurique','CHF',2.1]],
 skills:['Comunicação','Criatividade','Tecnologia','Esportes','Artes','Música','Negócios','Política','Liderança','Ciências','Direito','Medicina'],
 jobs:[
 ['Estagiário','Básico',16,0,18000,'Comunicação',0],['Atendente','Básico',16,0,22000,'Comunicação',0],['Caixa','Básico',16,0,25000,'Disciplina',0],['Barista','Básico',18,0,28000,'Criatividade',0],['Motorista','Básico',18,0,33000,'Disciplina',0],['Entregador','Básico',18,0,32000,'Esportes',0],['Garçom','Básico',18,0,30000,'Comunicação',0],['Recepcionista','Básico',18,0,31000,'Comunicação',0],['Auxiliar administrativo','Básico',18,0,34000,'Negócios',0],['Vendedor','Comércio',18,0,41000,'Comunicação',0],['Gerente comercial','Comércio',21,0,73000,'Liderança',20],['Consultor financeiro','Comércio',21,1,90000,'Negócios',25],['Diretor de marketing','Comércio',24,1,130000,'Criatividade',40],['Executivo de vendas','Comércio',22,0,88000,'Comunicação',35],['Analista de logística','Comércio',20,1,67000,'Negócios',15],
 ['Professor','Educação',21,1,63000,'Comunicação',15],['Diretor de escola','Educação',27,1,110000,'Liderança',40],['Pesquisador','Educação',24,1,93000,'Ciências',35],['Professor universitário','Educação',28,2,160000,'Ciências',45],['Bibliotecário','Educação',20,1,52000,'Comunicação',10],
 ['Programador','Tecnologia',18,0,75000,'Tecnologia',15],['Engenheiro de software','Tecnologia',21,1,140000,'Tecnologia',30],['Analista de cibersegurança','Tecnologia',22,1,135000,'Tecnologia',40],['Cientista de dados','Tecnologia',22,1,152000,'Tecnologia',35],['Designer de jogos','Tecnologia',18,0,84000,'Criatividade',25],['Diretor de tecnologia','Tecnologia',28,1,245000,'Liderança',55],['Fundador de startup','Tecnologia',18,0,50000,'Negócios',25],
 ['Enfermeiro','Saúde',21,1,82000,'Medicina',20],['Fisioterapeuta','Saúde',21,1,83000,'Medicina',20],['Médico','Saúde',25,2,240000,'Medicina',45],['Cirurgião','Saúde',29,3,380000,'Medicina',65],['Psiquiatra','Saúde',28,3,275000,'Medicina',55],['Dentista','Saúde',23,1,150000,'Medicina',30],['Farmacêutico','Saúde',22,1,102000,'Ciências',25],['Veterinário','Saúde',23,1,125000,'Medicina',30],
 ['Advogado','Justiça',23,1,135000,'Direito',35],['Juiz','Justiça',32,2,285000,'Direito',65],['Promotor','Justiça',29,1,203000,'Direito',55],['Detetive','Justiça',22,0,81000,'Direito',35],['Delegado','Justiça',26,1,160000,'Direito',45],['Perito criminal','Justiça',23,1,120000,'Ciências',35],
 ['Jornalista','Mídia',18,0,59000,'Comunicação',20],['Influenciador','Mídia',16,0,36000,'Comunicação',35],['Roteirista','Mídia',18,0,66000,'Criatividade',25],['Diretor de cinema','Mídia',24,0,185000,'Criatividade',60],['Ator','Celebridades',16,0,74000,'Artes',35],['Cantor','Celebridades',16,0,73000,'Música',35],['Produtor musical','Celebridades',18,0,110000,'Música',35],['Modelo','Celebridades',16,0,64000,'Artes',25],['Comediante','Celebridades',18,0,71000,'Comunicação',30],['Escritor','Celebridades',18,0,55000,'Criatividade',20],
 ['Jogador de futebol','Esportes',16,0,93000,'Esportes',45],['Tenista','Esportes',16,0,102000,'Esportes',45],['Piloto de corrida','Esportes',18,0,132000,'Esportes',55],['Lutador profissional','Esportes',18,0,103000,'Esportes',50],['Treinador','Esportes',21,0,78000,'Esportes',30],['Personal trainer','Esportes',18,0,55000,'Esportes',25],
 ['Militar','Governo',18,0,74000,'Disciplina',25],['Diplomata','Governo',25,1,145000,'Política',45],['Vereador','Governo',21,0,100000,'Política',35],['Deputado','Governo',25,0,230000,'Política',55],['Prefeito','Governo',25,0,215000,'Política',55],['Governador','Governo',30,0,320000,'Política',68],['Presidente','Governo',35,0,510000,'Política',82],
 ['Engenheiro civil','Ciências',22,1,125000,'Ciências',30],['Arquiteto','Ciências',22,1,118000,'Criatividade',28],['Biólogo','Ciências',21,1,87000,'Ciências',25],['Astronauta','Ciências',28,2,295000,'Ciências',72],['Piloto de avião','Ciências',23,1,177000,'Ciências',45],['Cientista climático','Ciências',23,1,112000,'Ciências',30],['Inventor','Ciências',20,0,100000,'Criatividade',30],
 ['Chef de cozinha','Criatividade',18,0,66000,'Criatividade',25],['Dono de restaurante','Criatividade',18,0,85000,'Negócios',30],['Estilista','Criatividade',18,0,93000,'Criatividade',35],['Fotógrafo','Criatividade',18,0,59000,'Artes',20],['Designer','Criatividade',18,0,78000,'Criatividade',30],['Artista plástico','Criatividade',18,0,48000,'Artes',25],
 ],
 degrees:['Administração','Direito','Medicina','Engenharia','Ciência da Computação','Psicologia','Design','Comunicação','Música','Artes Cênicas','História','Biologia','Educação Física','Economia','Ciência Política','Relações Internacionais','Arquitetura','Jornalismo','Pedagogia'],
 property:[['Kitnet',65000,900,1],['Apartamento',190000,1800,2],['Casa pequena',260000,2200,3],['Casa de família',450000,3200,4],['Cobertura',900000,4900,6],['Mansão',2500000,12500,10],['Fazenda',1900000,10000,8],['Ilha particular',6500000,35000,15],['Prédio comercial',3200000,27000,12],['Castelo',8000000,44000,16]],
 vehicles:[['Bicicleta',750,0],['Motocicleta',9000,700],['Carro usado',23000,1500],['Carro novo',80000,2500],['Carro de luxo',280000,8200],['Superesportivo',1500000,26000],['Iate',2800000,100000],['Jato particular',12000000,400000],['Helicóptero',3500000,130000]],
 ventures:[['Cafeteria',18000,8000,0.15],['Loja de roupas',35000,16000,.16],['Estúdio de jogos',60000,26000,.20],['Restaurante',100000,42000,.15],['Academia',125000,50000,.19],['Agência de marketing',25000,14000,.22],['Produtora musical',55000,22000,.22],['Imobiliária',120000,40000,.18],['Clínica médica',450000,120000,.21],['Fábrica',700000,250000,.17],['Fintech',1000000,420000,.22],['Estúdio de cinema',1200000,540000,.17],['Companhia aérea',5000000,1900000,.15],['Rede de hotéis',3000000,1250000,.19]],
 pets:['Cachorro','Gato','Coelho','Papagaio','Hamster','Tartaruga','Cavalo'],
 hobbies:['Xadrez','Desenho','Corrida','Canto','Instrumento musical','Dança','Fotografia','Videogames','Leitura','Programação','Culinária','Jardinagem','Voluntariado','Cinema','Escalada','Escrita','Surf','Artes marciais'],
 crimes:[['Furto',2500,14,1],['Golpe financeiro',12000,24,2],['Roubo de carro',30000,32,3],['Assalto',75000,42,5],['Fraude corporativa',350000,55,8],['Hackeamento criminoso',95000,37,3],['Tráfico internacional',450000,68,9]],
 experiences:[['Viagem nacional',1500,5,4],['Viagem internacional',8000,12,8],['Festival de música',650,6,5],['Curso de culinária',850,5,3],['Cruzeiro',8500,9,7],['Intercâmbio',24000,14,15],['Retiro na natureza',1200,10,4],['Show ao vivo',320,4,5]],
 challenges:[
 {id:'million',name:'Primeiro milhão',desc:'Alcance um patrimônio de R$ 1 milhão',condition:s=>netWorth(s)>=1000000},
 {id:'billion',name:'Magnata',desc:'Alcance R$ 1 bilhão',condition:s=>netWorth(s)>=1000000000},
 {id:'doctor',name:'Jaleco brilhante',desc:'Torne-se médico',condition:s=>/Médico|Cirurgião|Psiquiatra/.test(s.job?.name||'')},
 {id:'president',name:'No topo',desc:'Torne-se presidente',condition:s=>s.job?.name==='Presidente'},
 {id:'astronaut',name:'Entre estrelas',desc:'Torne-se astronauta',condition:s=>s.job?.name==='Astronauta'},
 {id:'family',name:'Família grande',desc:'Tenha pelo menos 4 filhos',condition:s=>s.children.length>=4},
 {id:'love',name:'Amor duradouro',desc:'Mantenha um casamento por 30 anos',condition:s=>s.spouse&&s.spouse.years>=30},
 {id:'business',name:'Empreendedor',desc:'Abra sua primeira empresa',condition:s=>s.businesses.length>=1},
 {id:'empire',name:'Império',desc:'Tenha cinco empresas ao mesmo tempo',condition:s=>s.businesses.length>=5},
 {id:'estate',name:'Proprietário',desc:'Tenha três imóveis',condition:s=>s.homes.length>=3},
 {id:'famous',name:'Ícone cultural',desc:'Chegue a 90 de fama',condition:s=>s.stats.fame>=90},
 {id:'smart',name:'Mente brilhante',desc:'Chegue a 95 de inteligência',condition:s=>s.stats.intel>=95},
 {id:'happy',name:'Vida boa',desc:'Chegue a 100 de felicidade',condition:s=>s.stats.joy>=100},
 {id:'travel',name:'Mochileiro',desc:'Faça 15 viagens',condition:s=>s.counts.trips>=15},
 {id:'friends',name:'Popular',desc:'Tenha 10 amizades',condition:s=>s.friends.length>=10},
 {id:'pets',name:'Arca de Noé',desc:'Adote 5 pets ao longo da vida',condition:s=>s.counts.pets>=5},
 {id:'graduate',name:'Formado',desc:'Conclua a faculdade',condition:s=>s.education.level>=1},
 {id:'master',name:'Especialista',desc:'Conclua pós-graduação',condition:s=>s.education.level>=2},
 {id:'doctorate',name:'Doutorado',desc:'Conclua doutorado',condition:s=>s.education.level>=3},
 {id:'artist',name:'Estrela da música',desc:'Grave 10 músicas',condition:s=>s.counts.songs>=10},
 {id:'books',name:'Autor prolífico',desc:'Publique 5 livros',condition:s=>s.counts.books>=5},
 {id:'candidate',name:'Campanha histórica',desc:'Vença sua primeira eleição',condition:s=>s.counts.elections>=1},
 {id:'record',name:'Atleta de elite',desc:'Vença 5 competições',condition:s=>s.counts.trophies>=5},
 {id:'crime',name:'Fora da lei',desc:'Cometa um crime no simulador',condition:s=>s.counts.crimes>=1},
 {id:'rebirth',name:'Nova geração',desc:'Continue com seu filho',condition:s=>s.generation>1},
 {id:'longlife',name:'Centenário',desc:'Chegue aos 100 anos',condition:s=>s.age>=100},
 {id:'curious',name:'Aprendiz',desc:'Participe de 20 atividades',condition:s=>s.counts.activities>=20},
 {id:'collector',name:'Colecionador',desc:'Compre 5 veículos',condition:s=>s.vehicles.length>=5},
 {id:'lifesaver',name:'Solidário',desc:'Faça 10 trabalhos voluntários',condition:s=>s.counts.volunteer>=10},
 {id:'hero',name:'Lenda da cidade',desc:'Chegue a 95 de reputação',condition:s=>s.stats.reputation>=95}
 ]
};
function money(n){return 'R$ '+Math.round(n||0).toLocaleString('pt-BR');}
function rnd(min,max){return Math.floor(Math.random()*(max-min+1))+min;}
function pick(a){return a[Math.floor(Math.random()*a.length)];}
function cap(n){return Math.max(0,Math.min(100,Math.round(n)));}
function netWorth(s){return s.cash+(s.investments||[]).reduce((a,v)=>a+v.amount,0)+(s.homes||[]).reduce((a,v)=>a+v.value,0)+(s.vehicles||[]).reduce((a,v)=>a+v.value,0)+(s.businesses||[]).reduce((a,v)=>a+v.value,0)-Math.max(0,s.debt||0);}

// Profissões especiais extras, todas acessíveis sem pagamentos.
DB.jobs.push(
 ['Profissional de eSports','Esportes',16,0,115000,'Tecnologia',35],
 ['Agente esportivo','Esportes',21,1,128000,'Comunicação',38],
 ['Narrador esportivo','Mídia',18,0,76000,'Comunicação',28],
 ['Embaixador cultural','Governo',26,1,132000,'Comunicação',44],
 ['Agente de inteligência','Governo',25,1,155000,'Direito',52],
 ['Policial','Justiça',21,0,86000,'Esportes',30],
 ['Oficial da marinha','Governo',21,1,113000,'Liderança',35],
 ['Bombeiro','Saúde',21,0,79000,'Esportes',35],
 ['Paramédico','Saúde',20,1,74000,'Medicina',25],
 ['Geneticista','Ciências',25,2,173000,'Ciências',53],
 ['Oceanógrafo','Ciências',22,1,121000,'Ciências',30],
 ['Roboticista','Tecnologia',23,1,143000,'Tecnologia',45],
 ['Desenvolvedor de IA','Tecnologia',22,1,187000,'Tecnologia',52],
 ['Programador de robôs','Tecnologia',21,1,135000,'Tecnologia',40],
 ['Pesquisador de foguetes','Ciências',27,2,195000,'Ciências',57],
 ['Arqueólogo','Educação',22,1,97000,'Ciências',30],
 ['Curador de museu','Educação',23,1,88000,'Artes',27],
 ['Roteirista de jogos','Criatividade',18,0,85000,'Criatividade',27],
 ['Dublador','Celebridades',17,0,69000,'Artes',28],
 ['Dançarino profissional','Celebridades',16,0,73000,'Artes',34],
 ['Maestro','Celebridades',25,1,114000,'Música',50],
 ['YouTuber','Mídia',16,0,62000,'Comunicação',30],
 ['Podcaster','Mídia',16,0,49000,'Comunicação',27],
 ['Criador de quadrinhos','Criatividade',18,0,73000,'Criatividade',25],
 ['Astrônomo','Ciências',23,1,125000,'Ciências',32],
 ['Urbanista','Ciências',23,1,117000,'Ciências',31],
 ['Corretor de imóveis','Comércio',18,0,98000,'Negócios',29],
 ['Cientista forense','Justiça',23,1,138000,'Ciências',40],
 ['Defensor público','Justiça',26,1,151000,'Direito',48],
 ['Empresário do entretenimento','Celebridades',22,0,142000,'Negócios',52],
 ['Sommelier','Criatividade',21,0,78000,'Comunicação',25],
 ['Organizador de eventos','Comércio',18,0,81000,'Liderança',25]
);
for(const [group,pairs] of Object.entries({
 voyages:[[3,'Caminhante','Viaje três vezes'],[10,'Mundo aberto','Faça dez viagens'],[30,'Nômade do mundo','Faça trinta viagens']],
 songs:[[3,'Primeiras notas','Lance três músicas'],[20,'Discografia','Lance vinte músicas'],[50,'Lenda musical','Lance cinquenta músicas']],
 books:[[1,'Primeiro autor','Publique um livro'],[15,'Biblioteca pessoal','Publique quinze livros']],
 activities:[[50,'Explorador constante','Faça cinquenta atividades'],[150,'Vida em movimento','Faça 150 atividades'],[500,'Um ano nunca é suficiente','Faça quinhentas atividades']],
 trophies:[[1,'O primeiro troféu','Vença uma competição'],[15,'Atleta lendário','Vença quinze competições']],
 elections:[[2,'Carreira política','Vença duas eleições'],[5,'Lenda das urnas','Vença cinco eleições']],
 crimes:[[10,'Vida perigosa','Cometa dez crimes no simulador']],
 marriages:[[1,'Aliança no dedo','Case-se pela primeira vez'],[3,'Amor insistente','Case-se três vezes']],
 children:[[1,'Primeiro filho','Tenha um filho'],[7,'Casa cheia','Tenha sete filhos']],
 pets:[[2,'Amigo dos animais','Adote dois animais'],[10,'Tutor dedicado','Adote dez animais']],
 volunteer:[[3,'Mãos à obra','Seja voluntário três vezes'],[30,'Coração grande','Participe trinta vezes']],
 years:[[10,'Uma década','Viva dez anos'],[50,'Meio século','Viva cinquenta anos'],[80,'Muitos capítulos','Viva oitenta anos']]
})){
  const indexKey={voyages:'trips'}[group]||group;
  for(const [n,name,desc] of pairs) DB.challenges.push({id:'extra_'+group+'_'+n,name,desc,condition:s=>(s.counts[indexKey]||0)>=n});
}
DB.challenges.push(
 {id:'extra_gen3',name:'Três gerações',desc:'Chegue à terceira geração',condition:s=>s.generation>=3},
 {id:'extra_gen5',name:'Dinastia histórica',desc:'Chegue à quinta geração',condition:s=>s.generation>=5},
 {id:'extra_500k',name:'Primeiras conquistas',desc:'Alcance R$ 500 mil de patrimônio',condition:s=>netWorth(s)>=500000},
 {id:'extra_10m',name:'Milionário múltiplo',desc:'Alcance R$ 10 milhões',condition:s=>netWorth(s)>=10000000},
 {id:'extra_100m',name:'Megaempresário',desc:'Alcance R$ 100 milhões',condition:s=>netWorth(s)>=100000000},
 {id:'extra_100followers',name:'Microinfluenciador',desc:'Tenha 100 seguidores',condition:s=>s.social.followers>=100},
 {id:'extra_1mfollowers',name:'Viral mundial',desc:'Tenha um milhão de seguidores',condition:s=>s.social.followers>=1000000},
 {id:'extra_royal',name:'Sangue azul',desc:'Comece uma vida na realeza',condition:s=>s.royal},
 {id:'extra_30skills',name:'Versátil',desc:'Tenha 30 pontos em oito habilidades',condition:s=>Object.values(s.skills).filter(v=>v>=30).length>=8},
 {id:'extra_masterall',name:'Pessoa de muitos talentos',desc:'Tenha 60 pontos em dez habilidades',condition:s=>Object.values(s.skills).filter(v=>v>=60).length>=10}
);
