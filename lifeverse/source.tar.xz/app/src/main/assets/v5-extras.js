/* Dois sistemas narrativos complementares: justiça fictícia e criadores digitais. */
'use strict';
const V5_LEGAL_TYPES={
 disputa:{name:'Disputa de contrato',kind:'civil',fee:1800,base:4500,risk:.34,requires:18},
 danos:{name:'Cobrança por danos materiais',kind:'civil',fee:2400,base:8500,risk:.43,requires:18},
 furto:{name:'Furto fictício',kind:'criminal',fee:0,base:3200,risk:.46,requires:18},
 fraude:{name:'Fraude fictícia',kind:'criminal',fee:0,base:19000,risk:.72,requires:18}
};
const V5_CHANNELS={
 video:{name:'VivaVídeo',skill:'Comunicação',sector:'Vídeos e documentários',cost:400},
 live:{name:'ArenaLive',skill:'Tecnologia',sector:'Jogos e transmissões',cost:700},
 escrita:{name:'JornalLivre',skill:'Criatividade',sector:'Textos e crônicas',cost:150},
 musica:{name:'OndaSom',skill:'Música',sector:'Música e produção',cost:650}
};
function v5ExtrasInit(){v5Init();if(!S.v5.legal)S.v5.legal={cases:[],record:[],lastYear:S.year};if(!S.v5.channels)S.v5.channels={accounts:[],posts:[],contracts:[],lastYear:S.year};}
function v5OpenCase(id){v5ExtrasInit();if(!requireLife(18))return false;const def=V5_LEGAL_TYPES[id];if(!def)return false;if(S.prison>0)return notify('Você precisa resolver a situação carcerária atual.','warn');if(S.cash<def.fee)return notify('Custas processuais: '+money(def.fee)+'.','warn');
 if(!v3Allow('case_start','global',1,{energy:10}))return false;
 if(!useEnergy(10,18)){v3RefundLimit('case_start');return false;}
 S.cash-=def.fee;const problem={id:'case-'+S.year+'-'+S.v5.legal.cases.length,kind:def.kind,type:id,name:def.name,opened:S.year,status:def.kind==='criminal'?'investigação':'petição',evidence:v3Int(15,85),claim:def.base,defense:0,hearing:S.year+1};
 S.v5.legal.cases.unshift(problem);if(def.kind==='criminal'){S.crimeHeat=Math.min(100,S.crimeHeat+v3Int(7,23));change('reputation',-7);}else change('stress',2);
 if(def.fee)v5Tx('justica',-def.fee,'Custas de '+def.name);logStory('Processo aberto: '+def.name+'. A decisão judicial ocorrerá em ano posterior.','event');save();render();return true;
}
function v5HireCounsel(id,tier){v5ExtrasInit();if(!requireLife(18))return false;const a=S.v5.legal.cases.find(x=>x.id===id&&x.status!=='encerrado');if(!a)return false;const level=tier==='especialista'?2:1,cost=level===2?9500:3000;if(S.cash<cost)return notify('Advocacia custa '+money(cost)+'.','warn');if(!v3Allow('legal_counsel','case:'+id,1,{energy:7}))return false;
 if(!useEnergy(7,18)){v3RefundLimit('legal_counsel','case:'+id);return false;}
 S.cash-=cost;a.defense+=level===2?26:12;a.counsel=level===2?'Especialista':'Defensor contratado';v5Tx('justica',-cost,'Contratação de defesa jurídica');logStory('Contratou defesa jurídica para '+a.name+'.','event');save();render();return true;
}
function v5AnnualLegal(){v5ExtrasInit();for(const c of S.v5.legal.cases){if(c.status==='encerrado'||S.year<c.hearing)continue;
 const publicReputation=(S.stats.reputation-50)*.18,skill=(S.skills['Direito']||0)*.13;
 const defense=c.defense+skill+publicReputation+v3Int(-17,18);
 const favorable=c.kind==='civil'?defense>c.evidence-10:defense>c.evidence+15;
 let verdict='';if(c.kind==='civil'){
  if(favorable){const award=Math.round(c.claim*(.6+v3Rand()*.5));S.cash+=award;v5Tx('sentenca',award,'Decisão civil favorável: '+c.name);verdict='Ganhou o processo e recebeu '+money(award);}
  else{const loss=Math.round(c.claim*(.4+v3Rand()*.4)),paid=Math.min(S.cash,loss);S.cash-=paid;if(paid<loss)S.debt+=loss-paid;v5Tx('sentenca',-paid,'Decisão civil desfavorável: '+c.name);verdict='Perdeu a disputa e arcou com '+money(loss);}
 }else if(favorable){verdict='Foi absolvido por insuficiência de provas';change('reputation',2);}else{const time=c.type==='fraude'?v3Int(2,6):v3Int(1,3);S.prison=Math.max(S.prison,time);change('reputation',-12);S.v5.legal.record.push({year:S.year,type:c.type,sentence:time});verdict='Foi condenado(a) a '+time+' anos de prisão (simulação)';}
 c.verdict=verdict;c.status='encerrado';c.resolved=S.year;logStory('Tribunal: '+c.name+'. '+verdict+'.','event');S.v5.legal.lastYear=S.year;
 }}
function v5CreateChannel(id){v5ExtrasInit();if(!requireLife(13))return false;const channel=V5_CHANNELS[id];if(!channel||S.v5.channels.accounts.some(c=>c.id===id))return notify('Este canal já está ativo.','warn');if(S.cash<channel.cost)return notify('Equipamentos custam '+money(channel.cost)+'.','warn');if(!v3Allow('channel_create','global',2,{energy:10}))return false;
 S.cash-=channel.cost;S.v5.channels.accounts.push({id,name:channel.name,followers:0,engagement:0,posts:0,reputation:50,created:S.year,lastPostedYear:0,earnings:0});v5Tx('canal',-channel.cost,'Equipamentos para '+channel.name);logStory('Criou um canal em '+channel.name+'.','milestone');save();render();return true;
}
function v5ChannelPost(id,kind){v5ExtrasInit();if(!requireLife(13))return false;const channel=S.v5.channels.accounts.find(x=>x.id===id);if(!channel)return false;const meta=V5_CHANNELS[id];if(!v3Allow('post','channel:'+id,2,{energy:9}))return false;
 if(!useEnergy(9,13)){v3RefundLimit('post','channel:'+id);return false;}
 const quality=(S.skills[meta.skill]||0)*.6+S.stats.discipline*.25+(S.stats.joy*.15);const luck=v3Int(-40,45);const reach=Math.max(10,Math.round((quality+luck)*(1+channel.followers/8000)*v4SalaryFactor()*.35));const viral=v3Chance(Math.min(.06,.004+quality/8000));const gained=viral?reach*v3Int(8,18):reach;
 channel.followers+=gained;channel.posts++;channel.lastPostedYear=S.year;channel.engagement=Math.max(0,Math.min(100,Math.round(quality+v3Int(-12,12))));channel.reputation=Math.max(0,Math.min(100,channel.reputation+(viral?3:0)+v3Int(-2,2)));
 S.social.followers+=gained;S.social.posts++;S.v5.channels.posts.unshift({year:S.year,id,kind,reach,gained,viral,engagement:channel.engagement});S.v5.channels.posts=S.v5.channels.posts.slice(0,100);change('joy',viral?7:2);if(viral)change('fame',3);
 logStory('Publicou '+kind+' em '+channel.name+', alcançou '+reach+' pessoas e ganhou '+gained+' seguidores.','event');save();render();return true;
}
function v5Sponsor(id){v5ExtrasInit();if(!requireLife(18))return false;const c=S.v5.channels.accounts.find(x=>x.id===id);if(!c||c.followers<2000)return notify('Precisa de pelo menos 2.000 seguidores no canal.','warn');
 if(!v3Allow('sponsor','channel:'+id,1,{energy:7}))return false;if(!useEnergy(7,18)){v3RefundLimit('sponsor','channel:'+id);return false;}
 const chance=Math.min(.84,.15+c.engagement/190+c.reputation/450);if(!v3Chance(chance)){logStory('A marca recusou o contrato publicitário com '+c.name+'.','event');save();render();return false;}
 const pay=Math.round(c.followers*(.015+v3Rand()*.13)*v4SalaryFactor());S.cash+=pay;c.earnings+=pay;S.v5.channels.contracts.unshift({year:S.year,id,brand:v3Pick(['Aurora Studio','Nexus Foods','Prisma Digital','Horizonte Sports']),pay});v5Tx('patrocinio',pay,'Contrato publicitário de '+c.name);logStory('Assinou patrocínio em '+c.name+' por '+money(pay)+'.','money');save();render();return true;}
function v5AnnualChannels(){v5ExtrasInit();for(const c of S.v5.channels.accounts){if(c.lastPostedYear<S.year-1){const lost=Math.round(c.followers*.035);c.followers=Math.max(0,c.followers-lost);S.social.followers=Math.max(0,S.social.followers-lost);c.engagement=Math.max(0,c.engagement-2);}else{c.engagement=Math.max(0,c.engagement-1);}}}
const _v5PreviousAnnual=v5AfterYear;
v5AfterYear=function(){_v5PreviousAnnual();if(!S||!S.v5)return;if(S.v5.extrasProcessedYear===S.year)return;S.v5.extrasProcessedYear=S.year;v5AnnualLegal();v5AnnualChannels();save();render();};
