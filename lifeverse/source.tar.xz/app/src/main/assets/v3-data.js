/* VIDAVERSO 3.0 — catálogos declarativos. Nenhum conteúdo pago. */
'use strict';
const V3_DEGREE_FIELDS={
 'Medicina':['Medicina','Enfermagem','Odontologia','Fisioterapia','Farmácia','Biomedicina','Nutrição','Veterinária','Psicologia','Terapia Ocupacional','Fonoaudiologia','Saúde Pública','Radiologia'],
 'Direito':['Direito','Criminologia','Segurança Pública','Ciências Forenses'],
 'Tecnologia':['Ciência da Computação','Engenharia de Software','Sistemas de Informação','Ciência de Dados','Inteligência Artificial','Segurança da Informação','Engenharia de Computação','Robótica','Design de Jogos','Redes de Computadores','Análise de Sistemas'],
 'Ciências':['Física','Química','Biologia','Matemática','Estatística','Geologia','Astronomia','Ciências Ambientais','Biotecnologia','Oceanografia','Arqueologia','Engenharia Civil','Engenharia Mecânica','Engenharia Elétrica','Engenharia de Produção','Engenharia Química','Engenharia Aeroespacial','Engenharia Ambiental','Arquitetura','Agronomia','Zootecnia','Engenharia Naval'],
 'Educação':['Pedagogia','Letras','História','Geografia','Filosofia','Matemática','Educação Física','Biblioteconomia','Sociologia'],
 'Negócios':['Administração','Economia','Contabilidade','Gestão Financeira','Marketing','Comércio Exterior','Logística','Gestão de Projetos','Gestão de Pessoas','Gestão Imobiliária','Turismo','Hotelaria','Relações Internacionais','Ciências Políticas'],
 'Criatividade':['Design','Artes Visuais','Música','Cinema','Teatro','Moda','Gastronomia','Fotografia','Jornalismo','Publicidade','Comunicação','Produção Musical']
};
const V3_DEGREES=[...new Set(Object.values(V3_DEGREE_FIELDS).flat())];
// Nome | setor existente | idade | nível acadêmico | salário anual fictício | habilidade | dificuldade | formação preferencial | experiência mínima.
const V3_JOB_ROWS=`
Técnico de enfermagem|Saúde|19|0|42000|Medicina|15||0
Pediatra|Saúde|29|2|285000|Medicina|65|Medicina|5
Cardiologista|Saúde|31|2|355000|Medicina|70|Medicina|6
Neurocirurgião|Saúde|34|3|495000|Medicina|82|Medicina|9
Dermatologista|Saúde|29|2|290000|Medicina|61|Medicina|5
Anestesista|Saúde|31|2|340000|Medicina|67|Medicina|6
Oncologista|Saúde|30|2|325000|Medicina|69|Medicina|5
Terapeuta ocupacional|Saúde|23|1|85000|Medicina|29|Terapia Ocupacional|1
Fonoaudiólogo|Saúde|23|1|79000|Medicina|28|Fonoaudiologia|1
Gestor hospitalar|Saúde|28|1|164000|Liderança|52|Administração|5
Biomédico|Saúde|23|1|92000|Ciências|32|Biomedicina|1
Técnico em radiologia|Saúde|20|0|50000|Medicina|22||0
Procurador público|Justiça|30|1|214000|Direito|64|Direito|5
Defensor público|Justiça|28|1|175000|Direito|59|Direito|4
Oficial de justiça|Justiça|23|1|96000|Direito|32|Direito|1
Escrivão judicial|Justiça|21|0|69000|Direito|23||0
Tabelião|Justiça|29|1|205000|Direito|65|Direito|5
Mediador judicial|Justiça|24|1|97000|Comunicação|30|Direito|2
Desembargador|Justiça|40|2|365000|Direito|80|Direito|14
Advogado trabalhista|Justiça|25|1|128000|Direito|40|Direito|2
Advogado criminalista|Justiça|25|1|135000|Direito|45|Direito|2
Analista de suporte|Tecnologia|18|0|42000|Tecnologia|16||0
Desenvolvedor mobile|Tecnologia|20|0|100000|Tecnologia|35||2
Desenvolvedor web|Tecnologia|18|0|85000|Tecnologia|28||1
Engenheiro de dados|Tecnologia|23|1|165000|Tecnologia|44|Ciência de Dados|2
Pesquisador de inteligência artificial|Tecnologia|28|2|256000|Ciências|65|Inteligência Artificial|4
Engenheiro de segurança digital|Tecnologia|24|1|175000|Tecnologia|51|Segurança da Informação|3
Arquiteto de software|Tecnologia|27|1|213000|Tecnologia|61|Engenharia de Software|6
Administrador de banco de dados|Tecnologia|22|0|116000|Tecnologia|38||2
Testador de software|Tecnologia|18|0|64000|Tecnologia|20||0
Engenheiro de robótica|Tecnologia|24|1|158000|Tecnologia|47|Robótica|2
Produtor de aplicativos|Tecnologia|19|0|74000|Criatividade|24||1
Analista de automação|Tecnologia|21|0|99000|Tecnologia|35||2
Engenheiro mecânico|Ciências|23|1|140000|Ciências|40|Engenharia Mecânica|1
Engenheiro eletricista|Ciências|23|1|144000|Ciências|42|Engenharia Elétrica|1
Engenheiro de produção|Ciências|22|1|132000|Ciências|38|Engenharia de Produção|1
Engenheiro ambiental|Ciências|22|1|115000|Ciências|36|Engenharia Ambiental|1
Engenheiro químico|Ciências|23|1|148000|Ciências|41|Engenharia Química|1
Engenheiro aeroespacial|Ciências|24|1|172000|Ciências|52|Engenharia Aeroespacial|2
Astrônomo|Ciências|25|1|120000|Ciências|46|Astronomia|2
Astrofísico|Ciências|29|2|185000|Ciências|61|Física|4
Oceanógrafo|Ciências|24|1|107000|Ciências|34|Oceanografia|2
Geólogo|Ciências|22|1|119000|Ciências|36|Geologia|1
Microbiologista|Ciências|24|1|112000|Ciências|39|Biologia|2
Geneticista|Ciências|27|2|161000|Ciências|54|Biotecnologia|4
Engenheiro agrônomo|Ciências|23|1|122000|Ciências|39|Agronomia|1
Pesquisador espacial|Ciências|29|2|206000|Ciências|68|Engenharia Aeroespacial|5
Coordenador pedagógico|Educação|28|1|87000|Liderança|40|Pedagogia|5
Diretor pedagógico|Educação|34|1|145000|Liderança|56|Pedagogia|9
Professor infantil|Educação|21|1|48000|Comunicação|22|Pedagogia|0
Professor de matemática|Educação|23|1|64000|Ciências|30|Matemática|0
Professor de idiomas|Educação|21|1|57000|Comunicação|25|Letras|0
Tutor particular|Educação|18|0|39000|Comunicação|20||0
Instrutor técnico|Educação|21|0|52000|Comunicação|24||1
Reitor universitário|Educação|40|3|260000|Liderança|80|Pedagogia|14
Orientador educacional|Educação|23|1|67000|Comunicação|27|Pedagogia|2
Assistente de RH|Comércio|18|0|35000|Comunicação|13||0
Gerente de recursos humanos|Comércio|27|1|122000|Liderança|48|Gestão de Pessoas|5
Gerente de operações|Comércio|28|1|147000|Liderança|50|Administração|6
Diretor financeiro|Comércio|34|1|258000|Negócios|66|Gestão Financeira|10
Auditor independente|Comércio|25|1|110000|Negócios|36|Contabilidade|3
Analista de crédito|Comércio|21|1|66000|Negócios|29|Gestão Financeira|0
Analista de risco|Comércio|23|1|108000|Negócios|41|Economia|2
Atuário|Comércio|24|1|129000|Ciências|48|Estatística|2
Planejador financeiro|Comércio|24|1|102000|Negócios|39|Gestão Financeira|2
Gerente de e-commerce|Comércio|23|0|91000|Negócios|37||3
Representante comercial|Comércio|18|0|45000|Comunicação|19||0
Corretor de imóveis|Comércio|19|0|53000|Comunicação|24||0
Avaliador imobiliário|Comércio|23|0|70000|Negócios|30||3
Administrador de propriedades|Comércio|23|0|74000|Negócios|31||3
Incorporador imobiliário|Comércio|30|1|235000|Negócios|64|Gestão Imobiliária|7
Gestor de locações|Comércio|23|0|74000|Negócios|33||3
Gestor de condomínios|Comércio|23|0|65000|Liderança|30||2
Gestor de patrimônio imobiliário|Comércio|31|1|161000|Negócios|60|Gestão Imobiliária|8
Analista de investimentos imobiliários|Comércio|24|1|126000|Negócios|48|Economia|3
Analista de comércio exterior|Comércio|22|1|96000|Comunicação|34|Comércio Exterior|1
Operador de máquinas|Básico|18|0|37000|Disciplina|15||0
Soldador|Básico|18|0|49000|Disciplina|23||1
Torneiro mecânico|Básico|18|0|53000|Disciplina|24||1
Eletricista industrial|Básico|19|0|52000|Tecnologia|23||1
Mecânico industrial|Básico|19|0|52000|Tecnologia|24||1
Inspetor de qualidade|Básico|21|0|66000|Disciplina|31||2
Supervisor de fábrica|Básico|26|0|89000|Liderança|40||5
Motorista de ônibus|Básico|21|0|45000|Disciplina|18||1
Caminhoneiro|Básico|21|0|62000|Disciplina|22||1
Operador ferroviário|Básico|19|0|49000|Disciplina|21||1
Comissário de bordo|Básico|20|0|62000|Comunicação|27||1
Controlador aéreo|Ciências|23|1|143000|Ciências|54|Engenharia Aeroespacial|2
Comandante de aeronave|Ciências|34|1|340000|Disciplina|70|Engenharia Aeroespacial|8
Marinheiro|Básico|18|0|46000|Disciplina|16||0
Comandante de navio|Ciências|30|1|218000|Liderança|62|Engenharia Naval|7
Policial rodoviário|Governo|21|0|86000|Esportes|39||1
Agente penitenciário|Governo|21|0|70000|Disciplina|30||1
Guarda municipal|Governo|21|0|65000|Esportes|27||1
Bombeiro|Governo|20|0|72000|Esportes|32||1
Socorrista|Saúde|20|0|51000|Medicina|27||1
Resgatista|Saúde|20|0|60000|Esportes|32||1
Soldado|Governo|18|0|47000|Disciplina|18||0
Sargento|Governo|24|0|76000|Disciplina|34||4
Tenente|Governo|26|1|110000|Liderança|43|Administração|5
Capitão militar|Governo|29|1|156000|Liderança|56|Administração|8
General|Governo|44|2|330000|Liderança|84|Administração|22
Guia turístico|Básico|18|0|42000|Comunicação|17||0
Agente de viagens|Comércio|19|0|48000|Comunicação|21||1
Gerente de hotel|Comércio|28|1|106000|Liderança|44|Hotelaria|5
Concierge|Básico|19|0|50000|Comunicação|27||1
Gestor de resort|Comércio|33|1|173000|Liderança|62|Hotelaria|8
Chef confeiteiro|Criatividade|21|0|65000|Criatividade|30||3
Confeiteiro|Criatividade|18|0|39000|Criatividade|17||0
Padeiro|Criatividade|18|0|37000|Criatividade|18||0
Pizzaiolo|Criatividade|18|0|38000|Criatividade|19||0
Sommelier|Criatividade|23|0|67000|Criatividade|32||3
Crítico gastronômico|Mídia|25|0|71000|Comunicação|33||4
Gerente de restaurante|Comércio|25|0|86000|Liderança|35||5
Diretor de fotografia|Mídia|24|0|102000|Artes|42||3
Editor de vídeo|Mídia|18|0|61000|Tecnologia|24||1
Dublador|Celebridades|18|0|51000|Artes|26||1
Compositor|Celebridades|18|0|61000|Música|30||1
Maestro|Celebridades|30|1|133000|Música|63|Música|8
Coreógrafo|Celebridades|23|0|74000|Artes|38||4
Ator de teatro|Celebridades|18|0|48000|Artes|26||0
Podcaster|Mídia|17|0|39000|Comunicação|24||0
Tradutor|Mídia|20|0|56000|Comunicação|24||1
Assessor de imprensa|Mídia|22|1|84000|Comunicação|33|Comunicação|1
Designer de interiores|Criatividade|21|0|66000|Criatividade|26||1
Ilustrador|Criatividade|18|0|46000|Criatividade|23||0
Maquiador|Criatividade|18|0|40000|Artes|20||0
Tatuador|Criatividade|18|0|49000|Artes|24||1
Joalheiro|Criatividade|20|0|56000|Criatividade|27||2
Preparador físico|Esportes|20|0|61000|Esportes|28||1
Árbitro de futebol|Esportes|19|0|47000|Esportes|25||1
Nadador profissional|Esportes|17|0|65000|Esportes|41||2
Jogador de basquete|Esportes|16|0|76000|Esportes|44||2
Jogador de vôlei|Esportes|16|0|66000|Esportes|41||2
Boxeador|Esportes|18|0|72000|Esportes|47||2
Atleta de e-sports|Esportes|16|0|65000|Tecnologia|42||1
Treinador de e-sports|Esportes|22|0|60000|Tecnologia|37||3
Skatista profissional|Esportes|17|0|51000|Esportes|37||2
Surfista profissional|Esportes|17|0|53000|Esportes|39||2
Assistente social|Educação|22|1|61000|Comunicação|25|Sociologia|1
Cuidador infantil|Básico|18|0|35000|Comunicação|15||0
Agente comunitário de saúde|Saúde|18|0|42000|Comunicação|19||0
Coordenador de ONG|Comércio|28|1|88000|Liderança|42|Administração|5
Engenheiro florestal|Ciências|23|1|118000|Ciências|38|Engenharia Ambiental|1
Apicultor|Básico|18|0|42000|Ciências|23||0
Pescador|Básico|18|0|38000|Esportes|16||0
Zootecnista|Ciências|23|1|103000|Ciências|35|Zootecnia|1
Administrador rural|Comércio|27|1|118000|Negócios|45|Agronomia|5
Desenvolvedor independente de jogos|Tecnologia|18|0|47000|Tecnologia|32||1
Especialista em marketing digital|Mídia|19|0|62000|Comunicação|25||1
Gestor de comunidades|Mídia|19|0|54000|Comunicação|22||1
Produtor de cursos online|Educação|19|0|45000|Comunicação|24||1
`.trim().split('\n').map(s=>s.trim().split('|'));
const V3_EXTRA_JOBS=V3_JOB_ROWS.map(([name,sector,minAge,degree,salary,skill,required,major,experience])=>({name,sector,minAge:+minAge,degree:+degree,salary:+salary,skill,required:+required,major:major||'',experience:+experience}));
const V3_PROPERTIES=[['Studio mobiliado',140000,1500,2],['Apartamento compacto',175000,1700,2],['Sobrado',590000,3900,5],['Casa em condomínio',1100000,6900,6],['Casa de praia',780000,4600,6],['Chácara',720000,2500,5],['Terreno urbano',125000,0,1],['Terreno industrial',980000,0,2],['Sala comercial',290000,2300,2],['Loja de rua',440000,3600,3],['Galpão logístico',1350000,9000,3],['Conjunto de salas',1400000,11200,4],['Prédio residencial',4800000,42000,8],['Casa de campo',640000,2900,5],['Hotel pequeno',2650000,20000,7],['Fazenda produtiva',2950000,17600,6],['Condomínio de casas',5300000,39000,9],['Residência histórica',850000,3600,6]];
const V3_VENTURES=[['Padaria artesanal',45000,19500,.10],['Mercado de bairro',85000,55000,.08],['Loja de eletrônicos',76000,37000,.11],['Escola de idiomas',90000,33000,.16],['Escola infantil',240000,87000,.11],['Construtora',500000,220000,.08],['Agência de viagens',55000,24000,.14],['Oficina mecânica',90000,48000,.14],['Salão de beleza',48000,26000,.17],['Empresa de limpeza',34000,22000,.15],['Empresa agrícola',230000,100000,.12],['Transportadora',260000,150000,.08],['Loja virtual',32000,25000,.13],['Consultoria empresarial',55000,24000,.2],['Aplicativo de mobilidade',180000,90000,.06],['Ateliê de design',45000,21000,.19],['Estúdio de fotografia',28000,12500,.15],['Empresa de reciclagem',135000,58000,.10],['Clínica veterinária',180000,68000,.14],['Pet shop',70000,31000,.13],['Farmácia',190000,93000,.08],['Laboratório',440000,160000,.12],['Livraria',65000,22000,.06],['Fazenda de energia solar',350000,125000,.13],['Empresa de segurança',125000,72000,.10],['Academia de dança',87000,32000,.16],['Restaurante vegano',100000,43000,.13],['Estúdio de animação',180000,83000,.14],['Empresa de manutenção',76000,38000,.12],['Hotel para pets',90000,38000,.17]];
const V3_CONDITIONS=[
 ['Gripe sazonal','aguda',1,3,10],['Enxaqueca','recorrente',5,5,16],['Asma','cronica',4,6,12],['Anemia','aguda',3,5,12],['Dermatite','recorrente',2,3,7],['Alergia respiratória','recorrente',2,3,7],['Hipertensão','cronica',4,6,18],['Diabetes tipo 2','cronica',5,6,24],['Insônia','recorrente',3,4,15],['Ansiedade','recorrente',4,4,20],['Depressão','recorrente',5,6,22],['Lesão muscular','aguda',2,3,12],['Fratura','aguda',5,6,22],['Artrite','cronica',4,4,17],['Bronquite','recorrente',3,4,14],['Gastrite','recorrente',3,3,10],['Intoxicação alimentar','aguda',2,2,11],['Pneumonia','aguda',6,6,30],['Problema de visão','cronica',2,2,7],['Problema auditivo','cronica',3,3,8],['Lombalgia','recorrente',3,3,13],['Cárie dentária','aguda',1,1,6],['Colesterol alto','cronica',3,3,13],['Osteoporose','cronica',4,5,20],['Doença autoimune','cronica',7,7,27],['Tendinite','recorrente',2,3,10],['Refluxo','recorrente',2,3,8],['Apneia do sono','cronica',5,5,20],['Pedra nos rins','aguda',5,5,20],['Hipotireoidismo','cronica',3,4,10],['Otite','aguda',2,2,8],['Conjuntivite','aguda',2,1,6]
].map(([name,type,severity,cost,impact],i)=>({id:'med_'+i,name,type,severity,cost:cost*240,impact}));
// Especialidades por categoria, com exigências/impactos de turno próprio.
const V3_SECTOR_SCENARIOS={
 Saúde:[['Plantão com equipe reduzida','Reorganizar atendimento','Pedir reforços','Ignorar advertência'],['Paciente precisa de acompanhamento','Agendar retorno','Consultar um especialista','Encerrar rapidamente']],
 Justiça:[['Processo difícil','Analisar jurisprudência','Propor acordo','Ignorar provas'],['Dilema de confidencialidade','Proteger os envolvidos','Consultar ética profissional','Divulgar a informação']],
 Tecnologia:[['Falha em produção','Investigar a origem','Fazer rollback','Esconder o problema'],['Dados de usuários expostos','Notificar responsáveis','Corrigir e auditar','Apagar os registros']],
 Ciências:[['Projeto experimental','Validar amostras','Repetir o teste','Publicar cedo'],['Financiamento de pesquisa','Apresentar resultados','Revisar orçamento','Prometer mais do que pode']],
 Educação:[['Alunos com dificuldades','Criar acompanhamento','Conversar com responsáveis','Aplicar punição geral'],['Conflito em sala','Medir o problema','Buscar mediação','Ignorar a turma']],
 Comércio:[['Cliente insatisfeito','Investigar falha','Oferecer solução','Ignorar contato'],['Meta de vendas apertada','Rever estratégia','Treinar equipe','Prometer resultados irreais']],
 Básico:[['Turno sobrecarregado','Negociar divisão','Propor melhoria','Assumir tudo sozinho'],['Equipamento com defeito','Reportar manutenção','Solicitar inspeção','Continuar sem verificar']],
 Mídia:[['Reportagem controversa','Checar fontes','Solicitar revisão','Publicar sem conferir'],['Fonte confidencial','Proteger identidade','Buscar confirmação','Expor o contato']],
 Celebridades:[['Convite de publicidade','Ler contrato','Consultar representante','Aceitar sem avaliar'],['Críticas ao trabalho','Preparar novo projeto','Ouvir equipe','Comprar avaliações falsas']],
 Esportes:[['Treino antes da final','Priorizar recuperação','Rever estratégia','Treinar lesionado'],['Proposta de transferência','Negociar contrato','Conversar com equipe','Romper compromissos']],
 Governo:[['Orçamento em debate','Ouvir a comunidade','Rever prioridades','Esconder os custos'],['Crise pública','Divulgar informações','Consultar especialistas','Culpar adversários']],
 Criatividade:[['Projeto autoral atrasado','Redefinir escopo','Buscar parceria','Entregar inacabado'],['Cliente pede alteração','Negociar prazo','Apresentar alternativa','Descartar feedback']]
};
