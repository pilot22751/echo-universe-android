/* VIDAVERSO 5.0 — desenvolvimento incremental; dados ficcionais, 100% offline.
 * Módulos novos: banco, crédito, imigração documentada, entrevistas, educação,
 * empréstimos entre conhecidos, produção empresarial e relatórios auditáveis.
 * Valores financeiros internos são créditos BRL de referência, sem FX de mercado.
 */
'use strict';
const V5_SCHEMA=5;
const V5_BANKS=[
 {id:'aurora',name:'Banco Aurora',savings:0.038,loan:0.14,fee:0},
 {id:'ponte',name:'Banco Ponte',savings:0.052,loan:0.19,fee:80},
 {id:'vereda',name:'Cooperativa Vereda',savings:0.043,loan:0.115,fee:35}
];
const V5_CARD_ITEMS={cultura:{title:'Passe anual de cultura',price:1600,joy:5,skill:'Artes'},curso:{title:'Curso profissional',price:2600,joy:1,skill:'Tecnologia'},viagem:{title:'Viagem de fim de semana',price:3800,joy:7,skill:'Comunicação'},reforma:{title:'Móveis para casa',price:4400,joy:5,skill:'Negócios'}};
const V5_SCHOOL_CLUBS={robotica:{name:'Clube de robótica',skill:'Tecnologia',minAge:10,cost:360},debate:{name:'Clube de debates',skill:'Comunicação',minAge:10,cost:140},xadrez:{name:'Clube de xadrez',skill:'Ciências',minAge:7,cost:90},teatro:{name:'Teatro escolar',skill:'Artes',minAge:7,cost:300},esporte:{name:'Equipe esportiva',skill:'Esportes',minAge:8,cost:300},musica:{name:'Orquestra juvenil',skill:'Música',minAge:9,cost:450}};
const V5_TRAVEL_RULES={
 'Estados Unidos':{visa:true,cost:2400,requirements:60},'Canadá':{visa:true,cost:2100,requirements:55},'Japão':{visa:true,cost:1800,requirements:48},'Reino Unido':{visa:true,cost:2000,requirements:52},'Austrália':{visa:true,cost:2300,requirements:56},'Brasil':{visa:false,cost:1300,requirements:35},'Portugal':{visa:false,cost:1400,requirements:35},'Alemanha':{visa:false,cost:1550,requirements:40},'França':{visa:false,cost:1400,requirements:38},'Itália':{visa:false,cost:1400,requirements:38}
};
function v5Rule(country){return V5_TRAVEL_RULES[country]||{visa:true,cost:Math.round(1800*v4CostFactor()/2),requirements:45};}
function v5Init(){if(!S)return;v4Init();if(!S.v5)S.v5={schema:V5_SCHEMA,finance:{bank:'aurora',savings:0,checking:0,loans:[],card:{balance:0,limit:5000,missed:0},score:650,ledger:[],year:S.year},travel:{passport:null,visas:[],visits:[],citizenships:[S.country],residence:S.country},school:{clubs:[],entrance:[],scholarship:0,examScore:0,history:[]},interviews:[],social:{loans:[],gatherings:[]},businessReports:[],yearReports:[],processedYear:S.year};
 const v=S.v5;v.schema=V5_SCHEMA;v.finance=v.finance||{};const f=v.finance;f.bank=V5_BANKS.some(b=>b.id===f.bank)?f.bank:'aurora';f.savings=Math.max(0,Number(f.savings)||0);f.checking=Math.max(0,Number(f.checking)||0);f.loans=Array.isArray(f.loans)?f.loans:[];f.card=f.card||{balance:0,limit:5000,missed:0};f.card.balance=Math.max(0,Number(f.card.balance)||0);f.card.limit=Math.max(5000,Number(f.card.limit)||5000);f.card.missed=Math.max(0,Number(f.card.missed)||0);f.score=Math.max(300,Math.min(900,Number(f.score)||650));f.ledger=Array.isArray(f.ledger)?f.ledger:[];
 v.travel=v.travel||{};v.travel.visas=v.travel.visas||[];v.travel.visits=v.travel.visits||[];v.travel.citizenships=v.travel.citizenships||[S.country];v.travel.residence=v.travel.residence||S.country;
 v.school=v.school||{clubs:[],entrance:[],scholarship:0,examScore:0,history:[]};v.school.clubs=v.school.clubs||[];v.school.entrance=v.school.entrance||[];v.school.history=v.school.history||[];
 v.interviews=v.interviews||[];v.social=v.social||{loans:[],gatherings:[]};v.social.loans=v.social.loans||[];v.social.gatherings=v.social.gatherings||[];v.businessReports=v.businessReports||[];v.yearReports=v.yearReports||[];
 if(!Number.isFinite(v.processedYear))v.processedYear=S.year;
 return v;
}
function v5Bank(){return V5_BANKS.find(x=>x.id===v5Init().finance.bank)||V5_BANKS[0];}
function v5TotalLoans(){return (S?.v5?.finance?.loans||[]).reduce((a,x)=>a+Math.max(0,x.balance||0),0);}
function v5Receivables(){return (S?.v5?.social?.loans||[]).reduce((a,x)=>a+(x.closed?0:Math.max(0,x.balance||0)),0);}
function v5NetAdditions(){return S?.v5?(S.v5.finance.savings+S.v5.finance.checking+v5Receivables()-v5TotalLoans()-S.v5.finance.card.balance):0;}
function v5Tx(kind,amount,description,account='wallet'){
 const record={id:S.year+':'+(S.v5.finance.ledger.length+1)+':'+Math.floor(v3Rand()*1e7),year:S.year,kind,amount:Math.round(amount),description,account,country:S.country};
 S.v5.finance.ledger.unshift(record);if(S.v5.finance.ledger.length>250)S.v5.finance.ledger.length=250;
 if(typeof v2Ledger==='function')v2Ledger(kind,amount,description);
}
function v5Amount(raw){const n=Math.round(Number(raw));return Number.isSafeInteger(n)&&n>0&&n<=1000000000?n:0;}
function v5FinanceMove(kind,amount){v5Init();if(!requireLife(18))return false;amount=v5Amount(amount);if(!amount)return notify('Escolha um valor positivo válido.','warn');
 const f=S.v5.finance,from=kind==='deposit'?'cash':kind==='withdraw'?'savings':kind==='checking'?'cash':kind==='cashout'?'checking':null,to=kind==='deposit'?'savings':kind==='withdraw'?'cash':kind==='checking'?'checking':kind==='cashout'?'cash':null;
 if(!from||!to)return false;
 const old=from==='cash'?S.cash:f[from];if(old<amount)return notify('O saldo de origem é insuficiente.','warn');
 if(from==='cash')S.cash-=amount;else f[from]-=amount;
 if(to==='cash')S.cash+=amount;else f[to]+=amount;
 v5Tx('transferencia',0,'Transferência '+money(amount)+' de '+from+' para '+to,from+' → '+to);save();render();notify('Transferência realizada. Seu patrimônio não mudou.');return true;
}
function v5ChangeBank(id){v5Init();if(!requireLife(18))return false;const b=V5_BANKS.find(x=>x.id===id);if(!b)return false;
 if(!v3Allow('bank_switch','global',1,{energy:5,message:'Você já mudou de instituição neste ano.'}))return false;
 if(S.cash<b.fee){v3RefundLimit('bank_switch');return notify('Não tem saldo para a tarifa de '+money(b.fee)+'.','warn');}
 S.cash-=b.fee;S.v5.finance.bank=id;S.v5.finance.score=Math.max(300,S.v5.finance.score-(b.fee?1:0));v5Tx('tarifa',-b.fee,'Mudança de banco: '+b.name);logStory('Transferiu seus serviços bancários para '+b.name+'.','money');save();render();return true;
}
function v5CreditLoan(amount,years){v5Init();if(!requireLife(18))return false;amount=v5Amount(amount);years=Math.round(Number(years));const f=S.v5.finance,b=v5Bank();if(!amount||amount<3000||amount>200000||![2,4,8].includes(years))return notify('Empréstimos entre '+money(3000)+' e '+money(200000)+' por 2, 4 ou 8 anos.','warn');
 const outstanding=v5TotalLoans();const income=(S.job?.salary||0)+(S.businesses||[]).reduce((x,y)=>x+Math.max(0,y.profit||0),0);const affordability=Math.max(9000,income*2.7+S.cash*.5);
 if(outstanding+amount>affordability||f.score<430)return notify('Crédito recusado: capacidade de pagamento ou pontuação insuficiente.','warn');
 if(!v3Allow('borrow','global',1,{energy:5,message:'Limite: um empréstimo aprovado por ano.'}))return false;
 const rate=b.loan+Math.max(0,(650-f.score)/6000),fees=Math.round(amount*.018);
 const loan={id:'cr'+S.year+'_'+Math.floor(v3Rand()*100000),bank:b.name,principal:amount,balance:amount,rate,years,term:years,installment:Math.round(amount*rate/(1-Math.pow(1+rate,-years))),lastProcessed:S.year,issued:S.year,arrears:0};
 f.loans.push(loan);S.cash+=amount-fees;v5Tx('credito',amount-fees,'Empréstimo aprovado ('+years+' anos), descontada tarifa '+money(fees));logStory('Contratou empréstimo em '+b.name+' por '+money(amount)+' com juros simulados.','money');save();render();return true;
}
function v5RepayLoan(id,amount){v5Init();const l=S.v5.finance.loans.find(x=>x.id===id&&x.balance>0);amount=v5Amount(amount);if(!l||!amount)return false;const n=Math.min(l.balance,amount,S.cash);if(n<=0)return notify('Saldo insuficiente para amortização.','warn');S.cash-=n;l.balance=Math.max(0,l.balance-n);v5Tx('amortizacao',-n,'Amortização de '+l.bank);save();render();return true;}
function v5CardBuy(item){v5Init();if(!requireLife(18))return false;const it=V5_CARD_ITEMS[item],f=S.v5.finance;if(!it)return false;const price=Math.round(it.price*v4CostFactor());if(f.card.balance+price>f.card.limit)return notify('O limite do cartão não cobre a compra.','warn');
 if(!v3Allow('card_'+item,'global',1,{energy:4}))return false;
 f.card.balance+=price;change('joy',it.joy);if(S.skills[it.skill]!==undefined)change(it.skill,2);v5Tx('cartao',-price,it.title,'crédito');logStory('Comprou '+it.title+' no cartão por '+money(price)+'.','money');save();render();return true;
}
function v5CardPayment(amount){v5Init();amount=v5Amount(amount);const card=S.v5.finance.card;if(!amount||!card.balance)return false;const n=Math.min(amount,card.balance,S.cash);if(n<=0)return notify('Não tem dinheiro disponível para pagar a fatura.','warn');card.balance-=n;S.cash-=n;v5Tx('fatura',-n,'Pagamento da fatura do cartão');if(card.balance===0)S.v5.finance.score=Math.min(900,S.v5.finance.score+4);save();render();return true;}
function v5AnnualFinance(){const f=S.v5.finance;if(!S.alive)return;const interest=Math.round(f.savings*v5Bank().savings);f.savings+=interest;if(interest)v5Tx('rendimento',interest,'Juros da poupança em '+v5Bank().name,'savings');
 for(const l of f.loans){if(l.balance<=0||l.lastProcessed===S.year)continue;l.lastProcessed=S.year;
  const due=Math.min(Math.ceil(l.balance*(1+l.rate)),Math.max(1,l.installment));const interestLoan=Math.round(l.balance*l.rate);l.balance+=interestLoan;
  const paid=Math.min(S.cash,due,l.balance);S.cash-=paid;l.balance=Math.max(0,l.balance-paid);
  if(paid<due){l.arrears++;f.score=Math.max(300,f.score-24);change('stress',5);logStory('Não conseguiu pagar toda a parcela do empréstimo '+l.id+'.','sad');}
  else{f.score=Math.min(900,f.score+3);l.arrears=Math.max(0,l.arrears-1);}
  v5Tx('parcela',-paid,'Parcela '+l.bank+' (juros '+money(interestLoan)+')');
 }
 const c=f.card;if(c.balance>0){const due=Math.round(c.balance*.27),paid=Math.min(S.cash,due);S.cash-=paid;c.balance=Math.max(0,c.balance-paid);const interestCard=Math.round(c.balance*.19);c.balance+=interestCard;if(paid<due){c.missed++;f.score=Math.max(300,f.score-15);change('stress',4);}else f.score=Math.min(900,f.score+2);v5Tx('fatura',-paid,'Pagamento anual automático do cartão; juros '+money(interestCard));}
 c.limit=Math.max(5000,Math.round(5000+(f.score-400)*140));
}
function v5Passport(){v5Init();if(!requireLife(16))return false;const t=S.v5.travel,cost=Math.round(550*v4CostFactor());if(t.passport&&t.passport.expires>S.year+1)return notify('Seu passaporte já está válido até '+t.passport.expires+'.');if(S.cash<cost)return notify('Emissão custa '+money(cost)+'.','warn');if(!v3Allow('passport','global',1,{energy:5}))return false;S.cash-=cost;t.passport={issued:S.year,expires:S.year+10,country:S.country};v5Tx('documento',-cost,'Emissão de passaporte');logStory('Emitiu um passaporte com validade de dez anos.','milestone');save();render();return true;}
function v5Visa(country){v5Init();if(!requireLife(18))return false;if(!V4_COUNTRIES.has(country)||country===S.country)return false;const t=S.v5.travel,r=v5Rule(country);if(!t.passport||t.passport.expires<=S.year)return notify('Precisa de passaporte válido antes de pedir autorização.','warn');
 if(t.visas.some(x=>x.country===country&&x.expires>S.year))return notify('Você já tem autorização válida para '+country+'.');const fee=r.cost;if(S.cash<fee)return notify('Taxa de solicitação: '+money(fee)+'.','warn');if(!v3Allow('visa','country:'+country,1,{energy:10}))return false;
 S.cash-=fee;const score=(S.stats.reputation*.35+S.stats.intel*.25+Math.min(100,S.cash/20000)*.20+(S.job?15:3))-(S.crimeHeat||0)*.5;const approved=v3Chance(Math.min(.93,Math.max(.07,.38+(score-r.requirements)/140)));
 if(approved)t.visas.push({country,issued:S.year,expires:S.year+5,kind:'Residência simulada'});
 v5Tx('documento',-fee,'Solicitação de autorização: '+country);logStory(approved?'Autorização de residência concedida para '+country+'.':'Autorização de residência negada por '+country+'.',approved?'milestone':'event');save();render();notify(approved?'Autorização aprovada!':'Pedido negado. Pode tentar novamente no próximo ano.',approved?'ok':'warn');return approved;
}
function v5Travel(country){v5Init();if(!requireLife(16))return false;if(!V4_COUNTRIES.has(country)||country===S.country)return false;const t=S.v5.travel;
 if(!t.passport||t.passport.expires<=S.year)return notify('Emita um passaporte válido primeiro.','warn');const r=v5Rule(country);if(r.visa&&!t.citizenships.includes(country)&&!t.visas.some(x=>x.country===country&&x.expires>S.year))return notify('Precisa de autorização de entrada válida para este destino fictício.','warn');const price=Math.round((4000+r.cost/2)*v4CostFactor());if(S.cash<price)return notify('A viagem custa '+money(price)+'.','warn');if(!v3Allow('international_trip','global',2,{energy:15}))return false;
 if(!useEnergy(15,16)){v3RefundLimit('international_trip');return false;}
 S.cash-=price;t.visits.unshift({year:S.year,country,cost:price,home:S.country});S.counts.trips++;change('joy',6);change('stress',-4);v5Tx('viagem',-price,'Viagem turística a '+country);logStory('Visitou '+country+' e retornou para casa. Gastou '+money(price)+'.','event');save();render();return true;
}
function v5Immigrate(country,city){v5Init();if(!requireLife(18))return false;const t=S.v5.travel;if(country!==S.country&&!t.citizenships.includes(country)&&!t.visas.some(x=>x.country===country&&x.expires>S.year))return notify('Solicite uma autorização de residência para '+country+' antes de emigrar.','warn');const old=S.country;const success=v4Move(country,city);if(success){t.residence=S.country;if(old!==S.country){t.arrivedYear=S.year;t.visas=t.visas.filter(x=>x.country!==S.country);logStory('O novo endereço foi registrado nos documentos migratórios.','milestone');}save();render();}return !!success;}
function v5Naturalize(){v5Init();if(!requireLife(21))return false;const t=S.v5.travel;if(t.citizenships.includes(S.country))return notify('Você já possui a cidadania do país atual.');if(t.residence!==S.country)return notify('Precisa residir legalmente no país.','warn');const elapsed=Math.max(0,S.year-(t.arrivedYear||S.year));if(elapsed<5)return notify('Precisa de pelo menos cinco anos de residência (simulação).','warn');const fee=Math.round(6500*v4CostFactor());if(S.cash<fee)return notify('A taxa custa '+money(fee)+'.','warn');if(!v3Allow('naturalize','global',1,{energy:8}))return false;S.cash-=fee;t.citizenships.push(S.country);v5Tx('documento',-fee,'Naturalização simulada');logStory('Obteve cidadania de '+S.country+'.','milestone');save();render();return true;}
function v5SchoolClub(id){v5Init();const club=V5_SCHOOL_CLUBS[id];if(!club||!requireLife(club.minAge)||S.age>18)return notify('Este clube é voltado para estudantes entre '+club.minAge+' e 18 anos.','warn');if(S.cash<club.cost)return notify('Você não pode pagar a atividade escolar.','warn');
 if(!v3Allow('schoolclub_'+id,'global',1,{energy:7}))return false;if(!useEnergy(7,club.minAge)){v3RefundLimit('schoolclub_'+id);return false;}
 S.cash-=club.cost;S.v5.school.clubs.push({year:S.year,id,name:club.name});S.v3.school.yearlyEffort+=5;change(club.skill,4);change('joy',3);v5Tx('educacao',-club.cost,club.name);logStory('Participou de '+club.name+' na escola.','education');save();render();return true;}
function v5EntranceExam(){v5Init();if(!requireLife(16))return false;if(!v3Allow('entrance','global',1,{energy:15}))return false;if(!useEnergy(15,16)){v3RefundLimit('entrance');return false;}
 const s=S.v5.school,score=Math.round(Math.max(0,Math.min(100,S.stats.intel*.4+S.stats.discipline*.21+S.v3.school.grade*.24+S.v3.academic.performance*.15+v3Int(-17,18))));s.examScore=score;s.entrance.push({year:S.year,score,country:S.country,age:S.age});if(score>=75){s.scholarship=Math.max(s.scholarship,score>=90?.65:.35);logStory('Conquistou bolsa acadêmica de '+Math.round(s.scholarship*100)+'% no exame de ingresso.','milestone');}else logStory('Prestou exame de ingresso e tirou '+score+' pontos.','education');save();render();return score;}
function v5EducationWithScholarship(kind){v5Init();const e=S.education,prior={enrolled:e.enrolled,major:e.major},type=String(kind).split('|')[0];if(type!=='Graduação'||!S.v5.school.scholarship)return enroll(kind);
 const discount=Math.round(12000*S.v5.school.scholarship),prev=S.cash;S.cash+=discount;
 try{enroll(kind);}finally{if(S.education.enrolled===prior.enrolled&&S.education.major===prior.major){S.cash=Math.max(0,S.cash-discount);}else{logStory('Bolsa acadêmica reduziu o custo de matrícula em '+money(discount)+'.','education');S.v5.school.scholarship=0;}save();render();}
}
function v5MeetInterview(index,approach){v5Init();if(!requireLife(16))return false;const def=DB.jobs[Number(index)],spec=v3JobDef(def);if(!spec)return false;const issues=v3JobEligibility(spec);if(issues.length)return notify('Não atende aos requisitos: '+issues.join('; ')+'.','warn');
 if(!v3Allow('v5_interview','job:'+spec.name,1,{energy:12}))return false;if(!v3Allow('v5_all_interviews','career',4,{energy:12})){v3RefundLimit('v5_interview','job:'+spec.name);return false;}
 if(!useEnergy(12,16)){v3RefundLimit('v5_interview','job:'+spec.name);v3RefundLimit('v5_all_interviews','career');return false;}
 const strength=approach==='competencia'?(S.skills[spec.skill]||S.stats.discipline):approach==='comunicacao'?(S.skills['Comunicação']||0):S.stats.discipline;
 const chance=Math.max(.08,Math.min(.88,.31+(strength-45)*.006+(S.stats.reputation-50)*.003+(S.stats.intel-50)*.001-(S.v2.world.unemployment||0)*.002));const hired=v3Chance(chance);
 S.v5.interviews.unshift({year:S.year,job:spec.name,approach,score:Math.round(chance*100),hired});S.v5.interviews=S.v5.interviews.slice(0,80);
 if(hired){if(S.job)S.v3.career.history.unshift({job:S.job.name,employer:S.job.employer,years:S.job.years,salary:S.job.salary,ended:S.year});S.job={name:spec.name,sector:spec.sector,salary:Math.round(spec.annualPay*(.85+v3Rand()*.20)*v4SalaryFactor()*(.8+v4City().factor*.2)),level:1,years:0};v3UpgradeJob(S.job);S.careerYears=0;S.workQuality=45;change('joy',5);logStory('Conseguiu vaga de '+spec.name+' após entrevista em '+S.job.employer+'.','work');}
 else{change('stress',2);logStory('Não passou na entrevista para '+spec.name+'.','work');}
 save();render();notify(hired?'Você foi contratado!':'Entrevista não aprovada. Prepare-se para outra vaga.',hired?'ok':'warn');return hired;
}
function v5SocialLoan(personId,amount){v5Init();if(!requireLife(18))return false;amount=v5Amount(amount);const p=v3People().find(x=>String(x.id)===String(personId)&&x.alive);if(!p||!amount||amount<100||amount>30000)return false;
 if(S.cash<amount)return notify('Você não tem esse dinheiro para emprestar.','warn');if(!v3Allow('personal_loan','person:'+p.id,1,{energy:8}))return false;
 if(!useEnergy(8,18)){v3RefundLimit('personal_loan','person:'+p.id);return false;}
 S.cash-=amount;const loan={id:'sl'+S.year+'_'+p.id,personId:p.id,name:p.name,balance:amount,principal:amount,issued:S.year,due:S.year+2,closed:false};S.v5.social.loans.push(loan);p.bond=cap(p.bond+3);v3Memory(p,'Recebeu um empréstimo pessoal de '+money(amount)+' de você.',5,'financeiro');v5Tx('emprestimo_social',-amount,'Empréstimo para '+p.name);logStory('Emprestou '+money(amount)+' a '+p.name+'; há risco de atraso.','money');save();render();return true;}
function v5SocialCollect(id){v5Init();const l=S.v5.social.loans.find(x=>x.id===id&&!x.closed);if(!l)return false;const p=v3People().find(x=>String(x.id)===String(l.personId));if(!p||!p.alive){l.closed=true;return false;}if(!v3Allow('social_collect','person:'+p.id,1,{energy:5}))return false;
 const chance=Math.max(.1,Math.min(.92,.33+(p.trust-50)*.006+(p.wealth||0)/180000+(S.year-l.issued)*.06));if(!v3Chance(chance)){p.bond=cap(p.bond-3);v3Memory(p,'Você cobrou o empréstimo; ainda não conseguiu pagamento.',-3,'financeiro');save();render();return false;}
 const amount=Math.min(l.balance,Math.max(100,Math.round((p.wealth||l.balance)*.20)));l.balance=Math.max(0,l.balance-amount);l.closed=l.balance===0;S.cash+=amount;p.wealth=Math.max(0,(p.wealth||0)-amount);v5Tx('recebimento',amount,'Pagamento recebido de '+p.name);v3Memory(p,'Quitou parte do empréstimo.',3,'financeiro');logStory('Recebeu '+money(amount)+' de '+p.name+'.','money');save();render();return true;}
function v5FamilyMeeting(){v5Init();if(!requireLife(6))return false;const people=v3People().filter(p=>p.alive&&p.bond>0).slice(0,12),fee=Math.round(220+people.length*60);if(S.cash<fee)return notify('Encontro de família custa '+money(fee)+'.','warn');if(!v3Allow('family_reunion','global',1,{energy:12}))return false;if(!useEnergy(12,6)){v3RefundLimit('family_reunion');return false;}
 S.cash-=fee;const attended=people.filter(p=>p.trait==='Reservado'?v3Chance(.35):v3Chance(.7));for(const p of attended){p.bond=cap(p.bond+4);p.trust=cap(p.trust+1);v3Memory(p,'Participou de encontro familiar com '+S.name+'.',2,'família');}S.v5.social.gatherings.unshift({year:S.year,attended:attended.map(p=>p.name),cost:fee});v5Tx('familia',-fee,'Encontro familiar');logStory('Organizou encontro de família com '+attended.length+' convidados presentes.','event');save();render();return true;}
function v5BusinessPurchase(index,amount){v5Init();if(!requireLife(18))return false;const b=S.businesses[Number(index)];amount=v5Amount(amount);if(!b||!amount||amount<500||amount>100000)return false;v2EnrichBiz(b);if(S.cash<amount)return notify('Capital de giro insuficiente.','warn');if(!v3Allow('biz_stock','business:'+b.id,2,{energy:8}))return false;
 S.cash-=amount;b.v5=b.v5||{stock:0,productPrice:150,orders:0,revenue:0,cost:0,lastYear:S.year};b.v5.stock+=Math.max(1,Math.floor(amount/70));b.v5.cost+=amount;v5Tx('estoque',-amount,'Compra de insumos para '+b.name);logStory('Comprou insumos no valor de '+money(amount)+' para '+b.name+'.','money');save();render();return true;}
function v5BusinessPricing(index,price){v5Init();if(!requireLife(18))return false;const b=S.businesses[Number(index)];price=v5Amount(price);if(!b||price<50||price>4000)return false;v2EnrichBiz(b);if(!v3Allow('biz_price','business:'+b.id,1,{energy:5}))return false;b.v5=b.v5||{stock:0,productPrice:150,orders:0,revenue:0,cost:0,lastYear:S.year};b.v5.productPrice=price;logStory('Definiu preço de '+money(price)+' para uma linha de produtos de '+b.name+'.','work');save();render();return true;}
function v5AnnualBusinesses(){for(const b of S.businesses){if(!b.v5||b.v5.lastYear===S.year||!b.v5.stock)continue;const x=b.v5;x.lastYear=S.year;const interest=Math.max(.05,Math.min(1.0,(b.brand||50)/115+(b.quality||50)/180-(x.productPrice-150)/3000));const units=Math.min(x.stock,Math.round((6+(b.staff||1)*3+v3Int(0,20))*interest));const sale=units*x.productPrice;x.stock-=units;x.orders+=units;x.revenue+=sale;S.cash+=sale;v5Tx('venda',sale,'Produtos vendidos por '+b.name);if(units>0)logStory(b.name+' vendeu '+units+' itens nesta temporada.','money');S.v5.businessReports.unshift({year:S.year,business:b.name,units,revenue:sale,stock:x.stock});}S.v5.businessReports=S.v5.businessReports.slice(0,50);}
function v5AnnualSocial(){for(const l of S.v5.social.loans){if(l.closed||S.year<=l.issued)continue;const p=v3People().find(x=>String(x.id)===String(l.personId));if(!p||!p.alive){l.closed=true;l.writtenOff=true;logStory('O empréstimo pessoal de '+l.name+' foi baixado por impossibilidade de cobrança.','sad');continue;}if(S.year>=l.due&&v3Chance(.22)&&p.wealth>0){const amount=Math.min(l.balance,Math.max(100,Math.round(p.wealth*.12)));l.balance=Math.max(0,l.balance-amount);l.closed=l.balance===0;S.cash+=amount;p.wealth-=amount;v5Tx('recebimento',amount,'Pagamento espontâneo de '+p.name);}if(S.year>l.due&&!l.closed&&v3Chance(.20)){p.bond=cap(p.bond-2);v3Memory(p,'A dívida antiga permanece pendente.',-2,'financeiro');}}}
function v5AfterYear(){if(!S||!S.v5)return;v5Init();if(S.v5.processedYear===S.year)return;S.v5.processedYear=S.year;
 v5AnnualFinance();v5AnnualBusinesses();v5AnnualSocial();const t=S.v5.travel;if(t.residence!==S.country){t.residence=S.country;t.arrivedYear=S.year;}S.v5.yearReports.unshift({year:S.year,country:S.country,cash:S.cash,debt:S.debt,bank:S.v5.finance.savings+S.v5.finance.checking,credit:v5TotalLoans()+S.v5.finance.card.balance,worth:netWorth(S),score:S.v5.finance.score});S.v5.yearReports=S.v5.yearReports.slice(0,100);save();render();}
