/* VIDAVERSO 4.0 — motor de mercado, moeda, cassino e vida cotidiana.
   Quantias internas preservadas em créditos de referência BRL para migrar saves 1-3.
   Toda apresentação/conversão usa a moeda local; não são taxas de câmbio reais. */
'use strict';
function v4Country(name=S?.country){return V4_COUNTRIES.get(name)||V4_COUNTRIES.get('Brasil');}
function v4City(city=S?.city,country=S?.country){return v4Country(country).cities.find(c=>c.name===city)||v4Country(country).cities[0];}
function v4ToLocal(value,country=S?.country){return Number(value||0)/v4Country(country).brlPerUnit;}
function v4FromLocal(value,country=S?.country){return Number(value||0)*v4Country(country).brlPerUnit;}
function v4Format(value,country=S?.country,small=false){const c=v4Country(country),local=v4ToLocal(value,country),abs=Math.abs(local),sign=local<0?'-':'';if(small&&abs>=1e9)return sign+new Intl.NumberFormat(c.locale,{maximumFractionDigits:1}).format(abs/1e9)+' bi '+c.currency;if(small&&abs>=1e6)return sign+new Intl.NumberFormat(c.locale,{maximumFractionDigits:1}).format(abs/1e6)+' mi '+c.currency;if(small&&abs>=100000)return sign+new Intl.NumberFormat(c.locale,{maximumFractionDigits:0}).format(abs/1000)+' mil '+c.currency;try{return new Intl.NumberFormat(c.locale,{style:'currency',currency:c.currency,maximumFractionDigits:c.currency==='JPY'||c.currency==='KRW'||c.currency==='VND'?0:2}).format(local);}catch(e){return c.currency+' '+Math.round(local).toLocaleString('pt-BR');}}
money=function(n){return v4Format(n);};
shortMoney=function(n){return v4Format(n,undefined,true);};
function v4Hash(s){let h=2166136261;for(const ch of String(s)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
function v4Init(){if(!S)return;
 v3Init();if(!S.v4)S.v4={version:4,orientation:'Ainda não definiu',rental:null,marketCity:'',marketFilter:'Todos',marketPage:0,vehicleFilter:'Todos',casino:{games:0,wagered:0,won:0,history:[],year:S.year,round:null},nightHistory:[],filmDiary:[],relationshipDiary:[],fxHistory:[],mortgages:[],countryEvents:[],localChallenges:[],migratedFrom3:true};
 const v=S.v4;v.version=4;v.orientation=v.orientation||'Ainda não definiu';v.casino=v.casino||{games:0,wagered:0,won:0,history:[],year:S.year,round:null};v.casino.history=v.casino.history||[];v.nightHistory=v.nightHistory||[];v.filmDiary=v.filmDiary||[];v.relationshipDiary=v.relationshipDiary||[];v.fxHistory=v.fxHistory||[];v.mortgages=v.mortgages||[];v.countryEvents=v.countryEvents||[];v.localChallenges=v.localChallenges||[];
 if(!v4Country().cities.some(c=>c.name===v.marketCity))v.marketCity=v4City().name;
 if(!Number.isFinite(v.marketPage))v.marketPage=0;
 if(S.royal&&!v4Country().monarchy){S.royal=false;if(S.mode==='royal')S.mode='normal';if(!v.royalReconciled){logStory('O título real não se aplica à república onde você vive; a realeza foi desativada.','event');v.royalReconciled=true;}}
}
function v4SalaryFactor(country=S?.country){const groups={
 'Estados Unidos':4.1,'Canadá':3.5,'Japão':3.0,'Reino Unido':3.6,'Portugal':2.1,'Espanha':2.3,'França':3.1,'Alemanha':3.3,'Itália':2.5,'Holanda':3.5,'Bélgica':3.2,'Suíça':5.6,
 'Áustria':3.2,'Dinamarca':4.0,'Noruega':4.5,'Suécia':3.8,'Finlândia':3.2,'Irlanda':3.5,'Polônia':1.65,'República Tcheca':1.65,'Grécia':1.75,'Turquia':1.4,'Coreia do Sul':2.85,
 'Austrália':4,'Nova Zelândia':3.3,'Singapura':3.6,'Emirados Árabes Unidos':3.6,'Arábia Saudita':2.9,'Israel':3.1,'China':1.5,'Taiwan':2.3,'México':1.3,'Argentina':1.15,'Chile':1.4,'Uruguai':1.3,
 'Índia':.78,'Nigéria':.8,'Quênia':.7,'África do Sul':1.12,'Egito':.8,'Bangladesh':.65,'Filipinas':.85,'Indonésia':.81,'Malásia':1.2
};return groups[country]||1.18;}
function v4CostFactor(){return Math.max(.45,Math.min(10,(0.6+v4SalaryFactor()*.52)*(0.6+v4City().factor*.4)));}
function v4MarketFactor(country=S?.country){return country==='Estados Unidos'?5:country==='Canadá'?3.7:country==='Japão'?3.5:country==='Reino Unido'?5:country==='Austrália'?4.0:country==='Suíça'?5.8:country==='Singapura'?5.2:country==='Nova Zelândia'?3.7:country==='Brasil'?1:2.3;}
function v4Listings(country=S?.country,city){const c=v4Country(country),cities=city?[v4City(city,country)]:c.cities;const data=[];
 for(const place of cities){V4_PROPERTY_TYPES.forEach((type,i)=>{for(let variant=0;variant<5;variant++){const key=country+'|'+place.name+'|'+i+'|'+variant;const rand=v4Hash(key+'|v4')%101;const quality=45+rand%51;const marketExtra=.82+variant*.11+(rand%13)/100;const base=Math.round(type.base*place.factor*v4MarketFactor(country)*marketExtra);const price=Math.max(8000,base);const rent=type.rent?Math.round(price*type.rent):0;const area=Math.round(type.area*(.78+variant*.14+(rand%9)/100));data.push({id:key,city:place.name,country,type:type.name,area,quality,price,rent,variant,name:type.name+' em '+place.name});}});}
 return data;}
function v4PropertyById(id){const [country,city]=String(id).split('|');if(country!==S.country)return null;return v4Listings(country,city).find(x=>x.id===id)||null;}
function v4Spend(amount,reason){if(!Number.isFinite(amount)||amount<0||S.cash+0.00001<amount){notify('Saldo insuficiente: '+money(amount)+' necessários.','warn');return false;}S.cash-=amount;if(typeof v2Ledger==='function')v2Ledger('gasto',-amount,reason);return true;}
function v4BuyProperty(id,finance=false){v4Init();if(!requireLife(18))return false;const item=v4PropertyById(id);if(!item)return notify('O anúncio não está disponível nessa localidade.','warn');
 const fees=Math.round(item.price*.04),down=finance?Math.round(item.price*.30):item.price,cost=down+fees;
 if(S.cash<cost)return notify('Precisa de '+money(cost)+' para esta compra'+(finance?' com entrada de 30%':'')+'.','warn');
 if(!v3Allow('purchase_home','global',5,{energy:8,message:'Você atingiu o limite de aquisições neste ano.'}))return false;
 if(!useEnergy(8,18)){v3RefundLimit('purchase_home');return false;}
 if(!v4Spend(cost,'Compra '+item.name))return false;
 const balance=finance?item.price-down:0;
 if(balance){S.debt+=balance;S.v4.mortgages.push({id:item.id,original:balance,year:S.year,listing:item.name});}
 const prop={id:Date.now()+v3Rand(),name:item.name,city:item.city,country:item.country,type:item.type,area:item.area,condition:item.quality,quality:item.quality,acquiredYear:S.year,purchasePrice:item.price,value:item.price,rent:item.rent,rented:false,loanRemaining:balance,marketListing:item.id};
 S.homes.push(v3Home(prop));logStory('Comprou '+item.name+' por '+money(item.price)+(finance?' (entrada e financiamento).':'.'),'money');change('joy',4);save();render();notify('Imóvel adquirido! Impostos e conservação serão calculados anualmente.');return true;}
function v4RentProperty(id){v4Init();if(!requireLife(18))return false;const item=v4PropertyById(id);if(!item||!item.rent)return notify('Esta propriedade não está disponível para locação.','warn');
 const deposit=item.rent*2;if(S.cash<deposit)return notify('Para entrar no imóvel, é necessário um caução de '+money(deposit)+'.','warn');
 if(item.city!==S.city)return notify('Para alugar e morar em '+item.city+', primeiro mude sua residência para essa cidade.','warn');
 if(!v3Allow('new_rental','global',2,{energy:5}))return false;
 if(!useEnergy(5,18)){v3RefundLimit('new_rental');return false;}
 v4EndRental(false);S.cash-=deposit;S.v4.rental={id:item.id,name:item.name,city:item.city,country:S.country,annualRent:item.rent*12,deposit,started:S.year,lastPaidYear:S.year};
 logStory('Passou a morar de aluguel em '+item.name+'; caução de '+money(deposit)+'.','money');save();render();notify('Contrato de locação assinado. Aluguel será cobrado a cada ano.');return true;}
function v4EndRental(userInitiated=true){if(!S.v4?.rental)return;const r=S.v4.rental;const age=Math.max(0,S.year-r.started);const refund=Math.round(r.deposit*(age===0?.8:1));S.cash+=refund;logStory('Encerrou o aluguel de '+r.name+' e recebeu '+money(refund)+' de caução devolvida.','money');S.v4.rental=null;if(userInitiated){save();render();notify('Contrato encerrado.');}}
function v4VehicleOffer(index){const [name,type,price,cost]=V4_VEHICLE_CATALOG[Number(index)]||[];if(!name)return null;const factor=type==='Aeronave'||type==='Náutico'?1:Math.max(.85,Math.min(1.45,v4MarketFactor()/3));return {name,type,price:Math.round(price*factor),cost:Math.round(cost*factor)};}
function v4BuyVehicle(index){v4Init();if(!requireLife(16))return;const o=v4VehicleOffer(index);if(!o)return;const tax=Math.round(o.price*.055);if(S.cash<o.price+tax)return notify('Você precisa de '+money(o.price+tax)+' incluindo taxas.','warn');
 if(!v3Allow('vehicle_buy','global',4,{energy:7}))return;if(!useEnergy(7,16)){v3RefundLimit('vehicle_buy');return;}
 v4Spend(o.price+tax,'Veículo '+o.name);S.vehicles.push({id:Date.now()+v3Rand(),name:o.name,type:o.type,value:o.price,cost:o.cost,year:S.year,mileage:0});
 logStory('Comprou '+o.name+' pagando '+money(o.price)+' mais taxas.','money');change('joy',4);save();render();notify('Veículo adquirido! Custos anuais e desvalorização serão aplicados.');}
function v4CurrencyChange(oldCountry,newCountry){const c1=v4Country(oldCountry),c2=v4Country(newCountry);if(c1.currency===c2.currency)return;
 const before=v4Format(S.cash,oldCountry),after=v4Format(S.cash,newCountry);
 S.v4.fxHistory.unshift({year:S.year,from:oldCountry,to:newCountry,before,after,rate:c1.brlPerUnit/c2.brlPerUnit});S.v4.fxHistory=S.v4.fxHistory.slice(0,40);
 logStory('Seu saldo foi convertido de '+before+' para '+after+' na moeda de '+newCountry+'.','money');}
function v4Move(country,city){v4Init();if(!requireLife(18))return false;const target=v4Country(country);if(target.name!==country)return notify('País inválido.','warn');if(!target.cities.some(c=>c.name===city))return notify('Cidade inválida.','warn');if(S.country===country&&S.city===city)return notify('Você já mora nessa cidade.','warn');
 const domestic=S.country===country;const cost=domestic?2600:11000;
 if(S.cash<cost)return notify('Mudança exige '+money(cost)+'.','warn');
 if(!v3Allow('relocate','global',1,{energy:18,message:'Você já mudou de residência este ano.'}))return false;
 if(!useEnergy(18,18)){v3RefundLimit('relocate');return false;}
 if(!v4Spend(cost,'Mudança para '+city))return false;
 const previous=S.country,previousCity=S.city;
 if(S.v4.rental)v4EndRental(false);
 S.country=country;S.city=city;S.v4.marketCity=city;S.v4.marketPage=0;S.job=null;
 if(S.royal&&!target.monarchy){S.royal=false;if(S.mode==='royal')S.mode='normal';logStory('Ao sair de uma monarquia, perdeu os privilégios de representação real.','event');}
 if(!domestic)v4CurrencyChange(previous,country);
 change('joy',3);S.v3.movedYear=S.year;S.v3.moves=(S.v3.moves||0)+1;
 logStory('Mudou-se de '+previousCity+' para '+city+', '+country+'.','milestone');save();render();notify('Nova vida em '+city+'! Salários e preços são mostrados em '+target.currency+'.');return true;}
function v4PickCity(country){const c=V4_COUNTRIES.get(country);if(!c)return;openQuestion('Mudar para '+country,'Escolha uma cidade. Cada localidade tem salários, imóveis, aluguel e custo de vida próprios. A economia e as taxas de câmbio são fictícias.',c.cities.map(x=>({label:x.name+' · nível de custo '+x.factor.toFixed(2),action:()=>v4Move(country,x.name)})).concat([{label:'Cancelar'}]));}
function v4CasinoStake(){const raw=Number(document.getElementById('v4Stake')?.value||100);return Number.isFinite(raw)?Math.floor(raw):0;}
function v4CasinoStart(kind,option,stake){v4Init();if(!requireLife(18))return;if(S.prison>0)return notify('Cassino indisponível enquanto cumpre pena.','warn');if(S.v4.casino.round)return notify('Termine sua partida de blackjack primeiro.','warn');
 stake=Math.round(stake||v4CasinoStake());if(stake<20||stake>50000)return notify('Aposta permitida: de '+money(20)+' a '+money(50000)+'.','warn');if(S.cash<stake)return notify('Saldo insuficiente para apostar.','warn');
 if(!v3Allow('casino_spin','global',5,{energy:5,message:'Seu limite de cinco rodadas por ano foi atingido.'}))return;
 if(!useEnergy(5,18)){v3RefundLimit('casino_spin');return;}
 S.cash-=stake;S.v4.casino.games++;S.v4.casino.wagered+=stake;
 let payout=0,description='';
 if(kind==='roulette'){const number=v3Int(0,36),red=new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);const color=number===0?'verde':red.has(number)?'vermelho':'preto';payout=(color===option?2:0)*stake;description='Roleta: número '+number+' ('+color+').';}
 else if(kind==='slots'){const symbols=['🍒','🍒','🍋','🍋','⭐','💎'];const values=Array.from({length:3},()=>v3Pick(symbols));const triple=values[0]===values[1]&&values[1]===values[2];payout=triple?stake*(values[0]==='💎'?12:values[0]==='⭐'?8:5):values.filter(x=>x==='🍒').length===2?Math.round(stake*1.5):0;description='Caça-níqueis: '+values.join(' ')+'.';}
 else if(kind==='blackjack'){const draw=()=>v3Int(1,13);S.v4.casino.round={bet:stake,player:[draw(),draw()],dealer:[draw(),draw()],year:S.year};save();render();notify('Blackjack iniciado. Compre carta ou pare.');return;}
 else {S.cash+=stake;v3RefundLimit('casino_spin');return;}
 v4CasinoResult(kind,stake,payout,description);}
function v4BlackjackValue(cards){let total=0,aces=0;for(const n of cards){if(n===1){aces++;total+=11;}else total+=Math.min(n,10);}while(total>21&&aces>0){total-=10;aces--;}return total;}
function v4BlackjackAction(choice){v4Init();const round=S.v4.casino.round;if(!round||round.year!==S.year)return notify('Nenhuma partida ativa.','warn');if(choice==='hit'){round.player.push(v3Int(1,13));if(v4BlackjackValue(round.player)>21){S.v4.casino.round=null;v4CasinoResult('blackjack',round.bet,0,'Você estourou com '+v4BlackjackValue(round.player)+' pontos.');return;}save();render();return;}
 if(choice==='stand'){while(v4BlackjackValue(round.dealer)<17)round.dealer.push(v3Int(1,13));const player=v4BlackjackValue(round.player),dealer=v4BlackjackValue(round.dealer);const outcome=dealer>21||player>dealer?2:player===dealer?1:0;const natural=round.player.length===2&&player===21;
 const payout=Math.round(round.bet*(outcome===2&&natural?2.5:outcome));S.v4.casino.round=null;v4CasinoResult('blackjack',round.bet,payout,'Você marcou '+player+'; a banca marcou '+dealer+'.');}}
function v4CasinoResult(game,bet,payout,description){S.cash+=payout;S.v4.casino.won+=payout;const net=payout-bet;
 S.v4.casino.history.unshift({year:S.year,game,bet,payout,net,description});S.v4.casino.history=S.v4.casino.history.slice(0,80);
 change('stress',net<0?3:-1);change('joy',net>=0?2:-3);logStory(description+' Resultado: '+(net>=0?'+':'')+money(net)+'.','money');save();render();openInfo(net>0?'Você ganhou!':net===0?'Empate':'Você perdeu',description+' Resultado líquido: '+money(net)+'. Cassino fictício, sem dinheiro real.');}
function v4SetOrientation(value){const allowed=['Heterossexual','Homossexual','Bissexual','Pansexual','Assexual','Ainda não definiu'];if(!allowed.includes(value))return;v4Init();S.v4.orientation=value;logStory('Refletiu sobre a própria identidade e registrou sua orientação.','note');save();render();notify('Preferência pessoal atualizada.');}
function v4NightOut(kind,withPersonId){v4Init();const minAge=kind==='Cinema'||kind==='Café noturno'?12:18;if(!requireLife(minAge))return;if(S.prison>0)return notify('Não é possível sair durante o cumprimento da pena.','warn');if(!V4_NIGHT_SPOTS.includes(kind))return;
 const costs={Cinema:85,'Bar com música ao vivo':170,Boate:320,'Festival local':450,'Café noturno':70,Show:410};const cost=Math.round(costs[kind]*(v4City().factor*.5+.5));if(S.cash<cost)return notify('Essa saída custa '+money(cost)+'.','warn');
 if(withPersonId&&minAge>=18){const person=v3People().find(p=>String(p.id)===String(withPersonId)&&p.alive);if(person&&person.age<18)return notify('Esse programa é exclusivo para maiores de 18 anos.','warn');}
 if(!v3Allow('night_'+kind,'global',1,{energy:10,message:'Você já fez esse programa neste ano.'}))return;
 if(!useEnergy(10,minAge)){v3RefundLimit('night_'+kind);return;}
 v4Spend(cost,'Programa '+kind);let film='',person=null,outcome='';if(withPersonId)person=v3People().find(p=>String(p.id)===String(withPersonId)&&p.alive);
 if(kind==='Cinema'){film=v3Pick(V4_MEDIA[S.country]||V4_MEDIA.default);S.v4.filmDiary.unshift({year:S.year,age:S.age,city:S.city,title:film,with:person?.name||'sozinho(a)'});}
 if(person){const key='night_bond_'+kind;const allowed=v3Allow(key,'person:'+person.id,1,{message:'Vocês já fizeram esse programa juntos neste ano.'});if(allowed){let bonus=kind==='Cinema'?4:kind==='Café noturno'?5:7;bonus+=person.trait==='Reservado'?-2:person.trait==='Generoso'?2:0;person.bond=cap(person.bond+bonus);person.trust=cap(person.trust+2);v3Memory(person,'Saíram para '+(film?'assistir a '+film:kind.toLowerCase())+' em '+S.city+'.',bonus,'lazer');}}
 const favorable=v3Chance(S.stats.stress>65?.38:.74);outcome=favorable?'Foi uma experiência agradável.':'A noite foi cansativa e não saiu como você esperava.';
 change('joy',favorable?8:2);change('stress',favorable?-3:3);
 const description=kind==='Cinema'?'Você assistiu a '+film+' no cinema de '+S.city+'.': 'Você foi a '+kind.toLowerCase()+' em '+S.city+'.';
 const text=description+(person?' Estava com '+person.name+'.':' ')+outcome;
 S.v4.nightHistory.unshift({year:S.year,age:S.age,city:S.city,kind,person:person?.name||null,film,cost,outcome});S.v4.nightHistory=S.v4.nightHistory.slice(0,140);logStory(text,'event');save();render();openInfo(kind,text+' Gastou '+money(cost)+'.');}
function v4StartDating(){v4Init();if(!requireLife(16))return;if(S.partner||S.spouse)return notify('Você já está em um relacionamento.','warn');
 if(!v3Allow('start_romance','global',1,{energy:12,message:'Você já buscou um relacionamento neste ano.'}))return;
 if(!useEnergy(12,16)){v3RefundLimit('start_romance');return;}
 const orientation=S.v4.orientation;let partnerGender=v3Pick(['F','M']);if(orientation==='Heterossexual')partnerGender=S.gender==='M'?'F':'M';if(orientation==='Homossexual')partnerGender=S.gender;
 const baseAge=S.age<18?S.age:Math.max(18,S.age+v3Int(-5,5));
 const companion=v2RandomAgent({name:mkPerson(partnerGender),gender:partnerGender,age:baseAge,bond:v3Int(45,78),years:0},'Namoro');
 S.partner=v3UpgradePerson(companion,'Namoro');S.counts.partners++;change('joy',9);change('Comunicação',3);
 logStory('Conheceu '+companion.name+' e começou um namoro.','milestone');save();render();openInfo('Um novo romance','Você conheceu '+companion.name+'. A relação terá confiança, personalidade, memórias e decisões ao longo dos anos.');}
function v4RomanceAction(kind){v4Init();if(!requireLife(18))return;const p=S.spouse||S.partner;if(!p||!p.alive)return notify('Você precisa de um parceiro adulto e disponível.','warn');if(p.age!==undefined&&p.age<18)return notify('A intimidade é exclusiva para adultos.','warn');
 const options={flertar:{cost:0,gain:4,stress:1},encontro:{cost:220,gain:7,stress:-3},intimidade:{cost:0,gain:9,stress:-5}};const opt=options[kind];if(!opt)return;
 if(S.cash<opt.cost)return notify('Saldo insuficiente.','warn');if(!v3Allow('romance_'+kind,'person:'+p.id,1,{energy:8,message:'Essa interação já aconteceu neste ano.'}))return;
 if(!useEnergy(8,18)){v3RefundLimit('romance_'+kind,'person:'+p.id);return;}
 if(opt.cost)v4Spend(opt.cost,'Encontro com '+p.name);
 const consent=v3Chance(Math.max(.08,Math.min(.94,.28+p.bond/190+(p.trust||50)/300-(p.trait==='Desconfiado'?.18:0))));
 if(consent){p.bond=cap(p.bond+opt.gain);p.trust=cap((p.trust||50)+2);change('joy',4);change('stress',opt.stress);v3Memory(p,'Um momento romântico respeitoso e consensual fortaleceu a relação.',opt.gain,'romance');}
 else {change('stress',1);p.bond=cap(p.bond-1);}
 const text=consent?(kind==='intimidade'?'Vocês conversaram, confirmaram seus limites e compartilharam uma noite íntima.':'Vocês compartilharam um momento romântico e agradável.'):'Seu parceiro não estava confortável com o convite. Você respeitou a decisão.';
 S.v4.relationshipDiary.unshift({year:S.year,partner:p.name,kind,consent,text});S.v4.relationshipDiary=S.v4.relationshipDiary.slice(0,70);logStory(text,'event');save();render();openInfo(consent?'Uma noite especial':'Respeitar limites',text);}
function v4CountryLifeEvent(){const stories={
 Brasil:['O Carnaval movimentou eventos culturais e oportunidades de trabalho em sua cidade.','Uma feira gastronômica local reuniu vizinhos e pequenos empreendedores.'],
 Japão:['Um matsuri tradicional reuniu moradores e visitantes.','Uma convenção de mangá e animação abriu oportunidades para artistas iniciantes.'],
 'Estados Unidos':['Um festival de cinema trouxe novas oportunidades para artistas locais.','Uma feira de tecnologia abriu portas para jovens profissionais.'],
 Índia:['Uma mostra de cinema indiano movimentou a cena artística local.'],
 'Coreia do Sul':['Um festival de música reuniu novos talentos e produtores.'],
 França:['A semana cultural trouxe desfiles e exposições para sua região.'],
 Itália:['Uma mostra de arte e gastronomia impulsionou pequenos negócios.'],
 Portugal:['Um festival de música tradicional encheu o centro histórico.'],
 'Reino Unido':['Um festival de teatro atraiu visitantes à cidade.'],
 Argentina:['Uma competição de futebol mobilizou torcedores e comércio local.'],
 Austrália:['Um campeonato de surfe atraiu atletas e turistas.'],
 Quênia:['Uma campanha de conservação ambiental mobilizou sua comunidade.']
};const events=stories[S.country]||['Um evento cultural em '+S.city+' movimentou a cidade e inspirou novas amizades.'];
 if(v3Chance(.28)){const choice=v3Pick(events);const last=S.v4.countryEvents[0];if(!last||last.text!==choice||S.year-last.year>3){S.v4.countryEvents.unshift({year:S.year,text:choice,country:S.country,city:S.city});S.v4.countryEvents=S.v4.countryEvents.slice(0,35);logStory(choice,'event');}}
}
function v4MortgageAnnual(){for(const mortgage of S.v4.mortgages){mortgage.balance=Math.min(mortgage.balance,Math.max(0,S.debt));if(mortgage.balance<=0)continue;const annual=Math.max(300,Math.round(mortgage.original*.075));const payAmount=Math.min(annual,mortgage.balance,S.cash,Math.max(0,S.debt));if(payAmount>0){S.cash-=payAmount;S.debt-=payAmount;mortgage.balance-=payAmount;}const h=S.homes.find(p=>p.marketListing===mortgage.id);if(h)h.loanRemaining=mortgage.balance;}S.v4.mortgages=S.v4.mortgages.filter(m=>m.balance>0);}
function v4SellProperty(idx){if(!requireLife(18))return;const house=S.homes[idx];if(!house)return;const mortgage=S.v4.mortgages.find(m=>m.id===house.marketListing&&m.balance>0);const payoff=mortgage?.balance||0;const fee=Math.round(house.value*.035);const net=house.value-fee-payoff;
 openQuestion('Vender '+house.name+'?','Oferta de '+money(house.value)+'. Comissão e impostos de '+money(fee)+(payoff?'; quitação da hipoteca de '+money(payoff):'')+'. Resultado líquido: '+money(net)+'.',[
 {label:'Cancelar'},{label:'Confirmar venda',action:()=>{S.cash+=house.value-fee;if(payoff){S.cash-=payoff;S.debt=Math.max(0,S.debt-payoff);mortgage.balance=0;}S.homes.splice(idx,1);logStory('Vendeu '+house.name+' por '+money(house.value)+' após custos e dívidas.','money');save();render();}}
 ]);
}
function v4AfterYear(){v4Init();const v=S.v4;
 if(S.age>=18){const baseline=S.lastYearReport?.living||0;const already=S.v3.countryCost||0;const adjustment=Math.round(baseline*(v4CostFactor()-1))-already;if(Number.isFinite(adjustment)){S.cash-=adjustment;if(S.cash<0){S.debt+=-S.cash;S.cash=0;}v.lastLocationCost=adjustment;}}
 if(v.rental&&v.rental.lastPaidYear!==S.year){const fee=v.rental.annualRent;v.rental.lastPaidYear=S.year;const paid=Math.min(S.cash,fee);S.cash-=paid;if(paid<fee){S.debt+=fee-paid;change('stress',8);logStory('Não conseguiu pagar integralmente o aluguel de '+v.rental.name+' e contraiu dívida.','sad');}else logStory('Pagou '+money(fee)+' de aluguel anual em '+v.rental.city+'.','money');}
 for(const vehicle of S.vehicles){if(vehicle.type&&vehicle.cost){const extra=vehicle.type==='Aeronave'?Math.round(vehicle.cost*.25):vehicle.type==='Náutico'?Math.round(vehicle.cost*.12):Math.round(vehicle.cost*.08);const paid=Math.min(S.cash,extra);S.cash-=paid;if(paid<extra)S.debt+=extra-paid;vehicle.mileage=(vehicle.mileage||0)+v3Int(1000,18000);}}
 // Receitas e despesas do motor original permanecem em unidades de referência BRL.
 if(v.casino.round&&v.casino.round.year<S.year){const r=v.casino.round;v.casino.round=null;v.casino.history.unshift({year:S.year,game:'blackjack',bet:r.bet,payout:0,net:-r.bet,description:'Rodada abandonada'});}
 v4MortgageAnnual();v4CountryLifeEvent();
 if(v4Country().monarchy&&S.royal&&v3Chance(.09))logStory('Participou de uma solenidade da casa real de '+S.country+'.','event');
 if(v3Chance(.13)){const films=V4_MEDIA[S.country]||V4_MEDIA.default;logStory('O cinema local anunciou uma nova sessão de '+v3Pick(films)+'; a programação da cidade movimentou seus conhecidos.','event');}
 v4SyncAssets();save();}
function v4SyncAssets(){if(!S||!S.v4)return;S.v4.audit={countries:V4_COUNTRY_LINES.length,cityProfiles:V4_COUNTRY_LINES.reduce((n,c)=>n+c.cities.length,0),marketTemplates:V4_PROPERTY_TYPES.length,marketOffersPerCity:V4_PROPERTY_TYPES.length*5,vehicles:V4_VEHICLE_CATALOG.length,countryJobs:V4_LOCAL_JOBS.length,royalCountries:V4_COUNTRY_LINES.filter(c=>c.monarchy).length};}
