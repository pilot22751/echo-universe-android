/* Adaptação retrocompatível das ações e da interface 2.0 ao motor 3.0. */
'use strict';
const v3OriginalMakeLife=makeLife;
makeLife=function(config={}){v3OriginalMakeLife(config);v3Init();save();render();};
const v3OriginalRestore=restore;
restore=function(){const result=v3OriginalRestore();if(result){v3Init();save();}return result;};
const v3OriginalImport=importBackup;
importBackup=function(raw){const prev=S;v3OriginalImport(raw);if(S!==prev){v3Init();save();render();}};
const v3OriginalAge=ageOneYear;
ageOneYear=function(){if(!requireLife())return;v3BeforeYear();v3OriginalAge();v3AfterYear();};
const v3OriginalApplyJob=applyJob;
applyJob=function(index){return v3ApplyJob(index);};
const v3OriginalEnroll=enroll;
enroll=function(kind){if(!requireLife(18))return;const type=String(kind).split('|')[0],major=String(kind).split('|')[1];if(!DB.degrees.includes(major)){notify('Selecione uma formação válida.','warn');return;}
 if(!S.v3.school.graduated){notify('Você ainda precisa concluir a educação básica.','warn');return;}
 if(type==='Pós-graduação'&&S.education.level<1||type==='Doutorado'&&S.education.level<2){notify('Conclua a formação anterior.','warn');return;}
 v3OriginalEnroll(kind);
};
const v3OriginalChooseEvent=chooseEvent;
chooseEvent=function(){if(S?.v3&&v3Chance(.65)&&v3ChooseEvent())return;v3OriginalChooseEvent();};
const v3OriginalAdvancedEvent=v2ChooseAdvancedEvent;
v2ChooseAdvancedEvent=function(){if(S?.v3&&v3Chance(.65)&&v3ChooseEvent())return true;return v3OriginalAdvancedEvent();};
const v3OriginalV2Act=v2Act;
v2Act=function(name,arg){if(!S)return false;v3Init();
 if(name==='v2Relationship'){
  const [id,rawKind]=String(arg||'').split('|'),kind=rawKind||'talk';const p=v2PersonById(id);
  if(!p||!p.alive){notify('Essa pessoa não está disponível para conversar.','warn');return true;}
  const type=kind==='advice'?'talk':kind;
  if(!v3Allow('relationship_'+type,'person:'+p.id,kind==='conflict'?2:1,{energy:10,cost:kind==='present'?600:0,message:'Você já realizou essa interação com '+p.name+' neste ano.'}))return true;
  const bond=p.bond,trust=p.trust;const before=S.cash;const worked=v3OriginalV2Act(name,arg);
  if(S.cash!==before||p.bond!==bond||p.trust!==trust){
    const bias=p.trait==='Desconfiado'?-3:p.trait==='Leal'?2:p.trait==='Generoso'?3:p.trait==='Reservado'&&kind==='talk'?-2:p.trait==='Competitivo'&&kind==='conflict'?-6:0;
    p.bond=cap(p.bond+bias);p.trust=cap(p.trust+(kind==='conflict'?-Math.round((100-p.patience)/15):p.trait==='Desconfiado'?-2:1));p.lastContactYear=S.year;
    const outcome=p.bond-bond;v3Memory(p,'A interação de '+kind+' mudou o vínculo em '+outcome+' pontos.',outcome,'relacionamento');
    if(kind==='conflict'&&outcome<-6)S.v3.scheduled.push({due:S.year+v3Int(2,5),targetId:p.id,bond:-2,text:'Uma discussão antiga com '+p.name+' voltou a pesar na confiança.'});
    save();render();
  }
  return worked;
 }
 const gated={
  v2CareerProject:['project','job',1,18,0],v2SideGig:['sidegig','career',2,22,0],v2Mentor:['mentoria','career',1,14,900],v2Certification:['certificado','career',2,18,3500],v2NewEvent:['discover','global',1,8,0]
 };
 if(gated[name]){const [type,entity,max,energy,cost]=gated[name];if(!v3Allow(type,entity,max,{energy,cost,message:'Você já atingiu o limite anual desta ação.'}))return true;const result=v3OriginalV2Act(name,arg);return result;}
 if(name==='v2BizAction'){
  const [raw,kind]=String(arg||'').split('|'),b=S.businesses[Number(raw)];if(!b)return true;
  const estCost=kind==='marketing'?Math.round(b.value*.035)+400:kind==='pesquisa'?Math.round(b.value*.045)+600:kind==='cultura'?2200+b.staff*230:kind==='qualidade'?2000+Math.round(b.value*.025):0;
  if(!v3Allow('business_'+kind,'business:'+b.id,1,{energy:14,cost:estCost,message:'Sua empresa já adotou essa medida neste ano.'}))return true;
  return v3OriginalV2Act(name,arg);
 }
 if(name==='v2Habit'){
  if(!v3Allow('habit_'+arg,'global',1,{energy:12,message:'Você já cultivou esse hábito neste ano.'}))return true;
 }
 return v3OriginalV2Act(name,arg);
};
const v3OriginalAction=action;
const V3_ACTION_LIMITS={
 meditate:['meditate',1,10,0,0],gym:['exercise',1,16,8,0],doctor:['doctor',1,12,0,350],therapy:['therapy',2,12,12,320],salon:['salon',1,10,13,240],library:['library',2,12,4,0],study:['study',2,15,5,0],course:['course',1,15,12,900],hobby:['hobby',2,12,5,0],volunteer:['volunteer',1,14,8,0],party:['party',1,15,14,360],travel:['travel',2,20,12,0],pet:['adopt_pet',2,8,8,450],friends:['meet_friend',2,12,6,0],dating:['start_romance',1,12,16,0],dateNight:['date',1,10,16,0],
 overtime:['overtime',1,22,16,0],raise:['raise',1,12,16,0],promotion:['promotion',1,18,16,0],prisonStudy:['prison_read',1,12,16,0],prisonGoodBehavior:['prison_good',1,15,16,0],royalDuty:['royal_duty',1,16,16,0],royalBanquet:['royal_banquet',1,18,18,7000],royalVisit:['royal_visit',1,18,18,5000],royalMarriage:['royal_marriage',1,20,18,35000],lawyer:['appeal',1,0,18,30000],election:['election',1,20,21,0],publicPolicy:['policy',2,16,25,0],post:['post',3,10,13,0],song:['release_song',1,20,15,650],book:['publish_book',1,20,17,1300],competition:['competition',2,25,12,0],move:['migrate',1,20,18,11000],practiceSkill:['practice_skill',2,13,8,0]
};
function v3ActionCost(name,arg){if(name==='travel'){const x=DB.experiences[Number(arg)];return x?.[1]||0;}return V3_ACTION_LIMITS[name]?.[4]||0;}
action=function(name,arg){
 if(name==='newLife'||name==='randomLife'||name==='resetPrompt')return v3OriginalAction(name,arg);
 if(!S)return v3OriginalAction(name,arg);
 v3Init();
 if(name==='v3Special'){const [track,cmd]=String(arg).split('|');return v3SpecialAction(track,cmd);}
 if(name==='v3School')return v3StudyAtSchool();
 if(name==='v3Nav'){go('universo',arg||'motor3');return;}
 if(name==='v3Promotion')return v3AskPromotion();
 if(name==='v3CareerChoice')return v3ResolveCareerEvent(Number(arg));
 if(name==='v3Treat')return v3Treat(Number(arg));
 if(name==='v3Home'){const [idx,kind]=String(arg).split('|');return v3HomeAction(Number(idx),kind);}
 if(name==='v3Pet'){const [idx,kind]=String(arg).split('|');return v3PetAction(Number(idx),kind);}
 if(name==='v3Time'){
  const p=v2PersonById(arg);if(!p||!p.alive){notify('Essa pessoa não está disponível.','warn');return;}
  if(!v3Allow('relationship_time','person:'+p.id,1,{energy:8,message:'Você já passou tempo com '+p.name+' neste ano.'}))return;
  if(!useEnergy(8)){v3RefundLimit('relationship_time','person:'+p.id);return;}
  const modifier=p.trait==='Reservado'?3:p.trait==='Desconfiado'?2:p.trait==='Generoso'?10:7;
  p.bond=cap(p.bond+modifier);p.trust=cap(p.trust+Math.round(modifier/2));p.lastContactYear=S.year;
  v3Memory(p,'Vocês passaram um tempo juntos e compartilharam uma lembrança.',modifier,'convivencia');change('joy',2);save();render();notify('Encontro registrado com '+p.name+'.');return;
 }
 if(name==='bondParent'||name==='bondFriend'){
  const p=name==='bondParent'?S.parents[Number(arg)]:S.friends[Number(arg)];if(!p||!p.alive){notify('Essa pessoa não está disponível.','warn');return;}
  return action('v3Time',p.id);
 }
 if(name==='promotion')return v3AskPromotion();
 if(name==='applyJob')return v3ApplyJob(Number(arg));
 if(name==='rentHome'){
  const p=S.homes[Number(arg)];if(p?.rented){p.rented=false;save();render();notify('O imóvel foi retirado da locação.');return;}
  return v3HomeAction(Number(arg),'inquilino');
 }
 if(name==='buyHome'||name==='startBiz'||name==='buyVehicle'){
  const catalog=name==='buyHome'?DB.property:name==='startBiz'?DB.ventures:DB.vehicles;const item=catalog[Number(arg)];if(!item||S.cash<item[1]){notify('Você não tem dinheiro para essa compra.','warn');return;}
 }
 if(name==='dateNight'&&!S.partner&&!S.spouse){notify('Você precisa estar em um relacionamento.','warn');return;}
 if(['overtime','raise'].includes(name)&&!S.job){notify('Você precisa ter um emprego.','warn');return;}
 if(name==='practiceSkill'&&!DB.skills.includes(arg)){notify('Habilidade inválida.','warn');return;}
 const policy=V3_ACTION_LIMITS[name];let mark;
 if(policy){const [type,max,energy,minAge]=policy;const entity=['overtime','raise'].includes(name)?'job:'+(S.job?.startedYear||0):'global';const cost=v3ActionCost(name,arg);
  if(name==='doctor'&&S.v3.conditions.some(c=>c.status==='active')){
   // Consulta preventiva ainda disponível; tratamentos específicos são feitos na aba Saúde.
  }
  if(!v3Allow(type,entity,max,{energy,minAge,cost,message:'Você já usou o benefício anual dessa atividade. Avance um ano para repetir.'}))return;
  mark={type,entity};
 }
 const oldCountry=S.country;const result=v3OriginalAction(name,arg);
 if(name==='move'&&S.country!==oldCountry){S.v3.movedYear=S.year;S.v3.moves=(S.v3.moves||0)+1;save();}
 return result;
};
const v3OldContinue=continueChild;
continueChild=function(index){if(!S||S.alive)return;v3Init();const previous=S;const child=previous.children[index];if(!child){notify('Escolha um descendente válido.','warn');return;}
 const net=Math.max(0,netWorth(previous)),children=previous.children.length||1;const pref=previous.v2?.estatePlan;
 const ratio=pref==='filantropia'?.45:pref==='conservador'?.65:.75;const inheritance=Math.floor(net*ratio/children);
 const ancestor={name:previous.name+' '+previous.surname,born:previous.year-previous.age,died:previous.year,age:previous.age,generation:previous.generation,job:previous.job?.name||'Sem ocupação',legacy:previous.v2?.legacyPoints||0};
 const originalHomes=previous.homes,originalBusinesses=previous.businesses,originalVehicles=previous.vehicles;const oldDiary=previous.v2.journal;
 const descendantName=child.name.split(' ');makeLife({name:descendantName.slice(0,-1).join(' '),surname:descendantName.at(-1),country:previous.country,mode:'normal',startAdult:true});
 S.age=Math.max(18,child.age);S.year=previous.year;S.generation=previous.generation+1;S.parents=[{name:ancestor.name,age:ancestor.age,alive:false,bond:child.bond||50,role:'Família'}];
 S.stats.intel=Math.round((S.stats.intel+(child.intelligence||S.stats.intel))/2);
 S.v3.lineage=[...previous.v3.lineage,ancestor].slice(-40);S.v3.familyArchive=[...previous.v3.familyArchive,...S.v3.familyArchive].slice(0,100);
 S.v2.legacyPoints=Math.round((previous.v2.legacyPoints||0)*.75);S.v2.journal=oldDiary.slice(0,30);
 const pools=[['homes',originalHomes],['businesses',originalBusinesses],['vehicles',originalVehicles]];let owned=0;
 for(const [key,list]of pools){if(children===1){S[key]=list.map(x=>({...x}));owned+=list.reduce((n,x)=>n+(x.value||0),0);}else if(list.length){S[key]=list.filter((x,i)=>i%children===index).map(x=>({...x}));owned+=S[key].reduce((n,x)=>n+(x.value||0),0);}}
 const financial=Math.max(0,inheritance-owned);S.cash=financial;S.investments=[];S.debt=0;
 S.story=previous.story.slice(0,24).map(x=>({...x,text:'Do legado familiar: '+x.text}));logStory('Herdou uma parcela do patrimônio familiar. A história continua.','milestone');S.achievements.push('rebirth');
 v3Init();checkAchievements();save();go('vida');notify('Nova geração! Patrimônio herdado: '+money(netWorth(S))+'.');
};
// Não apaga dados antigos nem altera os slots existentes.
