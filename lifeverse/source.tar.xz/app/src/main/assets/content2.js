/* VIDAVERSO 2.0 — expansão autoral de conteúdo; nenhum recurso pago. */
'use strict';
const V2_ADDITIONAL_JOBS=[
 ['Corretor de imóveis','Comércio',18,0,65000,'Comunicação',22],['Gestor de e-commerce','Comércio',20,0,79000,'Negócios',32],['Analista de investimentos','Comércio',22,1,128000,'Negócios',45],['Auditor de compliance','Comércio',24,1,142000,'Direito',38],['Especialista em supply chain','Comércio',21,1,103000,'Negócios',30],['Gestor de franquias','Comércio',25,0,160000,'Liderança',50],['Corretor de seguros','Comércio',18,0,61000,'Comunicação',23],['Trader de commodities','Comércio',22,1,175000,'Negócios',55],
 ['Desenvolvedor mobile','Tecnologia',18,0,95000,'Tecnologia',38],['Engenheiro de IA','Tecnologia',23,1,210000,'Tecnologia',65],['Engenheiro de robótica','Tecnologia',23,1,171000,'Ciências',53],['Arquiteto de soluções cloud','Tecnologia',26,1,185000,'Tecnologia',60],['Analista de jogos','Tecnologia',18,0,87000,'Tecnologia',35],['Produtor de games','Tecnologia',22,0,131000,'Criatividade',48],['Pesquisador de computação quântica','Tecnologia',28,3,275000,'Ciências',78],['Designer de experiência','Tecnologia',19,0,107000,'Criatividade',38],
 ['Psicólogo','Saúde',23,1,93000,'Medicina',35],['Nutricionista','Saúde',22,1,86000,'Medicina',30],['Fonoaudiólogo','Saúde',23,1,94000,'Medicina',34],['Biomédico','Saúde',23,1,108000,'Ciências',35],['Paramédico','Saúde',20,0,69000,'Medicina',32],['Médico de família','Saúde',27,2,231000,'Medicina',55],['Neurocientista','Saúde',29,3,260000,'Ciências',69],['Gerente hospitalar','Saúde',28,1,159000,'Liderança',58],
 ['Arqueólogo','Ciências',23,1,78000,'Ciências',35],['Oceanógrafo','Ciências',22,1,104000,'Ciências',37],['Engenheiro aeroespacial','Ciências',24,1,178000,'Ciências',55],['Engenheiro ambiental','Ciências',22,1,123000,'Ciências',40],['Meteorologista','Ciências',23,1,117000,'Ciências',40],['Pesquisador de energia limpa','Ciências',25,1,153000,'Ciências',48],['Geólogo','Ciências',22,1,114000,'Ciências',38],['Matemático','Ciências',23,1,128000,'Ciências',42],
 ['Educador de tecnologia','Educação',21,1,81000,'Tecnologia',30],['Coordenador pedagógico','Educação',26,1,113000,'Liderança',40],['Professor de idiomas','Educação',21,1,65000,'Comunicação',27],['Pesquisador de educação','Educação',27,2,118000,'Ciências',50],['Orientador de carreira','Educação',24,1,93000,'Comunicação',35],
 ['Documentarista','Mídia',19,0,94000,'Criatividade',42],['Repórter investigativo','Mídia',21,1,106000,'Comunicação',48],['Editor de vídeo','Mídia',18,0,72000,'Criatividade',26],['Diretor de fotografia','Mídia',24,0,119000,'Artes',45],['Locutor de podcast','Mídia',18,0,61000,'Comunicação',27],['Produtor de espetáculos','Mídia',22,0,148000,'Liderança',46],
 ['Atleta de e-sports','Esportes',16,0,85000,'Tecnologia',54],['Treinador de e-sports','Esportes',20,0,101000,'Tecnologia',47],['Nadador olímpico','Esportes',17,0,113000,'Esportes',61],['Ciclista profissional','Esportes',18,0,98000,'Esportes',48],['Árbitro de futebol','Esportes',21,0,84000,'Esportes',43],['Preparador físico','Esportes',22,1,93000,'Esportes',40],
 ['Defensor público','Justiça',26,1,155000,'Direito',50],['Mediador de conflitos','Justiça',21,0,76000,'Comunicação',40],['Especialista em direito digital','Justiça',23,1,153000,'Direito',50],['Investigador forense digital','Justiça',24,1,151000,'Tecnologia',56],
 ['Bombeiro','Governo',19,0,74000,'Esportes',30],['Analista de políticas públicas','Governo',23,1,111000,'Política',39],['Coordenador de defesa civil','Governo',26,1,124000,'Liderança',47],['Diplomata cultural','Governo',25,1,129000,'Comunicação',51],
 ['Designer de interiores','Criatividade',19,0,86000,'Criatividade',32],['Ceramista','Criatividade',17,0,43000,'Artes',19],['Animador 3D','Criatividade',18,0,89000,'Artes',42],['Mestre confeiteiro','Criatividade',19,0,82000,'Criatividade',38],['Curador de museu','Criatividade',24,1,101000,'Artes',44],['Restaurador de obras','Criatividade',23,1,96000,'Artes',42]
];
DB.jobs.push(...V2_ADDITIONAL_JOBS);
DB.countries.push(...[
 ['Chile','Santiago','CLP',1.04],['Uruguai','Montevidéu','UYU',1.06],['Colômbia','Bogotá','COP',.98],['Noruega','Oslo','NOK',1.7],['Suécia','Estocolmo','SEK',1.52],['Dinamarca','Copenhague','DKK',1.65],['Países Baixos','Amsterdã','EUR',1.47],['Nova Zelândia','Auckland','NZD',1.44],['Índia','Mumbai','INR',1.09],['Singapura','Singapura','SGD',1.62],['África do Sul','Cidade do Cabo','ZAR',1.01],['Egito','Cairo','EGP',.88],['Emirados Árabes Unidos','Dubai','AED',1.68],['Grécia','Atenas','EUR',1.09]
]);
DB.degrees.push(...['Cinema','Sustentabilidade','Robótica','Inteligência Artificial','Saúde Pública','Sociologia','Antropologia','Gastronomia','Oceanografia','Ciências Ambientais','Matemática Aplicada','Engenharia Aeroespacial']);
DB.ventures.push(...[
 ['Mercado orgânico',85000,29000,.18],['Plataforma educacional',78000,27000,.23],['Editora independente',65000,22000,.18],['Laboratório de robótica',540000,185000,.21],['Consultoria ambiental',95000,33000,.24],['Clínica veterinária',350000,110000,.19],['Estúdio de animação',290000,90000,.18],['Produtora de podcasts',35000,13000,.22],['Escola de idiomas',165000,59000,.19],['Agência de turismo',75000,25000,.18],['Organização de eventos',52000,18000,.21],['Empresa de energia solar',680000,242000,.21],['Fazenda tecnológica',900000,310000,.16],['Centro de educação esportiva',145000,49000,.17]
]);
DB.property.push(...[['Casa de campo',540000,3600,4],['Loft',245000,2200,2],['Ateliê',180000,1700,1],['Chalé na montanha',460000,3300,4],['Estúdio comercial',320000,2800,3],['Galpão',1100000,9300,8],['Sítio',780000,4900,6]]);
DB.vehicles.push(...[['Patinete elétrico',3200,0],['Carro elétrico',160000,2800],['Motorhome',430000,10500],['Barco à vela',380000,12000],['Van de trabalho',92000,2800]]);
DB.hobbies.push(...['Astronomia','Cerâmica','Observação de aves','Mergulho','Robótica','Teatro','Marcenaria','Meditação','Escrita de diário','Ciclismo','Voluntariado ambiental','Composição musical']);
V2_ARCS.push(...[
 {id:'journalism',title:'O furo de reportagem',emoji:'📰',group:'Conhecimento',min:18,desc:'Investigue fatos, proteja fontes e escolha o que publicar.',stages:[
 ['Uma denúncia anônima','Um e-mail descreve irregularidades em um projeto público.',[['Verificar documentos',{intel:7,discipline:5},0],['Procurar segunda fonte',{communication:7,reputation:4},0],['Publicar imediatamente',{fame:5,reputation:-12},2]]],
 ['A fonte está com medo','Sua principal fonte teme perder o emprego.',[['Preservar anonimato',{reputation:9,law:5},0],['Solicitar entrevista pública',{communication:7,fame:4},1],['Ignorar receio',{reputation:-11,stress:7},2]]],
 ['A reportagem ganha repercussão','Os leitores pedem explicações e respostas.',[['Publicar documentos revisados',{reputation:11,intel:5},0],['Convidar especialistas',{communication:8,reputation:6},0],['Vender exclusividade',{cash:8500,fame:6},1]]]]},
 {id:'space',title:'Além do horizonte',emoji:'🪐',group:'Conhecimento',min:18,desc:'Prepare uma missão científica espacial e lide com imprevistos.',stages:[
 ['Convocação para a equipe','Um centro de pesquisa abre seletiva para um projeto espacial.',[['Estudar engenharia',{sciences:9,discipline:5},0],['Treinar resistência',{athletic:8,health:5},0],['Apostar em contatos',{communication:5,network:5},0]]],
 ['Teste decisivo','Uma falha ameaça meses de trabalho da equipe.',[['Revisar equipamentos',{technology:8,sciences:5},0],['Distribuir funções',{leadership:8,communication:5},0],['Acelerar sem testes',{career:8,stress:11},2]]],
 ['A missão decola','É preciso escolher o objetivo científico da missão.',[['Observar novos planetas',{sciences:10,reputation:6},0],['Pesquisar materiais',{technology:9,intel:5},0],['Estudar nosso planeta',{reputation:8,sciences:6},0]]]]},
 {id:'law',title:'Uma causa justa',emoji:'⚖️',group:'Sociedade',min:21,desc:'Uma disputa legal testa argumentos, empatia e integridade.',stages:[
 ['Caso delicado','Uma pessoa pede ajuda após ter um direito negado.',[['Ouvir e documentar',{law:8,communication:5},0],['Consultar especialistas',{cash:-700,law:8},0],['Prometer vitória fácil',{reputation:-8,fame:3},2]]],
 ['Uma prova inesperada','O caso recebe documentos que mudam a interpretação.',[['Conferir autenticidade',{intel:8,law:6},0],['Negociar acordo',{communication:7,reputation:5},0],['Ignorar novo documento',{stress:6,reputation:-8},2]]],
 ['Decisão final','Chegou o momento de defender sua posição.',[['Argumentar com provas',{law:11,reputation:7},0],['Propor solução conciliadora',{communication:9,joy:4},0],['Atacar a outra parte',{fame:2,reputation:-9},1]]]]},
 {id:'animals',title:'O abrigo das novas chances',emoji:'🐾',group:'Sociedade',min:15,desc:'Cuide de animais, busque apoio e construa uma rede de adoção.',stages:[
 ['Um animal ferido','Você encontra um animal precisando de cuidados.',[['Levar a veterinário',{cash:-600,joy:7,reputation:5},0],['Acionar voluntários',{communication:6,reputation:5},0],['Procurar família',{bond:4,joy:4},0]]],
 ['Abrigo lotado','Há mais animais do que espaço e recursos.',[['Criar campanha',{leadership:7,communication:6},0],['Conseguir doações',{cash:4000,reputation:5},0],['Aumentar gastos sem reserva',{cash:-8500,stress:7},1]]],
 ['Dia de adoção','Famílias chegam interessadas nos animais.',[['Verificar lares',{reputation:10,discipline:5},0],['Fazer evento aberto',{joy:7,communication:7},0],['Expandir o abrigo',{cash:-3500,business:6},0]]]]},
 {id:'esports',title:'A equipe impossível',emoji:'🎮',group:'Esportes',min:13,desc:'Construa time de e-sports e enfrente pressão competitiva.',stages:[
 ['Equipe amadora','Um grupo quer competir em um torneio de jogos.',[['Treinar juntos',{technology:8,leadership:5},0],['Estudar adversários',{intel:7,discipline:5},0],['Comprar equipamentos',{cash:-3800,technology:4},0]]],
 ['O jogador frustrado','Um integrante ameaça sair após derrotas.',[['Conversar a sós',{communication:8,bond:5},0],['Rever papéis',{leadership:8,technology:5},0],['Expulsar do time',{reputation:-5,stress:5},1]]],
 ['Final nacional','A transmissão do campeonato atrai milhares de espectadores.',[['Jogar com método',{technology:11,discipline:5},0],['Confiar na equipe',{leadership:9,joy:7},0],['Arriscar estratégia inédita',{fame:10,stress:6},1]]]]},
 {id:'hospital',title:'Plantões e decisões',emoji:'🏥',group:'Sociedade',min:20,desc:'Ajude uma unidade de saúde fictícia em diferentes dilemas.',stages:[
 ['Equipe sobrecarregada','Profissionais estão exaustos durante um período movimentado.',[['Redistribuir turnos',{leadership:8,health:3},0],['Oferecer descanso',{reputation:7,joy:4},0],['Ignorar desgaste',{stress:6,reputation:-7},2]]],
 ['Novo equipamento','A administração precisa priorizar melhorias.',[['Ouvir pacientes',{communication:7,reputation:6},0],['Investir em tecnologia',{cash:-4000,technology:7},0],['Cortar tudo',{cash:1200,reputation:-9},1]]],
 ['Atendimento humanizado','Uma campanha comunitária busca acolhimento.',[['Formar equipe',{leadership:8,medicine:7},0],['Organizar mutirão',{reputation:10,joy:5},0],['Criar material educativo',{communication:7,intel:5},0]]]]},
 {id:'education',title:'A escola de portas abertas',emoji:'🏫',group:'Conhecimento',min:18,desc:'Um projeto educacional enfrenta orçamento, famílias e desafios.',stages:[
 ['Biblioteca vazia','Uma escola precisa atrair jovens para a leitura.',[['Criar clube de leitura',{intel:7,communication:5},0],['Trazer jogos educativos',{technology:5,creativity:7},0],['Comprar livros caros',{cash:-3800,reputation:5},0]]],
 ['Uma turma desmotivada','Alunos pedem aulas mais práticas e criativas.',[['Criar oficinas',{creativity:8,leadership:5},0],['Ouvir alunos',{communication:8,reputation:5},0],['Exigir obediência sem diálogo',{reputation:-8,stress:5},2]]],
 ['Mostra de projetos','O trabalho da turma será apresentado à comunidade.',[['Organizar mostra pública',{reputation:9,leadership:6},0],['Convidar mentores',{communication:7,intel:5},0],['Premiar ideias sustentáveis',{sciences:8,joy:5},0]]]]},
 {id:'royalty',title:'O peso da coroa',emoji:'👑',group:'Sociedade',min:18,desc:'Em uma monarquia fictícia, tradição, família e responsabilidade se chocam.',stages:[
 ['Cerimônia tradicional','A família real quer manter uma antiga cerimônia.',[['Renovar com inclusão',{reputation:8,communication:6},0],['Respeitar tradição',{bond:6,discipline:5},0],['Cancelar sem consultar',{reputation:-9,stress:6},1]]],
 ['A imprensa questiona','Um jornalista faz perguntas sobre gastos oficiais.',[['Divulgar orçamento',{reputation:11,business:4},0],['Propor controle independente',{leadership:8,politics:5},0],['Evitar respostas',{reputation:-10,stress:7},2]]],
 ['O futuro da família','Você pode definir uma nova função pública para o título.',[['Priorizar educação',{reputation:10,intel:5},0],['Promover diplomacia',{communication:8,politics:6},0],['Financiar eventos luxuosos',{cash:-14000,fame:8},1]]]]},
 {id:'expedition',title:'A travessia da montanha',emoji:'🏔️',group:'Mundo',min:16,desc:'Planeje uma jornada de aventura e veja o custo das decisões.',stages:[
 ['Mapa incompleto','Um amigo propõe explorar uma trilha pouco conhecida.',[['Contratar guia',{cash:-1400,health:5},0],['Estudar o caminho',{intel:7,discipline:5},0],['Partir sem mapa',{joy:5,health:-8},2]]],
 ['Tempo virou','O céu escurece e o grupo precisa decidir onde descansar.',[['Buscar abrigo',{health:8,stress:-4},0],['Montar acampamento',{athletic:6,leadership:5},0],['Seguir apressado',{athletic:4,health:-10},2]]],
 ['O cume','As últimas horas da jornada revelam uma paisagem incrível.',[['Fotografar e preservar',{creativity:7,joy:9},0],['Agradecer à equipe',{bond:7,communication:5},0],['Fazer pesquisa de campo',{sciences:7,intel:5},0]]]]},
 {id:'finance',title:'Da dívida à liberdade',emoji:'💳',group:'Patrimônio',min:18,desc:'Aprenda a negociar dívidas, planejar gastos e construir segurança.',stages:[
 ['Conta atrasada','Você encontra uma cobrança que vinha ignorando.',[['Negociar parcelamento',{business:6,stress:-2},0],['Reorganizar orçamento',{discipline:8,intel:4},0],['Contrair nova dívida',{debt:8000,joy:3},2]]],
 ['Tentação do consumo','Uma promoção parece imperdível, mas não está no orçamento.',[['Guardar o dinheiro',{discipline:9,stress:-3},0],['Comprar só o necessário',{cash:-1000,joy:4},0],['Parcelar tudo',{debt:4500,joy:2},1]]],
 ['Reserva de emergência','Você tem a oportunidade de criar uma reserva.',[['Investir em conhecimento',{business:8,intel:4},0],['Separar uma reserva',{cash:-3000,discipline:7},0],['Ajudar a comunidade',{cash:-1700,reputation:9},0]]]]},
 {id:'techfuture',title:'O aplicativo que virou realidade',emoji:'📲',group:'Negócios',min:16,desc:'Desenvolva um produto digital e decida como proteger usuários.',stages:[
 ['Uma ideia no caderno','Você quer criar um aplicativo para resolver um problema real.',[['Entrevistar pessoas',{communication:6,business:5},0],['Desenvolver protótipo',{technology:9,cash:-800},0],['Procurar equipe',{leadership:5,friend:1},0]]],
 ['Dados pessoais','O aplicativo começa a coletar informações delicadas.',[['Minimizar dados',{reputation:9,technology:5},0],['Explicar permissões',{communication:8,reputation:5},0],['Vender dados sem consentimento',{cash:12000,reputation:-18},2]]],
 ['Primeiros usuários','A comunidade quer mais recursos e estabilidade.',[['Corrigir bugs',{technology:10,discipline:6},0],['Abrir código para colaborar',{reputation:9,communication:5},0],['Fazer marketing agressivo',{fame:7,cash:-4000},1]]]]},
 {id:'agriculture',title:'A fazenda do amanhã',emoji:'🌾',group:'Patrimônio',min:18,desc:'Produção, clima, inovação e o desafio de alimentar comunidades.',stages:[
 ['Terra cansada','Uma propriedade precisa recuperar a qualidade do solo.',[['Testar solo',{sciences:8,cash:-900},0],['Investir em cobertura verde',{cash:-2200,reputation:7},0],['Aumentar produção sem cuidado',{cash:3500,reputation:-7},1]]],
 ['Seca inesperada','Uma estação seca muda o planejamento da propriedade.',[['Captar água responsável',{technology:7,cash:-3500},0],['Diversificar plantações',{business:7,sciences:5},0],['Usar reserva sem planejamento',{cash:-5000,stress:6},1]]],
 ['Feira de produtores','A comunidade organiza um evento para vender produtos locais.',[['Vender diretamente',{cash:9000,business:7},0],['Ensinar técnicas a vizinhos',{reputation:9,communication:6},0],['Criar cooperativa',{leadership:8,reputation:6},0]]]]}
]);
V2_EVENT_PACK.push(...[
 ['Oferta de emprego remoto','Uma empresa permite trabalhar de qualquer cidade.',[['Negociar flexibilidade',{communication:7,joy:4}],['Aprimorar currículo',{technology:6,career:4}],['Recusar por enquanto',{stress:-3}]],{min:18,requires:'job'}],
 ['A biblioteca fecha cedo','Moradores querem horários melhores para estudar.',[['Criar movimento comunitário',{reputation:5,politics:3}],['Conversar com direção',{communication:7}],['Voluntariar-se',{joy:6,reputation:6}]],{min:12}],
 ['Uma ideia de invenção','Você observa um problema que poderia ter solução simples.',[['Construir protótipo',{technology:7,cash:-900}],['Pesquisar alternativas',{sciences:6,intel:4}],['Compartilhar ideia',{friend:1,communication:4}]],{min:13}],
 ['Mensagem de um ex-colega','Uma pessoa lembra de um projeto em que trabalharam juntos.',[['Retomar contato',{network:6,communication:5}],['Propor parceria',{business:5,career:5}],['Agradecer e seguir',{joy:3}]],{min:18}],
 ['Uma noite de chuva','A energia elétrica acaba no bairro e os vizinhos se reúnem.',[['Organizar ajuda',{reputation:6,leadership:4}],['Contar histórias',{joy:5,creativity:4}],['Descansar cedo',{health:4,stress:-4}]],{min:8}],
 ['O livro esquecido','Você descobre um caderno com textos antigos.',[['Reescrever ideias',{creativity:8,intel:3}],['Mostrar à família',{bond:6,joy:6}],['Guardar como lembrança',{joy:4}]],{min:10}],
 ['Gastos com transporte','Seu trajeto diário está ficando caro.',[['Planejar caronas',{cash:1400,communication:4}],['Pesquisar transporte público',{discipline:5,intel:3}],['Trocar rotina de trabalho',{stress:-4,technology:3}]],{min:18}],
 ['Nova tecnologia na escola','Uma ferramenta muda como as pessoas estudam.',[['Aprender a usar',{technology:6,intel:5}],['Criar projeto coletivo',{leadership:5,creativity:5}],['Criticar sem testar',{reputation:-3,stress:2}]],{min:12}],
 ['Reencontro de infância','Uma pessoa aparece com uma foto antiga de vocês.',[['Reviver memórias',{joy:8,bond:4}],['Fazer visita',{cash:-450,joy:7}],['Planejar nova viagem',{communication:6,stress:-2}]],{min:19}],
 ['Convite à leitura','Um autor pede opiniões sobre seu novo livro.',[['Ler e comentar',{intel:6,communication:4}],['Organizar clube',{leadership:6,friend:1}],['Agradecer',{reputation:2}]],{min:13}],
 ['Um erro no imposto','Você percebe diferença nos documentos fiscais.',[['Pedir orientação profissional',{cash:-350,business:5}],['Revisar registros',{intel:6,discipline:4}],['Ignorar aviso',{stress:8,reputation:-4}]],{min:18}],
 ['Um filme emociona','Uma história na tela faz você refletir sobre sua vida.',[['Escrever reflexão',{creativity:6,joy:5}],['Conversar com alguém',{bond:5,communication:4}],['Procurar obras similares',{intel:5,joy:3}]],{min:11}],
 ['Palestra gratuita','Uma profissional conta erros que cometeu ao crescer na carreira.',[['Anotar aprendizados',{intel:6,career:4}],['Fazer uma pergunta',{communication:7,network:4}],['Conversar depois',{friend:1,network:5}]],{min:16}],
 ['A descoberta de um artista','Você conhece uma banda independente incrível.',[['Compartilhar músicas',{music:5,friend:1}],['Ir a apresentação',{cash:-150,joy:6}],['Escrever uma resenha',{creativity:6,communication:4}]],{min:12}],
 ['Problema com colega','Alguém levou crédito por uma ideia que foi sua.',[['Conversar com respeito',{communication:6,career:5}],['Documentar contribuições',{discipline:5,reputation:4}],['Vingar-se publicamente',{reputation:-9,stress:8}]],{min:18,requires:'job'}],
 ['Uma decisão de saúde','Uma rotina intensa começa a atrapalhar seu sono.',[['Mudar horários',{health:6,discipline:5}],['Buscar orientação',{cash:-450,health:5}],['Continuar sem descanso',{health:-6,stress:7}]],{min:16}],
 ['A nova vizinhança','Uma família muda para perto e não conhece ninguém.',[['Dar boas-vindas',{reputation:5,joy:4}],['Oferecer ajuda',{bond:5,communication:4}],['Deixar um bilhete',{creativity:3,reputation:3}]],{min:8}],
 ['Debate sobre o futuro','Você recebe convite para discutir tecnologia e privacidade.',[['Ouvir posições diversas',{communication:6,intel:4}],['Defender dados pessoais',{reputation:6,technology:4}],['Organizar palestra',{leadership:6,reputation:4}]],{min:18}],
 ['Festival de pequenos negócios','Empreendedores expõem produtos em uma feira regional.',[['Participar',{cash:-450,business:6}],['Ajudar produtor local',{reputation:5,bond:4}],['Aprender com expositores',{intel:5,network:4}]],{min:18}],
 ['Premiação cultural','Uma comunidade reconhece pessoas que preservam suas tradições.',[['Participar voluntariamente',{reputation:7,joy:5}],['Produzir documentário',{creativity:7,art:4}],['Doar para escola',{cash:-600,reputation:6}]],{min:18}]
]);
const V2_NEW_GOALS=[
 {id:'learn20',title:'Conhecimento para toda a vida',test:s=>s.v2.career.certifications>=8,points:20},
 {id:'mentor10',title:'Orientador de gerações',test:s=>s.v2.career.mentors>=10,points:18},
 {id:'bizmagnate',title:'Construtor de empresas',test:s=>s.businesses.length>=8,points:25},
 {id:'happyfamily',title:'Família de confiança',test:s=>s.children.length>=3&&s.children.filter(x=>x.bond>=75).length>=3,points:20},
 {id:'boss',title:'Liderança de excelência',test:s=>s.job&&s.job.level>=7,points:25},
 {id:'health',title:'Hábitos duradouros',test:s=>Object.values(s.v2.habits).every(x=>x>=70),points:20},
 {id:'legacy',title:'Legado de histórias',test:s=>s.v2.completedSagas.length>=12,points:40},
 {id:'world',title:'Explorador persistente',test:s=>s.counts.trips>=25,points:25},
 {id:'luxury',title:'Uma vida de muitos bens',test:s=>s.homes.length>=8,points:22},
 {id:'friends10',title:'Amigos para contar',test:s=>s.friends.filter(x=>x.bond>=75).length>=6,points:25},
 {id:'journal30',title:'Um diário de décadas',test:s=>s.v2.journal.length>=30,points:25},
 {id:'elder',title:'Um século de histórias',test:s=>s.age>=100,points:35},
 {id:'rich25',title:'O império dos 25 milhões',test:s=>netWorth(s)>=25000000,points:35}
];
V2_GOALS.push(...V2_NEW_GOALS);
DB.challenges.push(...V2_NEW_GOALS.map(g=>({id:'v2_'+g.id,name:g.title,desc:'Missão v2: '+g.points+' pontos de legado',condition:s=>!!(s.v2&&s.v2.flags['goal_'+g.id])})));
