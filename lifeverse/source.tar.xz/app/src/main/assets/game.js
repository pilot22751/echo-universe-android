/* VIDAVERSO 1.0 — simulador original, sem ads, sem IAP, sem servidor. */
'use strict';
const SAVE_KEY='vidaverso-life-1'; // Retrocompatível com saves da versão 1
const fallbackStorage={};
function storeGet(k){try{return localStorage.getItem(k);}catch(e){return fallbackStorage[k]||null;}}
function storeSet(k,v){try{localStorage.setItem(k,v);}catch(e){fallbackStorage[k]=v;}}
function storeRemove(k){try{localStorage.removeItem(k);}catch(e){delete fallbackStorage[k];}}
function shortMoney(n){const a=Math.abs(n);const sign=n<0?'-':'';if(a>=1e9)return sign+'R$ '+(a/1e9).toFixed(1).replace('.',',')+' bi';if(a>=1e6)return sign+'R$ '+(a/1e6).toFixed(1).replace('.',',')+' mi';if(a>=10000)return sign+'R$ '+Math.round(a/1000)+' mil';return money(n);}

let S=null, tab='vida', section='visao', jobSector='Todos', storyMode='normal', pageOffset=0, currentModal=null, modalButtons=[], toastTimer=null, searchQuery='';
const icons={vida:'🌱',acoes:'✨',estudos:'🎓',trabalho:'💼',relacoes:'❤️',bens:'🏡',mundo:'🌎',universo:'🌌',legado:'🏆',ajustes:'⚙️'};
const labels={vida:'Minha vida',acoes:'Atividades',estudos:'Educação',trabalho:'Carreiras',relacoes:'Relações',bens:'Patrimônio',mundo:'Mundo & fama',universo:'Universo 3.0',legado:'Legado',ajustes:'Ajustes'};
const tabs=Object.keys(icons);
function escapeHTML(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function safeJSON(s){try{return JSON.parse(s);}catch(e){return null;}}
function save(){if(S)storeSet(SAVE_KEY,JSON.stringify(S));}
function restore(){try{const raw=storeGet(SAVE_KEY);const x=raw&&safeJSON(raw);if(x&&x.version===1&&x.name&&x.stats&&x.counts){S=x;S.skills=S.skills||{};S.eventsSeen=S.eventsSeen||[];S.story=S.story||[];S.achievements=S.achievements||[];S.settings=S.settings||{sound:true};S.friends=S.friends||[];S.pets=S.pets||[];S.businesses=S.businesses||[];S.homes=S.homes||[];S.vehicles=S.vehicles||[];S.investments=S.investments||[];S.children=S.children||[];S.actionsUsed=S.actionsUsed||0;initV2();save();return true;}}catch(e){}return false;}
function mkPerson(gender){return pick(gender==='F'?DB.namesF:DB.namesM)+' '+pick(DB.surnames);}
function makeLife(config={}){
 const gender=config.gender||pick(['M','F']); const country=DB.countries.find(x=>x[0]===(config.country||'Brasil'))||DB.countries[0];const name=(config.name||pick(gender==='F'?DB.namesF:DB.namesM)).trim().slice(0,25); const surname=(config.surname||pick(DB.surnames)).trim().slice(0,25);
 const mode=config.mode||'normal';const royal=mode==='royal';const free=mode==='god';const startAdult=config.startAdult;
 S={version:1,id:Date.now(),name:name||pick(DB.namesM),surname:surname||'Silva',gender,country:country[0],city:country[1],age:startAdult?18:0,year:2026,generation:1,alive:true,mode,royal,parents:[{name:mkPerson('F'),bond:72,alive:true},{name:mkPerson('M'),bond:65,alive:true}],cash:startAdult?(free?200000:2500):(royal?75000:0),debt:0,
 stats:{health:free?95:rnd(62,96),joy:free?95:rnd(60,95),intel:free?95:rnd(45,90),looks:free?95:rnd(38,92),discipline:free?90:rnd(40,75),stress:0,fame:royal?50:0,reputation:royal?65:50,energy:100},skills:{},education:{level:0,major:'',enrolled:false,remaining:0,kind:''},job:null,careerYears:0,workQuality:45,spouse:null,partner:null,children:[],friends:[],pets:[],businesses:[],homes:[],vehicles:[],investments:[],prison:0,crimeHeat:0,politics:{wins:0,policies:0},social:{followers:royal?50000:0,posts:0},
 counts:{activities:0,trips:0,pets:0,volunteer:0,crimes:0,arrests:0,songs:0,books:0,elections:0,trophies:0,partners:0,marriages:0,children:0,years:0},achievements:[],eventsSeen:[],story:[],actionsUsed:0,memories:[],settings:{sound:true},deathCause:'',lastYearReport:null};
 DB.skills.forEach(skill=>S.skills[skill]=free?rnd(78,95):rnd(5,32));
 initV2();v2SetAspiration(config.aspiration||'equilibrio',true);document.documentElement.classList.toggle('dark',false);
 if(royal){S.homes.push({name:'Palácio da família',value:5500000,rent:0,id:Date.now()});S.stats.reputation=75;S.cash+=50000;}
 logStory('Você nasceu em '+S.city+', '+S.country+'. Sua história começou.','birth');
 if(startAdult){logStory('Você iniciou uma vida adulta, com liberdade para decidir seu caminho.','milestone');}
 save();tab='vida';section='visao';render();
 openInfo('Bem-vindo ao VIDAVERSO','Cada escolha muda sua história. Avance de ano, explore os menus e crie sua própria vida. Todas as carreiras e modos estão disponíveis sem pagamentos.', [{label:'Começar a viver',primary:true}]);
}
function logStory(text,type='note'){if(!S)return;S.story.unshift({year:S.year,age:S.age,text,type,id:Date.now()+Math.random()});if(S.story.length>700)S.story.length=700;}
function requireLife(min=0){if(!S||!S.alive){notify('Comece uma nova vida ou continue com um descendente.','warn');return false;}if(S.age<min){notify('Essa atividade fica disponível a partir dos '+min+' anos.','warn');return false;}return true;}
function useEnergy(amount=8,minAge=0){if(!requireLife(minAge))return false;if(S.stats.energy<amount){notify('Você está sem energia! Passe um ano para se recuperar.','warn');return false;}if(S.actionsUsed>=24){notify('Você já fez muita coisa neste ano. Avance para o próximo.','warn');return false;}S.stats.energy-=amount;S.actionsUsed++;S.counts.activities++;return true;}
function change(stat,n){if(stat in S.stats)S.stats[stat]=cap(S.stats[stat]+n);else if(stat in S.skills)S.skills[stat]=cap(S.skills[stat]+n);}
function applyEffect(effect={}){
 const skillMap={communication:'Comunicação',creativity:'Criatividade',technology:'Tecnologia',athletic:'Esportes',art:'Artes',music:'Música',business:'Negócios',politics:'Política',leadership:'Liderança',sciences:'Ciências',law:'Direito',medicine:'Medicina'};
 for(const [key,value] of Object.entries(effect)){
  if(key==='cash'){S.cash+=value;if(S.cash<0){S.debt+=-S.cash;S.cash=0;}}
  else if(key==='debt')S.debt=Math.max(0,S.debt+value);
  else if(key==='investment')S.investments.push({name:'Fundo diversificado',amount:value,id:Date.now()});
  else if(key==='bond'){if(S.spouse)S.spouse.bond=cap(S.spouse.bond+value);else if(S.partner)S.partner.bond=cap(S.partner.bond+value);else S.parents.forEach(p=>p.bond=cap(p.bond+value));}
  else if(key==='friend')for(let i=0;i<value;i++)S.friends.push({name:mkPerson(pick(['F','M'])),bond:rnd(45,85)});
  else if(key==='career')S.workQuality=cap(S.workQuality+value);
  else if(key in skillMap)change(skillMap[key],value);
  else change(key,value);
 }
 checkAchievements();save();
}
function checkAchievements(){if(S&&S.v2&&typeof v2CheckGoals==='function')v2CheckGoals();let added=[];for(const ch of DB.challenges){if(!S.achievements.includes(ch.id)&&ch.condition(S)){S.achievements.push(ch.id);added.push(ch.name);}}if(added.length)notify('🏆 Conquista: '+added.slice(0,2).join(', ')+'!');}
function toastText(text){const h=document.getElementById('toast');if(!h)return;h.textContent=text;h.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>h.classList.remove('show'),3400);}
function notify(text,type='ok'){toastText((type==='warn'?'⚠️ ':'')+text);}
function openInfo(title,body,buttons=[{label:'Continuar',primary:true}]){currentModal={title,body,choices:buttons.map(b=>({label:b.label,action:b.action||null,primary:b.primary!==false}))};renderModal();}
function openQuestion(title,body,choices){currentModal={title,body,choices};renderModal();}
function closeModal(){currentModal=null;renderModal();}
function renderModal(){const host=document.getElementById('modalHost');if(!host)return;if(!currentModal){host.innerHTML='';return;}
 const ch=currentModal.choices||[];host.innerHTML=`<div class="modal-screen" data-act="dismiss"><div class="dialog" role="dialog" aria-modal="true"><div class="modal-kicker">✦ Sua história continua</div><h2>${escapeHTML(currentModal.title)}</h2><p>${escapeHTML(currentModal.body)}</p><div class="modal-choices">${ch.map((c,i)=>`<button class="choice ${c.primary?'primary':''}" data-act="modalChoice" data-p="${i}"><span>${escapeHTML(c.label)}</span><span>›</span></button>`).join('')}</div></div></div>`;
}
function eventEligible(e){if(S.age<e.min||S.age>e.max)return false;if(e.job && !(S.job&&e.job.test(S.job.name)))return false;if(e.requires==='business'&&!S.businesses.length)return false;if(e.requires==='spouse'&&!S.spouse)return false;if(e.requires==='children'&&!S.children.length)return false;return true;}
function chooseEvent(){const available=EV.map((e,i)=>({e,i})).filter(o=>eventEligible(o.e));const fresh=available.filter(o=>!S.eventsSeen.slice(-28).includes(o.i));const p=pick(fresh.length?fresh:available);if(!p)return;S.eventsSeen.push(p.i);if(S.eventsSeen.length>90)S.eventsSeen.shift();let e=p.e;openQuestion(e.title,e.body,e.choices.map(c=>({...c,action:()=>{applyEffect(c.effect);logStory(e.title+': '+c.label+'.','event');save();render();}})));}
function ageOneYear(){
 if(!requireLife())return;S.age++;S.year++;S.counts.years++;S.stats.energy=100;S.actionsUsed=0;const report=[];
 if(S.prison>0){S.prison--;change('joy',-8);change('health',-2);report.push('Ano cumprido na prisão'+(S.prison?' ('+S.prison+' restante).':'. Você está livre.'));}
 const isWorking=S.job&&S.prison===0;let income=0;if(S.retirement){S.cash+=S.retirement;income+=S.retirement;}if(S.royal){S.cash+=125000;income+=125000;change('reputation',-1);}if(isWorking){income=Math.round(S.job.salary*(0.79+S.workQuality/300)*(1+S.stats.fame/400));S.cash+=income;S.careerYears++;S.job.years++;change('stress',rnd(1,5));if(Math.random()<.12){S.job.salary=Math.round(S.job.salary*1.065);report.push('Seu salário aumentou pelo bom desempenho.');}}
 const businessIncome=S.businesses.reduce((n,b)=>{let profit=Math.round(b.revenue*(b.margin+((S.skills['Negócios']||0)-45)/500)*(0.6+Math.random()*.8)-b.staff*12000);b.value=Math.max(500,Math.round(b.value*(.93+Math.random()*.18)));b.revenue=Math.round(b.revenue*(.86+Math.random()*.35));b.profit=profit;return n+profit;},0);S.cash+=businessIncome;
 let rent=0;for(const h of S.homes){h.value=Math.round(h.value*(.96+Math.random()*.12));if(h.rented){const x=h.rent*12;rent+=x;}}
 S.cash+=rent;
 let investments=0;for(const inv of S.investments){let rate=inv.name.includes('Cripto')?(-.5+Math.random()*1.4):inv.name.includes('Ações')?(-.22+Math.random()*.46):(-.05+Math.random()*.18);const changeValue=Math.round(inv.amount*rate);inv.amount=Math.max(0,inv.amount+changeValue);investments+=changeValue;}
 const dependents=S.children.filter(c=>c.age<18).length;const living=S.age<18?0:(S.royal?28000:Math.round(7200+S.age*130+dependents*2300+(S.spouse?2700:0)));S.cash-=living;
 for(const v of S.vehicles)v.value=Math.max(50,Math.round(v.value*(.79+Math.random()*.18)));
 if(S.debt>0){let interest=Math.round(S.debt*.09);S.debt+=interest;let paid=Math.min(Math.max(0,S.cash*.08),S.debt);S.cash-=paid;S.debt-=paid;}
 if(S.cash<0){S.debt+=-S.cash;S.cash=0;change('stress',4);report.push('Você precisou usar crédito para pagar suas despesas.');}
 if(S.education.enrolled){S.education.remaining--;if(S.education.remaining<=0){if(S.v3&&typeof v3GraduationFail==='function'&&v3GraduationFail()){S.education.remaining=1;report.push('Você precisou refazer uma etapa de '+S.education.major+'.');logStory('Reprovação em '+S.education.major+'.','sad');}else{S.education.level=Math.max(S.education.level,S.education.kind==='Graduação'?1:S.education.kind==='Pós-graduação'?2:3);const type=S.education.kind;S.education.enrolled=false;report.push('Concluiu: '+type+' em '+S.education.major+'.');change('intel',6);logStory('Formou-se: '+type+' em '+S.education.major+'.','milestone');}}}
 for(const c of S.children)c.age++;
 if(S.spouse){S.spouse.years++;S.spouse.bond=cap(S.spouse.bond+rnd(-3,2));if(S.spouse.bond<10&&Math.random()<.2){report.push('Seu casamento chegou ao fim.');logStory('Você se divorciou.','sad');S.spouse=null;change('joy',-12);}}
 if(S.partner)S.partner.bond=cap(S.partner.bond+rnd(-3,4));
 for(const f of S.friends)f.bond=cap(f.bond+rnd(-4,2));
 if(S.pets.length){for(const p of S.pets)p.age++;const old=S.pets.filter(p=>p.age>rnd(10,18));if(old.length){S.pets=S.pets.filter(p=>!old.includes(p));report.push('Um animal de estimação faleceu de velhice.');change('joy',-8);}}
 S.stats.health=cap(S.stats.health+(S.age>50?-rnd(1,4):rnd(-2,2))+(S.stats.stress>80?-3:0));change('joy',rnd(-3,2));change('stress',-rnd(1,5));S.crimeHeat=Math.max(0,S.crimeHeat-rnd(0,5));
 if(S.age===6)report.push('Você começou o ensino fundamental.');if(S.age===15)report.push('Você entrou no ensino médio.');if(S.age===18)report.push('Você chegou à vida adulta!');
 if(S.age>=75&&Math.random()<(S.age-70)/180+(S.stats.health<20?.24:0)||S.age>=113){S.alive=false;S.deathCause=pick(['causas naturais','uma doença inesperada','complicações da idade']);logStory('Sua vida terminou por '+S.deathCause+'.','sad');report.push('Sua jornada chegou ao fim.');}
 v2Year();
 S.lastYearReport={age:S.age,income,businessIncome,investments,rent,living,report};
 logStory('Chegou aos '+S.age+' anos. '+(report[0]||'Um novo ano de possibilidades.'),'year');checkAchievements();save();render();
 if(!S.alive){openQuestion('Sua história ficou para sempre','Você viveu '+S.age+' anos, construiu um legado de '+money(netWorth(S))+' e colecionou '+S.achievements.length+' conquistas. Você pode iniciar uma nova vida ou continuar com um filho adulto.',[
 {label:'Ver meu legado',action:()=>go('legado','obituario')},...(S.children.length?[{label:'Continuar com um filho',action:()=>go('relacoes','filhos')}]:[]),{label:'Nova vida',action:()=>resetToStart()}]);return;}
 if(report.length&&Math.random()<.55){openQuestion('Aos '+S.age+' anos…',report.join(' '),[{label:'Continuar',action:()=>{if(Math.random()<.83){if(Math.random()<.6&&!v2ChooseAdvancedEvent())chooseEvent();else if(Math.random()>=.6)chooseEvent();}}}]);}else if(Math.random()<.92){if(Math.random()<.60){if(!v2ChooseAdvancedEvent())chooseEvent();}else chooseEvent();}
}
function activityFeedback(title,text,effect={},type='activity'){applyEffect(effect);logStory(text,type);save();render();openInfo(title,text);}
function action(name,arg){if(!S&&name!=='newLife'){return;}if(S&&v2Act(name,arg))return;let skill;
 switch(name){
 case 'age':ageOneYear();return;
 case 'newLife':{let gender=document.getElementById('newGender')?.value||'M';let country=document.getElementById('newCountry')?.value||'Brasil';let mode=document.getElementById('newMode')?.value||'normal';let name=document.getElementById('newName')?.value||'';let adult=document.getElementById('startAdult')?.checked||false;let aspiration=document.getElementById('newAspiration')?.value||'equilibrio';makeLife({gender,country,mode,name,startAdult:adult,aspiration});return;}
 case 'randomLife':makeLife({gender:pick(['F','M']),country:pick(DB.countries)[0],mode:pick(['normal','normal','normal','royal','god'])});return;
 case 'resetPrompt':openQuestion('Apagar sua vida atual?','Isso vai apagar o progresso salvo neste dispositivo. Faça um backup primeiro.',[{label:'Cancelar'},{label:'Apagar e criar outra vida',action:()=>resetToStart()}]);return;
 case 'meditate':if(!useEnergy(10))return;activityFeedback('Um momento de calma','Você reservou um tempo para respirar e recuperar o equilíbrio.',{stress:-16,joy:4,discipline:3});return;
 case 'gym':if(!useEnergy(16,8))return;activityFeedback('Treino concluído','Você praticou exercícios, sentiu mais disposição e melhorou suas habilidades físicas.',{health:8,athletic:7,looks:2,stress:-5});return;
 case 'doctor':if(!useEnergy(12))return;if(!pay(350))return;activityFeedback('Consulta médica','Você fez uma avaliação preventiva e cuidou da sua saúde.',{health:14,stress:-6});return;
 case 'therapy':if(!useEnergy(12,12))return;if(!pay(320))return;activityFeedback('Terapia','Você conversou sobre seus desafios e encontrou novas perspectivas.',{stress:-18,joy:9,health:2});return;
 case 'salon':if(!useEnergy(10,13))return;if(!pay(240))return;activityFeedback('Mudança de visual','Você decidiu se cuidar e experimentar um visual diferente.',{looks:7,joy:6});return;
 case 'library':if(!useEnergy(12,4))return;activityFeedback('Tarde na biblioteca','Você mergulhou em livros e aprendeu algo novo.',{intel:7,discipline:2,joy:2});return;
 case 'study':if(!useEnergy(15,5))return;activityFeedback('Sessão de estudos','Você se dedicou aos estudos e desenvolveu sua concentração.',{intel:7,discipline:5,stress:2});return;
 case 'course':if(!useEnergy(15,12))return;if(!pay(900))return;skill=arg||'Tecnologia';change(skill,12);change('intel',3);logStory('Fez um curso de '+skill+'.');checkAchievements();save();render();notify('Curso concluído: +12 em '+skill);return;
 case 'hobby':if(!useEnergy(12,5))return;skill=({"Corrida":'Esportes','Canto':'Música','Instrumento musical':'Música','Videogames':'Tecnologia','Programação':'Tecnologia','Fotografia':'Artes','Dança':'Artes','Artes marciais':'Esportes','Escrita':'Criatividade','Desenho':'Criatividade','Xadrez':'Ciências'})[arg]||'Criatividade';change(skill,7);change('joy',7);logStory('Praticou '+arg+'.');checkAchievements();save();render();notify('Hobby praticado: '+arg);return;
 case 'volunteer':if(!useEnergy(14,8))return;S.counts.volunteer++;activityFeedback('Dia de voluntariado','Você ajudou pessoas da sua comunidade.',{reputation:8,joy:7,communication:3});return;
 case 'party':if(!useEnergy(15,14))return;if(!pay(360))return;activityFeedback('Noite de festa','Você saiu, conheceu pessoas e aproveitou a noite.',{joy:9,communication:4,health:-1,stress:-4});return;
 case 'travel':if(!useEnergy(20,12))return;{let ex=DB.experiences[Number(arg)]||DB.experiences[0];if(!pay(ex[1]))return;S.counts.trips++;activityFeedback(ex[0],'Você viveu uma experiência especial: '+ex[0]+'.',{joy:ex[2],stress:-8,communication:2});return;}
 case 'pet':if(!useEnergy(8,8))return;if(!pay(450))return;S.pets.push({name:pick(['Pipoca','Bidu','Luna','Thor','Mel','Tico','Nina','Bela','Zig','Fubá']),type:arg||'Cachorro',age:0});S.counts.pets++;activityFeedback('Novo companheiro','Você adotou um '+arg+' para sua família.',{joy:10,reputation:4});return;
 case 'friends':if(!useEnergy(12,6))return;S.friends.push(v2RandomAgent({name:mkPerson(pick(['F','M'])),bond:rnd(48,85)},'Amizade'));activityFeedback('Uma nova amizade','Você conheceu uma pessoa especial e fez uma amizade.',{joy:6,communication:3});return;
 case 'bondFriend':{let f=S.friends[Number(arg)];if(!f)return;if(!useEnergy(8))return;f.bond=cap(f.bond+14);activityFeedback('Amizade fortalecida','Você passou um tempo com '+f.name+'.',{joy:5});return;}
 case 'bondParent':{let p=S.parents[Number(arg)];if(!p||!p.alive)return;if(!useEnergy(8))return;p.bond=cap(p.bond+16);activityFeedback('Tempo em família','Você aproveitou um dia com '+p.name+'.',{joy:6});return;}
 case 'dating':if(!useEnergy(12,16))return;if(S.partner||S.spouse){notify('Você já está em um relacionamento.','warn');return;}S.partner=v2RandomAgent({name:mkPerson(pick(['F','M'])),bond:rnd(48,80),years:0},'Namoro');S.counts.partners++;activityFeedback('Um novo romance','Você começou a namorar '+S.partner.name+'.',{joy:12,communication:3});return;
 case 'dateNight':if(!useEnergy(10,16))return;if(!S.partner&&!S.spouse)return;if(!pay(420))return;{let p=S.partner||S.spouse;p.bond=cap(p.bond+14);activityFeedback('Encontro especial','Você saiu com '+p.name+' para um programa romântico.',{joy:8,stress:-5});return;}
 case 'propose':if(!useEnergy(10,18))return;if(!S.partner){notify('Você precisa namorar alguém primeiro.','warn');return;}if(!pay(3200))return;{let success=Math.random()<(S.partner.bond/110+.12);if(success){S.spouse={...S.partner,years:0};S.partner=null;S.counts.marriages++;activityFeedback('Casamento!','Você se casou com '+S.spouse.name+'.',{joy:16,reputation:4});}else{S.partner.bond=cap(S.partner.bond-15);activityFeedback('Pedido recusado','A pessoa não se sentiu pronta para casar.',{joy:-8,stress:8});}return;}
 case 'separate':if(!useEnergy(5,16))return;{const p=S.spouse||S.partner;if(!p)return;openQuestion('Terminar relacionamento?','Você realmente quer terminar com '+p.name+'?', [{label:'Continuar juntos'},{label:'Terminar',action:()=>{S.spouse=null;S.partner=null;change('joy',-10);logStory('Um relacionamento chegou ao fim.','sad');save();render();}}]);return;}
 case 'child':if(!useEnergy(18,18))return;if(!S.partner&&!S.spouse){notify('É necessário estar em um relacionamento para planejar um filho.','warn');return;}if(S.age>65){notify('Nessa fase, prefira a adoção no simulador.','warn');return;}addChild(false);return;
 case 'adoptChild':if(!useEnergy(16,21))return;if(!pay(6500))return;addChild(true);return;
 case 'childBond':{let c=S.children[Number(arg)];if(!c)return;if(!useEnergy(10))return;c.bond=cap(c.bond+17);activityFeedback('Tempo especial','Você passou um dia com '+c.name+'.',{joy:7});return;}
 case 'heir':continueChild(Number(arg));return;
 case 'school':return enroll(arg);
 case 'applyJob':return applyJob(Number(arg));
 case 'resign':if(!requireLife(16))return;if(!S.job)return;logStory('Deixou o emprego de '+S.job.name+'.','work');S.job=null;S.careerYears=0;save();render();notify('Você pediu demissão.');return;
 case 'overtime':if(!useEnergy(22,16))return;if(!S.job){notify('Arrume um emprego primeiro.','warn');return;}S.cash+=Math.round(S.job.salary*.035);S.workQuality=cap(S.workQuality+6);activityFeedback('Hora extra','Você trabalhou muito e ganhou um adicional.',{stress:9,discipline:4});return;
 case 'raise':if(!useEnergy(12,16))return;if(!S.job){notify('Arrume um emprego primeiro.','warn');return;}if(Math.random()<(.30+S.workQuality/190)){S.job.salary=Math.round(S.job.salary*1.15);activityFeedback('Aumento aprovado','Você demonstrou bons resultados e ganhou 15% de aumento.',{joy:7});}else activityFeedback('Pedido recusado','Seu chefe pediu que você demonstre mais resultados.',{stress:4,communication:2});return;
 case 'promotion':if(!useEnergy(18,16))return;if(!S.job){notify('Arrume um emprego primeiro.','warn');return;}if(Math.random()<(S.workQuality+S.skills['Liderança'])/220){S.job.salary=Math.round(S.job.salary*1.28);S.job.level++;S.workQuality=50;activityFeedback('Promoção!', 'Você foi promovido no emprego e recebeu um aumento de 28%.',{joy:9,reputation:4});}else activityFeedback('Promoção adiada','A empresa ainda quer ver mais resultados.',{stress:5});return;
 case 'retire':if(!requireLife(55))return;if(!S.job)return;S.retirement=Math.round((S.job.salary||0)*.38);S.job=null;logStory('Você se aposentou.','work');save();render();notify('Aposentadoria registrada.');return;
 case 'startBiz':return startBusiness(Number(arg));
 case 'growBiz':return growBusiness(Number(arg));
 case 'hireBiz':return hireBusiness(Number(arg));
 case 'sellBiz':return sellBusiness(Number(arg));
 case 'buyHome':return buyHome(Number(arg));
 case 'rentHome':return rentHome(Number(arg));
 case 'sellHome':return sellHome(Number(arg));
 case 'buyVehicle':return buyVehicle(Number(arg));
 case 'sellVehicle':return sellVehicle(Number(arg));
 case 'invest':return invest(arg);
 case 'sellInvest':return sellInvest(Number(arg));
 case 'payDebt':if(!requireLife(18))return;if(S.debt<=0)return;{let paid=Math.min(S.cash,S.debt);S.cash-=paid;S.debt-=paid;save();render();notify('Dívida amortizada: '+money(paid));return;}
 case 'crime':return commitCrime(Number(arg));
 case 'prisonStudy':if(!requireLife(16)||!S.prison)return;if(!useEnergy(12,16))return;activityFeedback('Tempo na biblioteca da prisão','Você aproveitou o tempo para ler e estudar.',{intel:7,discipline:6,stress:-3});return;
 case 'prisonGoodBehavior':if(!requireLife(16)||!S.prison)return;if(!useEnergy(15,16))return;if(Math.random()<.4){S.prison=Math.max(0,S.prison-1);notify('Bom comportamento: pena reduzida em um ano!');}else notify('Seu bom comportamento foi registrado.');change('reputation',4);save();render();return;
 case 'royalDuty':if(!useEnergy(16,16))return;if(!S.royal)return;activityFeedback('Dever oficial','Você participou de uma cerimônia da família real.',{reputation:8,fame:4,communication:4,stress:4});return;
 case 'royalBanquet':if(!useEnergy(18,18))return;if(!S.royal||!pay(7000))return;activityFeedback('Baile no palácio','Sua festa reuniu convidados e pessoas influentes.',{reputation:5,fame:7,joy:8,stress:2});return;
 case 'royalVisit':if(!useEnergy(18,18))return;if(!S.royal||!pay(5000))return;activityFeedback('Viagem diplomática','Você conheceu culturas e representou sua família em uma visita oficial.',{reputation:9,fame:3,intel:4});return;
 case 'royalMarriage':if(!useEnergy(20,18))return;if(S.royal){notify('Você já faz parte da realeza.','warn');return;}if(!pay(35000))return;if(Math.random()<(.1+S.stats.fame/260+S.stats.reputation/400+S.stats.looks/350)){S.royal=true;S.cash+=70000;change('fame',20);logStory('Entrou para a família real.','milestone');notify('👑 Bem-vindo à realeza!');}else notify('A família real não aceitou o pedido.','warn');save();render();return;
 case 'abdicate':if(!S.royal)return;openQuestion('Renunciar à realeza?','Você perderá o estipêndio anual, mas manterá seus bens e conquistará mais liberdade.',[{label:'Manter o título'},{label:'Renunciar',action:()=>{S.royal=false;change('joy',8);change('stress',-8);logStory('Renunciou ao título real.','milestone');save();render();}}]);return;
 case 'lawyer':if(!requireLife(18))return;if(!S.prison)return;if(!pay(30000))return;if(Math.random()<.5){S.prison=Math.max(0,S.prison-rnd(1,5));notify('Seu advogado reduziu a pena!');}else notify('O recurso foi negado.','warn');save();render();return;
 case 'election':return election(arg);
 case 'publicPolicy':if(!useEnergy(16,25))return;if(!S.job||!/(Vereador|Deputado|Prefeito|Governador|Presidente)/.test(S.job.name)){notify('Você precisa ocupar um cargo político.','warn');return;}S.politics.policies++;activityFeedback('Nova política pública','Você liderou uma iniciativa pública sobre '+arg+'.',{politics:6,reputation:5,stress:4});return;
 case 'post':if(!useEnergy(10,13))return;{let gained=rnd(50,800)*Math.max(1,Math.round(S.stats.fame/15));S.social.followers+=gained;S.social.posts++;activityFeedback('Publicação na internet','Você publicou conteúdo e ganhou '+gained.toLocaleString('pt-BR')+' seguidores.',{fame:Math.min(7,Math.max(2,Math.round(gained/800))),communication:3});return;}
 case 'song':if(!useEnergy(20,15))return;if(!pay(650))return;S.counts.songs++;{let views=Math.round(rnd(100,8000)*(1+S.skills['Música']/35+S.stats.fame/40));S.cash+=Math.round(views*.35);activityFeedback('Nova música lançada','Sua música foi ouvida '+views.toLocaleString('pt-BR')+' vezes.',{music:7,fame:rnd(1,5),creativity:3});return;}
 case 'book':if(!useEnergy(20,17))return;if(!pay(1300))return;S.counts.books++;{let sales=rnd(300,18000);S.cash+=sales;activityFeedback('Livro publicado','Seu novo livro rendeu '+money(sales)+' em vendas.',{creativity:9,fame:rnd(1,5),intel:2});return;}
 case 'competition':if(!useEnergy(25,12))return;{let win=Math.random()<(.12+S.skills['Esportes']/110);if(win)S.counts.trophies++;activityFeedback(win?'🏅 Você venceu!':'Você competiu!',win?'Treinamento e dedicação deram resultado: conquistou um troféu!':'Você ganhou experiência e aprendeu com a disputa.',{athletic:9,health:-2,joy:win?12:3,fame:win?7:1});return;}
 case 'move':if(!useEnergy(20,18))return;{const dest=DB.countries[Number(arg)];if(!dest)return;if(!pay(11000))return;S.country=dest[0];S.city=dest[1];S.job=null;S.stats.joy=cap(S.stats.joy+6);logStory('Mudou para '+S.city+', '+S.country+'.','milestone');save();render();notify('Você recomeçou em '+S.city+'.');return;}
 case 'backup':return downloadBackup();
 case 'copyBackup':return copyBackup();
 case 'importText':return importBackupText();
 case 'historyMore':pageOffset+=25;render();return;
 case 'changeTab':go(arg,'visao');return;
 case 'changeSection':section=arg;render();return;
 case 'setSector':jobSector=arg;render();return;
 case 'setSearch':searchQuery=arg;render();return;
 case 'showCharacter':openCharacter();return;
 case 'practiceSkill':if(!useEnergy(13,8))return;change(arg,7);change('discipline',2);logStory('Treinou sua habilidade de '+arg+'.');checkAchievements();save();render();notify('Habilidade de '+arg+' aumentou.');return;
 default:notify('Esta opção ainda não está disponível.','warn');return;
 }
}
function pay(n){if(S.cash>=n){S.cash-=n;return true;}notify('Você precisa de '+money(n)+' para isso.','warn');return false;}
function addChild(adopted){const c={name:mkPerson(pick(['F','M'])),age:adopted?rnd(1,8):0,bond:80};v2RandomAgent(c,'Filho');S.children.push(c);S.counts.children++;activityFeedback(adopted?'Adoção concluída':'Novo bebê na família','Sua família recebeu '+c.name+'.',{joy:13,bond:6,stress:4});}
function continueChild(index){if(!S||S.alive){notify('A continuação da dinastia fica disponível depois que a vida atual terminar.','warn');return;}const heir=S.children[index];if(!heir){notify('Selecione um filho.','warn');return;}const share=S.v2?.estatePlan==='conservador'?.65:S.v2?.estatePlan==='filantropia'?.45:.75;const inheritance=Math.max(0,Math.round(netWorth(S)*share/S.children.length));const familyName=heir.name.split(' ');const gen=S.generation;const memory=S.story.slice(0,20);const oldPoints=S.v2?.legacyPoints||0;makeLife({name:familyName.slice(0,-1).join(' '),surname:familyName.at(-1),gender:pick(['M','F']),country:S.country,startAdult:true});S.generation=gen+1;S.v2.legacyPoints=Math.round(oldPoints*.65);S.age=Math.max(18,heir.age);S.cash+=inheritance;S.story.push(...memory.map(x=>({...x,text:'História da geração anterior: '+x.text})));logStory('Você recebeu '+money(inheritance)+' da geração anterior.','milestone');S.achievements.push('rebirth');v2CheckGoals();save();render();}
function enroll(kind){if(!requireLife(18))return;if(S.education.enrolled){notify('Você já está matriculado em um curso.','warn');return;}const k=kind.split('|')[0],major=kind.split('|')[1]||'Administração';const cost=k==='Graduação'?12000:k==='Pós-graduação'?22000:38000;const required=k==='Graduação'?0:k==='Pós-graduação'?1:2;if(S.education.level<required){notify('Você precisa concluir a etapa anterior.','warn');return;}if(!pay(cost))return;S.education={enrolled:true,kind:k,major,level:S.education.level,remaining:k==='Graduação'?4:k==='Pós-graduação'?2:3};logStory('Entrou em '+k+' de '+major+'.','milestone');save();render();notify('Matrícula feita! Avance os anos para concluir.');}
function applyJob(index){if(!requireLife(16))return;let j=DB.jobs[index];if(!j)return;const [name,sector,minAge,degree,salary,skill,required]=j;if(S.age<minAge||S.education.level<degree){notify('Você ainda não atende aos requisitos de idade ou formação.','warn');return;}if(S.prison){notify('Você não pode exercer essa carreira enquanto está preso.','warn');return;}let skillScore=skill==='Disciplina'?S.stats.discipline:S.skills[skill]||0;let chance=.76+(skillScore-required)/140+(S.stats.intel-50)/250;if(name==='Presidente')chance=.25+(S.skills['Política']-60)/130+S.stats.reputation/300;if(Math.random()>Math.max(.1,Math.min(.98,chance))){change('stress',3);notify('Sua candidatura foi recusada. Melhore suas habilidades e tente de novo.','warn');save();render();return;}S.job={name,sector,salary:Math.round(salary*(.85+Math.random()*.32)),level:1,years:0};S.workQuality=50;S.careerYears=0;if(['Presidente','Prefeito','Governador','Deputado','Vereador'].includes(name))S.counts.elections++;logStory('Conquistou emprego: '+name+'.','work');change('joy',6);change('reputation',2);checkAchievements();save();render();notify('🎉 Contratado como '+name+'!');}
function startBusiness(idx){if(!requireLife(18))return;const b=DB.ventures[idx];if(!b)return;if(!pay(b[1]))return;S.businesses.push(v2EnrichBiz({name:b[0],value:b[1],revenue:b[2],margin:b[3],staff:0,profit:0,id:Date.now()+Math.random()}));change('Negócios',5);change('stress',5);logStory('Fundou uma empresa: '+b[0]+'.','work');checkAchievements();save();render();notify('Seu novo negócio abriu as portas!');}
function growBusiness(idx){if(!useEnergy(15,18))return;const b=S.businesses[idx];if(!b)return;let cost=Math.round(b.value*.16);if(!pay(cost))return;b.value+=Math.round(cost*1.8);b.revenue+=Math.round(cost*.95);change('Negócios',5);logStory('Expandiu o negócio '+b.name+'.','work');save();render();notify('Empresa expandida. Receita potencial maior.');}
function hireBusiness(idx){if(!useEnergy(10,18))return;const b=S.businesses[idx];if(!b)return;if(!pay(4200))return;b.staff++;b.revenue+=rnd(8000,21000);change('Liderança',4);save();render();notify('Novo funcionário contratado.');}
function sellBusiness(idx){if(!requireLife(18))return;const b=S.businesses[idx];if(!b)return;openQuestion('Vender '+b.name+'?','O comprador oferece '+money(b.value)+' pela empresa.',[{label:'Manter empresa'},{label:'Vender por '+money(b.value),action:()=>{S.cash+=b.value;S.businesses.splice(idx,1);logStory('Vendeu '+b.name+' por '+money(b.value)+'.','work');save();render();}}]);}
function buyHome(idx){if(!requireLife(18))return;const p=DB.property[idx];if(!p||!pay(p[1]))return;S.homes.push({name:p[0],value:p[1],rent:p[2],rented:false,id:Date.now()+Math.random()});change('joy',p[3]);logStory('Comprou imóvel: '+p[0]+'.','money');checkAchievements();save();render();notify('Imóvel adquirido!');}
function rentHome(idx){if(!requireLife(18))return;const p=S.homes[idx];if(!p)return;p.rented=!p.rented;save();render();notify(p.rented?'Imóvel alugado! Receita anual habilitada.':'Imóvel retirado da locação.');}
function sellHome(idx){if(!requireLife(18))return;const p=S.homes[idx];if(!p)return;openQuestion('Vender imóvel?','Receber '+money(p.value)+' pelo imóvel '+p.name+'?', [{label:'Cancelar'},{label:'Confirmar venda',action:()=>{S.cash+=p.value;S.homes.splice(idx,1);logStory('Vendeu o imóvel '+p.name+'.','money');save();render();}}]);}
function buyVehicle(idx){if(!requireLife(16))return;const v=DB.vehicles[idx];if(!v||!pay(v[1]))return;S.vehicles.push({name:v[0],value:v[1],cost:v[2],id:Date.now()+Math.random()});change('joy',4);save();render();notify('Comprou '+v[0]+'.');}
function sellVehicle(idx){if(!requireLife(16))return;const v=S.vehicles[idx];if(!v)return;S.cash+=v.value;S.vehicles.splice(idx,1);save();render();notify('Vendeu por '+money(v.value));}
function invest(type){if(!requireLife(18))return;const cost=Number(document.getElementById('investValue')?.value||5000);if(!Number.isFinite(cost)||cost<100){notify('Investimento mínimo de R$ 100.','warn');return;}if(!pay(cost))return;S.investments.push({name:type,amount:cost,id:Date.now()+Math.random()});save();render();notify('Aplicou '+money(cost)+' em '+type+'.');}
function sellInvest(idx){if(!requireLife(18))return;const i=S.investments[idx];if(!i)return;S.cash+=i.amount;S.investments.splice(idx,1);save();render();notify('Investimento resgatado.');}
function commitCrime(idx){if(!useEnergy(19,16))return;const item=DB.crimes[idx];if(!item)return;S.counts.crimes++;let skill=S.skills['Direito']+S.stats.intel/2;let chance=.25+(idx*.065)+Math.max(0,S.crimeHeat)/160-skill/450;S.crimeHeat+=item[2];if(Math.random()<chance){S.prison+=item[3]+rnd(0,3);S.counts.arrests++;S.job=null;S.cash=Math.max(0,S.cash-7500);change('joy',-12);change('reputation',-15);logStory('Foi preso por '+item[0].toLowerCase()+' por '+S.prison+' anos.','sad');notify('Você foi preso! Pena: '+S.prison+' anos.','warn');}else{S.cash+=item[1];change('stress',6);change('reputation',-5);logStory('Cometeu '+item[0].toLowerCase()+' sem ser detido.','sad');notify('Você escapou da prisão, por enquanto.');}checkAchievements();save();render();}
function election(type){if(!useEnergy(20,21))return;const rank={Vereador:[21,13000,35,85000],Prefeito:[25,80000,48,240000],Deputado:[25,120000,55,290000],Governador:[30,450000,65,420000],Presidente:[35,1500000,80,650000]};const d=rank[type];if(!d||S.age<d[0]){notify('Você não tem a idade mínima para esse cargo.','warn');return;}if(!pay(d[1]))return;const influence=(S.skills['Política']*.35+S.stats.reputation*.28+S.stats.fame*.18+S.skills['Comunicação']*.13+S.skills['Liderança']*.06);const chance=Math.min(.88,Math.max(.05,(influence-d[2]+32)/100));if(Math.random()<chance){S.job={name:type,sector:'Governo',salary:d[3],years:0,level:1};S.counts.elections++;change('reputation',8);change('fame',12);change('Política',8);logStory('Venceu a eleição para '+type+'.','milestone');notify('Você venceu a eleição!');}else{change('stress',10);change('Política',4);logStory('Candidatou-se para '+type+', mas não venceu.','work');notify('Você não foi eleito desta vez.','warn');}checkAchievements();save();render();}
function go(t,s='visao'){tab=t;section=s;searchQuery='';pageOffset=0;render();window.scrollTo(0,0);}
function resetToStart(){S=null;storeRemove(SAVE_KEY);closeModal();tab='vida';render();}
function openCharacter(){if(!S)return;openInfo('Seu personagem',S.name+' '+S.surname+' · '+S.age+' anos · '+S.city+' · Modo '+(S.mode==='royal'?'Realeza':S.mode==='god'?'Livre':'Normal')+'. Comece em uma família, viva várias gerações e construa uma história única.');}
function downloadBackup(){if(!S)return;const data=JSON.stringify(S,null,2);if(window.VidaNative&&typeof window.VidaNative.exportBackup==='function'){window.VidaNative.exportBackup(data);notify('Escolha uma pasta para salvar seu backup.');return;}const blob=new Blob([data],{type:'application/json'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='VIDAVERSO_backup_'+S.name+'.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),7000);notify('Backup exportado!');}
function copyBackup(){if(!S)return;const x=JSON.stringify(S);const el=document.getElementById('backupText');if(el){el.value=x;el.select();try{document.execCommand('copy');notify('Backup copiado.');}catch(e){notify('Selecione o texto e copie manualmente.');}}}
function importBackupText(){const txt=document.getElementById('backupText')?.value||'';return importBackup(txt);}
function importBackup(txt){let imported=safeJSON(txt);if(!imported||imported.version!==1||!imported.stats||!imported.name||!Array.isArray(imported.children)){notify('Esse arquivo não é um backup válido do VIDAVERSO.','warn');return;}S=imported;initV2();save();go('vida','visao');notify('Sua vida foi restaurada!');}
function saveSlot(){if(!S)return;try{let saves=safeJSON(storeGet('vidaverso-slots'))||[];saves.push({title:S.name+' '+S.surname+' · '+S.age+' anos',date:new Date().toLocaleString('pt-BR'),data:JSON.stringify(S)});saves=saves.slice(-8);storeSet('vidaverso-slots',JSON.stringify(saves));notify('Espaço de vida salvo!');render();}catch(e){notify('Não foi possível guardar outro espaço. Exporte um backup.','warn');}}
function loadSlot(idx){let saves=safeJSON(storeGet('vidaverso-slots'))||[];if(!saves[idx])return;openQuestion('Carregar vida salva?','A vida aberta agora será substituída. Exporte um backup se precisar preservá-la.',[{label:'Cancelar'},{label:'Carregar vida',action:()=>importBackup(saves[idx].data)}]);}
