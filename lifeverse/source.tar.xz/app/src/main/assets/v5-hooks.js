/* V5 preserva os ganchos das versões anteriores e só adiciona novas ações. */
'use strict';
const _v5PreviousMakeLife=makeLife;
makeLife=function(config={}){_v5PreviousMakeLife(config);v5Init();save();render();};
const _v5PreviousRestore=restore;
restore=function(){const yes=_v5PreviousRestore();if(yes){v5Init();save();}return yes;};
const _v5PreviousImport=importBackup;
importBackup=function(x){_v5PreviousImport(x);if(S){v5Init();save();render();}};
const _v5PreviousChild=continueChild;
continueChild=function(index){_v5PreviousChild(index);if(S){/* A nova geração não herda automaticamente os documentos pessoais e dívidas do antecessor. */delete S.v5;v5Init();save();render();}};
const _v5OriginalYear=ageOneYear;
ageOneYear=function(){if(!requireLife())return;_v5OriginalYear();v5AfterYear();};
const _v5OriginalWorth=netWorth;
netWorth=function(s){return _v5OriginalWorth(s)+(s?.v5?(Math.max(0,s.v5.finance.savings||0)+Math.max(0,s.v5.finance.checking||0)+(s.v5.social.loans||[]).reduce((n,x)=>n+(x.closed?0:Math.max(0,x.balance||0)),0)-(s.v5.finance.loans||[]).reduce((n,x)=>n+Math.max(0,x.balance||0),0)-Math.max(0,s.v5.finance.card.balance||0)):0);};
// Via interface, emigração internacional exige documentação. A função antiga
// v4Move permanece para migração de salvamentos e compatibilidade com testes 4.0.
const _v5PreviousCityPicker=v4PickCity;
v4PickCity=function(country){const c=V4_COUNTRIES.get(country);if(!c)return;openQuestion('Escolha onde morar em '+country,'A emigração internacional exige cidadania ou autorização de residência no VIDAVERSO 5.0. Para solicitar, abra Mundo → Documentos.',c.cities.map(city=>({label:city.name+' · custo de vida '+city.factor.toFixed(2),action:()=>v5Immigrate(country,city.name)})).concat([{label:'Cancelar'}]));};
const _v5PreviousAction=action;
action=function(name,arg){
 if(name==='v5Go'){const [t,sec]=String(arg).split('|');return go(t,sec);}
 if(!S)return _v5PreviousAction(name,arg);
 if(name==='v5Bank')return v5FinanceMove(arg,document.getElementById('v5BankAmount')?.value);
 if(name==='v5SwitchBank')return v5ChangeBank(arg);
 if(name==='v5Loan')return v5CreditLoan(document.getElementById('v5LoanAmount')?.value,document.getElementById('v5LoanYears')?.value);
 if(name==='v5Repay'){const [id,amount]=String(arg).split('|');return v5RepayLoan(id,amount);}
 if(name==='v5CardBuy')return v5CardBuy(String(arg));
 if(name==='v5CardPay')return v5CardPayment(document.getElementById('v5PayAmount')?.value);
 if(name==='v5Passport')return v5Passport();
 if(name==='v5Naturalize')return v5Naturalize();
 if(name==='v5ChooseCountry'){S.v5.travel.target=document.getElementById('v5TargetCountry')?.value||S.country;save();render();return;}
 if(name==='v5Visa')return v5Visa(String(arg));
 if(name==='v5Visit')return v5Travel(String(arg));
 if(name==='v5Immigrate')return v5Immigrate(String(arg),document.getElementById('v5TargetCity')?.value||v4City(undefined,arg).name);
 if(name==='v5Exam')return v5EntranceExam();
 if(name==='v5Club')return v5SchoolClub(String(arg));
 if(name==='v5Enroll')return v5EducationWithScholarship('Graduação|'+(document.getElementById('v5Degree')?.value||'Administração'));
 if(name==='v5JobSearch'){S.v5.interviewQuery=(document.getElementById('v5JobQuery')?.value||'').slice(0,60);save();render();return;}
 if(name==='v5Interview'){const [idx,strategy]=String(arg).split('|');return v5MeetInterview(Number(idx),strategy);}
 if(name==='v5SocialLoan')return v5SocialLoan(document.getElementById('v5PersonId')?.value,document.getElementById('v5SocialAmount')?.value);
 if(name==='v5Collect')return v5SocialCollect(String(arg));
 if(name==='v5FamilyMeeting')return v5FamilyMeeting();
 if(name==='v5Stock'){const [i,n]=String(arg).split('|');return v5BusinessPurchase(Number(i),Number(n));}
 if(name==='v5Pricing'){const [i,n]=String(arg).split('|');return v5BusinessPricing(Number(i),Number(n));}
 if(name==='v5AuditFilter'){S.v5.auditFilter=String(arg);save();render();return;}
 if(name==='v4Move'){const [c,city]=String(arg).split('|');return v5Immigrate(c,city);}
 return _v5PreviousAction(name,arg);
};
