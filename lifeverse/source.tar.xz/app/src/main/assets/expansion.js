/* VIDAVERSO 2.0 | Conteúdo original, simulação offline e continuidade de saves 1.x. */
'use strict';
const V2_ASPIRATIONS=[
 {id:'equilibrio',name:'Equilíbrio',emoji:'⚖️',desc:'Construir uma vida estável, cuidar das relações e tomar decisões ponderadas.',stat:'joy',bonus:4},
 {id:'aventura',name:'Aventura',emoji:'🧭',desc:'Viajar, testar limites, descobrir lugares e colecionar experiências.',stat:'health',bonus:5},
 {id:'criacao',name:'Criatividade',emoji:'🎨',desc:'Transformar ideias em músicas, livros, filmes e obras originais.',skill:'Criatividade',bonus:10},
 {id:'familia',name:'Família',emoji:'❤️',desc:'Cultivar amizades, construir laços e criar uma dinastia com memórias.',stat:'joy',bonus:7},
 {id:'ciencia',name:'Conhecimento',emoji:'🔬',desc:'Estudar, ensinar e participar de descobertas importantes.',skill:'Ciências',bonus:10},
 {id:'negocios',name:'Empreender',emoji:'🏢',desc:'Construir negócios sustentáveis, liderar equipes e investir.',skill:'Negócios',bonus:10},
 {id:'servico',name:'Impacto social',emoji:'🌱',desc:'Resolver problemas coletivos, fazer voluntariado e inspirar comunidades.',stat:'reputation',bonus:7},
 {id:'esportes',name:'Superação',emoji:'🏆',desc:'Cuidar do corpo, treinar, competir e desafiar limites.',skill:'Esportes',bonus:10}
];
function v2SetAspiration(id,initial=false){if(!S||!S.v2)return;const a=V2_ASPIRATIONS.find(x=>x.id===id);if(!a)return;S.v2.aspiration=id;if(initial){if(a.stat)change(a.stat,a.bonus);if(a.skill)change(a.skill,a.bonus);}logStory('Escolheu seguir o caminho de '+a.name+'.','milestone');}
const V2_TRAITS=['Leal','Ambicioso','Criativo','Prudente','Generoso','Impulsivo','Curioso','Reservado','Sociável','Determinado','Sensível','Competitivo'];
const V2_ROLES=['Educador','Designer','Analista','Empreendedor','Enfermeiro','Artista','Técnico','Pesquisador','Servidor público','Atleta','Chef','Profissional autônomo'];
const V2_PHASES={prosperidade:{label:'Expansão',icon:'📈',desc:'O mercado está aquecido: oportunidades de carreira e consumo aumentam.'},estabilidade:{label:'Estabilidade',icon:'⚖️',desc:'Economia estável, com oportunidades e riscos equilibrados.'},recessao:{label:'Recessão',icon:'📉',desc:'Contratações difíceis e clientes mais cuidadosos com gastos.'},recuperacao:{label:'Recuperação',icon:'🌤️',desc:'Novos projetos aparecem após um período de dificuldades.'}};
const V2_ARCS=[
 {id:'startup',title:'A empresa que quase ninguém acreditou',emoji:'🚀',group:'Negócios',min:18,desc:'Da ideia no papel ao lançamento e à difícil decisão de expandir.',stages:[
 ['Um problema na cidade','Você encontrou um serviço que ainda não existe na região. Como validar a ideia?', [['Entrevistar clientes',{business:6,intel:4},0,0],['Fazer um protótipo',{business:4,technology:6,cash:-1200},0,1],['Alugar uma sala imediatamente',{cash:-6500,reputation:2},1,1]]],
 ['A primeira crise','A equipe é pequena e um cliente importante quer devolver o pagamento.',[['Devolver e melhorar o produto',{cash:-1600,reputation:8},0,0],['Negociar uma segunda chance',{communication:7,business:5},0,1],['Ignorar a reclamação',{cash:1800,reputation:-9},1,2]]],
 ['Uma proposta inesperada','Um investidor quer metade da empresa para acelerar o crescimento.',[['Crescer de forma independente',{business:9,stress:5},1,0],['Aceitar o investimento',{cash:22000,reputation:5},0,1],['Negociar uma participação menor',{communication:8,cash:12000},0,2]]]]},
 {id:'family',title:'Uma família atravessa gerações',emoji:'🏡',group:'Relações',min:18,desc:'Construa tradições, enfrente divergências e preserve memórias.',stages:[
 ['O almoço de domingo','Um parente não aparece nos encontros há vários meses.',[['Ir visitá-lo',{bond:8,joy:5},0,0],['Organizar uma reunião',{cash:-450,bond:11},0,1],['Deixar para outro dia',{stress:-2,bond:-4},1,1]]],
 ['Uma escolha de escola','A família discute as prioridades para o futuro das crianças.',[['Investir em educação',{cash:-5500,intel:5,bond:8},0,0],['Ouvir cada opinião',{communication:7,bond:6},0,1],['Decidir sozinho',{stress:4,bond:-7},1,1]]],
 ['O álbum encontrado','Uma caixa com registros antigos desperta histórias inesperadas.',[['Digitalizar as memórias',{creativity:7,joy:8},0,0],['Reunir todos para lembrar',{bond:11,joy:7},0,1],['Guardar o álbum',{joy:3},0,2]]]]},
 {id:'music',title:'Uma canção para o mundo',emoji:'🎤',group:'Fama & arte',min:15,desc:'Gravação, turnê e o dilema entre independência e exposição.',stages:[
 ['Música de madrugada','Uma melodia não sai da sua cabeça.',[['Gravar no quarto',{music:6,creativity:8,cash:-450},0,0],['Buscar um produtor',{music:4,cash:-2400},0,1],['Postar trecho em rede social',{fame:3,communication:5},0,2]]],
 ['Um contrato tentador','Uma gravadora oferece divulgação em troca dos direitos da música.',[['Negociar direitos',{communication:7,music:5},0,0],['Assinar e lançar',{cash:9000,fame:8},1,1],['Seguir independente',{music:8,stress:4},0,2]]],
 ['A primeira turnê','Seus fãs querem apresentações em cidades distantes.',[['Turnê pequena',{cash:7500,joy:8,fame:4},0,0],['Turnê ambiciosa',{cash:25000,stress:12,health:-4},1,1],['Fazer shows intimistas',{music:7,joy:7,bond:4},0,2]]]]},
 {id:'politics',title:'Vozes da comunidade',emoji:'🗳️',group:'Sociedade',min:21,desc:'Uma causa local leva você a decisões de impacto público.',stages:[
 ['A reunião dos moradores','Os vizinhos querem resolver um problema de mobilidade.',[['Ouvir os moradores',{communication:7,reputation:5},0,0],['Estudar propostas',{politics:8,intel:5},0,1],['Organizar manifestação pacífica',{reputation:6,stress:5},0,2]]],
 ['O debate difícil','Um adversário ataca sua proposta sem apresentar alternativas.',[['Mostrar evidências',{politics:8,reputation:7},0,0],['Responder com humor',{communication:6,fame:4},0,1],['Retrucar agressivamente',{reputation:-7,stress:8},1,2]]],
 ['A obra necessária','É preciso escolher prioridades dentro de um orçamento pequeno.',[['Priorizar escola',{reputation:9,cash:-3000},0,0],['Apoiar atendimento médico',{reputation:8,cash:-3200},0,1],['Conectar os bairros',{business:4,politics:7},0,2]]]]},
 {id:'science',title:'A descoberta improvável',emoji:'🔬',group:'Conhecimento',min:16,desc:'Um projeto de pesquisa exige paciência, colaboração e ética.',stages:[
 ['Hipótese ousada','Você tem uma pergunta científica que poucos investigaram.',[['Estudar literatura',{sciences:8,intel:6},0,0],['Montar experimento',{sciences:7,cash:-1800},0,1],['Conversar com professor',{communication:5,sciences:5},0,2]]],
 ['Resultados contraditórios','Os primeiros testes não confirmam sua hipótese.',[['Repetir o experimento',{sciences:9,discipline:6,cash:-2200},0,0],['Publicar resultados negativos',{reputation:7,intel:5},0,1],['Esconder os dados',{reputation:-14,stress:7},2,2]]],
 ['Congresso internacional','Você foi convidado para apresentar seu trabalho.',[['Ir apresentar',{cash:-2000,reputation:11},0,0],['Publicar em acesso livre',{sciences:7,reputation:9},0,1],['Formar laboratório colaborativo',{leadership:8,communication:6},0,2]]]]},
 {id:'sports',title:'O caminho até a final',emoji:'🏅',group:'Esportes',min:12,desc:'Treinos, lesões, decisões e o equilíbrio fora da competição.',stages:[
 ['Primeira seleção','Um treinador vê potencial em você.',[['Treinar cedo',{athletic:9,discipline:6},0,0],['Buscar um clube',{cash:-1200,athletic:6},0,1],['Equilibrar escola e treino',{intel:5,athletic:5},0,2]]],
 ['A lesão leve','Você sente um desconforto antes da competição.',[['Consultar fisioterapeuta',{cash:-900,health:8},0,0],['Reduzir a carga',{health:6,stress:-5},0,1],['Ignorar o problema',{athletic:2,health:-11},1,2]]],
 ['A grande final','Uma partida importante pode transformar sua carreira.',[['Jogar com estratégia',{athletic:9,intel:4},0,0],['Confiar na equipe',{leadership:8,joy:7},0,1],['Arriscar tudo',{fame:9,health:-5},1,2]]]]},
 {id:'housing',title:'A rua que você transformou',emoji:'🏙️',group:'Patrimônio',min:18,desc:'Reabilite imóveis e negocie com moradores e comerciantes.',stages:[
 ['Um imóvel abandonado','Uma casa vazia pode virar um projeto de impacto.',[['Levantar custos',{business:6,intel:3},0,0],['Conversar com moradores',{communication:7,reputation:5},0,1],['Comprar por impulso',{cash:-10000,stress:5},1,2]]],
 ['A reforma','O orçamento aumentou, mas a estrutura tem valor histórico.',[['Preservar detalhes',{cash:-3500,reputation:8},0,0],['Usar soluções eficientes',{technology:6,business:4},0,1],['Economizar em tudo',{cash:1500,reputation:-7},1,2]]],
 ['Novo destino','Chegou a hora de escolher como usar o espaço.',[['Abrir centro cultural',{reputation:11,cash:-3200},0,0],['Alugar para negócio local',{cash:11000,business:5},0,1],['Vender e reinvestir',{cash:18000,business:7},0,2]]]]},
 {id:'world',title:'Três fronteiras',emoji:'🌍',group:'Mundo',min:18,desc:'Aprenda idiomas, construa contatos e explore novas oportunidades.',stages:[
 ['Um convite de intercâmbio','Você pode estudar uma temporada em outro país.',[['Economizar e viajar',{cash:-5000,intel:8,joy:5},0,0],['Buscar bolsa',{intel:7,discipline:5},0,1],['Viajar sem planejar',{cash:-9000,stress:6},1,2]]],
 ['Choque de culturas','Você enfrenta uma situação social diferente da sua rotina.',[['Fazer novas amizades',{communication:8,friend:2},0,0],['Fazer curso de idioma',{cash:-800,intel:7},0,1],['Isolar-se',{stress:7,joy:-6},1,2]]],
 ['A proposta de emprego','Uma empresa internacional oferece um novo desafio.',[['Negociar pacote',{cash:9000,communication:5},0,0],['Buscar aprendizado',{career:7,intel:7},0,1],['Voltar para casa',{bond:7,joy:5},0,2]]]]},
 {id:'kitchen',title:'O restaurante dos sonhos',emoji:'🍽️',group:'Negócios',min:18,desc:'Crie o cardápio, sobreviva às críticas e estabeleça sua marca.',stages:[
 ['Primeiro prato','Uma receita especial pode se tornar o começo de uma empresa.',[['Testar com amigos',{creativity:6,communication:5},0,0],['Comprar equipamentos',{cash:-3500,business:5},0,1],['Vender imediatamente',{cash:1200,stress:3},1,2]]],
 ['Crítica viral','Um influenciador publica uma avaliação difícil.',[['Responder com educação',{reputation:7,communication:6},0,0],['Melhorar serviço',{cash:-1800,business:8},0,1],['Atacar o influenciador',{reputation:-12,fame:4},1,2]]],
 ['Filial ou qualidade','O salão está cheio e você pensa na expansão.',[['Abrir filial',{cash:-9000,business:9},1,0],['Aprimorar o menu',{creativity:9,reputation:7},0,1],['Formar equipe',{leadership:9,stress:-4},0,2]]]]},
 {id:'film',title:'Luzes, câmera e escolhas',emoji:'🎬',group:'Fama & arte',min:15,desc:'De um curta amador a uma estreia que coloca tudo à prova.',stages:[
 ['O roteiro perdido','Uma ideia de filme parece impossível com seu orçamento.',[['Reescrever com poucos cenários',{creativity:8,intel:3},0,0],['Buscar financiamento',{cash:6500,communication:6},0,1],['Filmar no celular',{art:7,cash:-400},0,2]]],
 ['Conflito no set','Dois membros da equipe não concordam sobre uma cena.',[['Mediar o conflito',{leadership:8,reputation:5},0,0],['Deixar cada um propor',{creativity:5,communication:6},0,1],['Demiti-los na hora',{stress:8,reputation:-8},1,2]]],
 ['Festival de cinema','Seu filme foi selecionado para um festival independente.',[['Comparecer à estreia',{fame:8,cash:-2500},0,0],['Promover bate-papo',{communication:8,reputation:5},0,1],['Vender distribuição',{cash:13000,business:4},0,2]]]]},
 {id:'environment',title:'O futuro da cidade',emoji:'🌳',group:'Sociedade',min:14,desc:'Reúna pessoas e coloque soluções ambientais em prática.',stages:[
 ['Rio poluído','Um grupo quer limpar uma área natural da cidade.',[['Organizar voluntários',{reputation:6,leadership:5},0,0],['Pesquisar contaminação',{sciences:6,intel:4},0,1],['Pagar equipamento',{cash:-1400,reputation:5},0,2]]],
 ['A indústria responde','Uma empresa local diz que o projeto vai prejudicar empregos.',[['Dialogar com gestores',{communication:7,politics:5},0,0],['Apresentar alternativa técnica',{sciences:7,reputation:6},0,1],['Criar confronto público',{fame:5,stress:7},1,2]]],
 ['O parque revitalizado','O projeto pode virar um espaço permanente da comunidade.',[['Criar associação',{leadership:8,reputation:9},0,0],['Plantar árvores',{health:4,joy:8},0,1],['Captar patrocinadores',{business:7,cash:4500},0,2]]]]},
 {id:'creator',title:'A marca de um criador',emoji:'📱',group:'Fama & arte',min:13,desc:'Produza conteúdo, lide com críticas e escolha seu modelo de negócio.',stages:[
 ['O vídeo inesperado','Uma publicação sua passou a receber atenção.',[['Criar série de vídeos',{creativity:7,fame:4},0,0],['Conversar com seguidores',{communication:8,reputation:4},0,1],['Fazer propaganda agressiva',{cash:1200,reputation:-6},1,2]]],
 ['Parceria questionável','Uma marca oferece dinheiro para você divulgar algo que não conhece.',[['Recusar e explicar',{reputation:9,stress:-2},0,0],['Testar antes de divulgar',{cash:2000,discipline:5},0,1],['Aceitar sem ler',{cash:9000,reputation:-12},1,2]]],
 ['O canal amadurece','Sua audiência pede uma mudança de formato.',[['Experimentar temas novos',{creativity:9,fame:5},0,0],['Criar comunidade',{communication:9,bond:5},0,1],['Abrir produto próprio',{business:9,cash:6500},0,2]]]]},
 {id:'mentor',title:'O mestre e o aprendiz',emoji:'🧠',group:'Conhecimento',min:28,desc:'Ensine alguém e veja como suas escolhas voltam anos depois.',stages:[
 ['Alguém pede ajuda','Uma pessoa no início de carreira quer aprender com você.',[['Dar uma orientação',{leadership:6,reputation:4},0,0],['Marcar encontros mensais',{discipline:6,communication:5},0,1],['Cobrar consultoria',{cash:1200,business:3},0,2]]],
 ['O grande erro','Seu aprendiz comete uma falha que atinge seu projeto.',[['Assumir responsabilidade',{reputation:8,leadership:7},0,0],['Ensinar a corrigir',{intel:6,communication:6},0,1],['Expor o erro',{reputation:-9,stress:5},1,2]]],
 ['O reencontro','A pessoa volta anos depois com uma oportunidade conjunta.',[['Criar iniciativa social',{reputation:10,joy:8},0,0],['Construir negócio',{business:8,cash:9500},0,1],['Agradecer e celebrar',{bond:8,joy:9},0,2]]]]}
];
const V2_EVENT_PACK=[
 ['A conversa na fila','Uma pessoa estranha começa a contar sua história.', [['Escutar até o fim',{joy:4,communication:5}],['Anotar uma ideia',{creativity:5,intel:3}],['Sair discretamente',{stress:-2}]],{min:9}],
 ['Uma notícia difícil','Alguém do seu círculo perdeu uma oportunidade de trabalho.',[['Indicar uma vaga',{reputation:5,bond:5}],['Oferecer uma conversa',{communication:5,joy:3}],['Fazer uma doação',{cash:-450,reputation:6}]],{min:18}],
 ['Curso gratuito','Uma biblioteca oferece vagas para uma oficina concorrida.',[['Participar',{intel:6,discipline:3}],['Convidar amigo',{friend:1,communication:4}],['Compartilhar o curso',{reputation:3}]],{min:10}],
 ['Viagem interrompida','Uma tempestade muda todos os seus planos.',[['Reorganizar itinerário',{stress:-6,intel:3}],['Conhecer a cidade por perto',{joy:6,creativity:2}],['Voltar para casa',{cash:-450,bond:4}]],{min:13}],
 ['Um amigo pediu desculpas','Uma amizade antiga reaparece depois de uma briga.',[['Aceitar e recomeçar',{joy:8,communication:5}],['Conversar sobre limites',{discipline:4,bond:5}],['Manter distância',{stress:-4,joy:-2}]],{min:15}],
 ['Dinheiro encontrado','Você encontra uma carteira esquecida.',[['Procurar o dono',{reputation:8,joy:3}],['Entregar à polícia',{reputation:6,stress:-2}],['Ficar com dinheiro',{cash:280,reputation:-10}]],{min:9}],
 ['Problema no condomínio','O elevador do prédio vive quebrando.',[['Organizar reunião',{leadership:5,business:3}],['Buscar três orçamentos',{intel:5,reputation:3}],['Reclamar nas redes',{fame:2,stress:5}]],{min:18}],
 ['Risco no investimento','Uma mensagem promete dinheiro fácil com retorno garantido.',[['Ignorar proposta',{intel:4,discipline:3}],['Consultar especialista',{cash:-220,business:5}],['Arriscar quantia',{cash:-4000,stress:9}]],{min:18}],
 ['O cachorro do vizinho','Um animal de estimação está perdido.',[['Ajudar a procurar',{reputation:7,joy:6}],['Publicar aviso',{communication:3,reputation:4}],['Aguardar notícias',{stress:-2}]],{min:6}],
 ['Uma entrevista inesperada','Você foi convidado para falar sobre sua trajetória.',[['Aceitar e preparar roteiro',{fame:4,communication:6}],['Dividir mérito com equipe',{reputation:8,leadership:5}],['Recusar educadamente',{stress:-3}]],{min:18}],
 ['Projeto colaborativo','Uma equipe precisa de alguém que organize o trabalho.',[['Assumir liderança',{leadership:7,stress:3}],['Dividir tarefas',{communication:6,discipline:5}],['Ajudar discretamente',{reputation:4,joy:3}]],{min:16}],
 ['Uma mudança no bairro','Uma praça vai receber obras e os moradores discordam.',[['Ouvir todos',{communication:6,politics:4}],['Criar abaixo-assinado',{leadership:5,reputation:5}],['Pesquisar alternativas',{intel:7,discipline:3}]],{min:15}],
 ['Dia de sol inesperado','Você ganhou uma tarde livre em um dia bonito.',[['Passear ao ar livre',{health:5,joy:6}],['Encontrar um amigo',{bond:5,joy:4}],['Estudar um hobby',{creativity:5,stress:-2}]],{min:5}],
 ['Oportunidade de voluntariado','Um projeto social precisa de mais pessoas.',[['Participar agora',{joy:6,reputation:7}],['Convidar colegas',{communication:5,leadership:4}],['Doar material',{cash:-650,reputation:5}]],{min:12}],
 ['Mídia e reputação','Uma foto sua foi publicada fora de contexto.',[['Esclarecer com calma',{communication:6,reputation:5}],['Consultar assessoria',{cash:-1200,stress:-5}],['Retrucar impulsivamente',{reputation:-7,stress:8}]],{min:18}],
 ['Convite para um debate','Você discorda de alguém querido sobre um tema importante.',[['Ouvir primeiro',{bond:5,communication:6}],['Pesquisar os fatos',{intel:6,reputation:4}],['Evitar assunto',{stress:-4}]],{min:15}],
 ['A vida online','Você percebe que está usando muito tempo em telas.',[['Criar limites',{discipline:7,health:4}],['Trocar por passeio',{health:5,joy:6}],['Continuar sem mudanças',{stress:5,joy:-3}]],{min:12}],
 ['Tempo para recomeçar','Uma atividade antiga volta a despertar seu interesse.',[['Praticar toda semana',{discipline:6,joy:7}],['Buscar um professor',{cash:-600,intel:6}],['Compartilhar com amigos',{friend:1,communication:4}]],{min:12}],
 ['Cliente insatisfeito','Uma pessoa apresenta uma reclamação justa sobre seu serviço.',[['Resolver integralmente',{cash:-1300,reputation:8}],['Negociar alternativa',{communication:7,business:5}],['Ignorar',{reputation:-11,stress:4}]],{min:18,requires:'business'}],
 ['Uma proposta de aquisição','Uma empresa maior quer adquirir uma marca sua.',[['Analisar números',{business:8,intel:4}],['Negociar sociedade',{communication:6,reputation:4}],['Continuar independente',{discipline:4,stress:3}]],{min:18,requires:'business'}],
 ['A equipe esgotada','Um projeto no trabalho está atrasado e a equipe parece cansada.',[['Redistribuir tarefas',{leadership:8,career:4}],['Pedir mais prazo',{communication:6,stress:-4}],['Exigir trabalho extra',{career:3,reputation:-5}]],{min:18,requires:'job'}],
 ['Uma homenagem no trabalho','Colegas querem celebrar um projeto importante.',[['Agradecer equipe',{reputation:7,leadership:5}],['Organizar almoço',{cash:-500,joy:7}],['Pedir promoção',{career:6,stress:3}]],{min:18,requires:'job'}],
 ['Fim de semestre','As avaliações estão chegando e você está atrasado nos estudos.',[['Criar cronograma',{discipline:8,intel:4}],['Pedir ajuda',{communication:4,intel:5}],['Virar a noite',{intel:3,health:-5,stress:7}]],{min:15,requires:'study'}],
 ['A conversa sobre o futuro','Seu parceiro quer saber como vocês imaginam a próxima década.',[['Planejar juntos',{bond:9,joy:4}],['Conversar com sinceridade',{bond:6,communication:5}],['Evitar conversa',{bond:-7,stress:3}]],{min:18,requires:'spouse'}],
 ['Um filho em dúvida','Uma criança da família busca apoio em uma decisão importante.',[['Escutar sem julgar',{bond:9,joy:4}],['Ajudar a pesquisar opções',{intel:4,bond:7}],['Decidir por ela',{bond:-5,discipline:2}]],{min:22,requires:'children'}],
 ['Uma decisão financeira difícil','Seus gastos estão altos e seu trabalho não acompanha.',[['Rever orçamento',{business:7,discipline:5}],['Buscar nova renda',{cash:2400,stress:6}],['Fazer mais dívida',{debt:4500,joy:3}]],{min:18,condition:s=>s.debt>1000||s.cash<4000}],
 ['O encontro de gerações','Um parente idoso compartilha uma memória da infância.',[['Gravar depoimento',{bond:7,creativity:5}],['Cozinhar algo juntos',{joy:6,bond:7}],['Perguntar sobre história familiar',{intel:6,bond:4}]],{min:35}],
 ['Um título na imprensa','Um jornalista quer contar a história da sua trajetória.',[['Dar entrevista completa',{fame:6,communication:5}],['Preservar privacidade',{stress:-4,bond:3}],['Citar as pessoas que ajudaram',{reputation:7,leadership:4}]],{min:20,condition:s=>s.stats.fame>25}],
 ['Um período de incerteza','Notícias econômicas fazem você questionar seus planos.',[['Diversificar risco',{business:7,discipline:5}],['Aprender outra habilidade',{technology:5,intel:4}],['Parar de acompanhar notícias',{stress:-6}]],{min:18,condition:s=>s.v2&&s.v2.world.phase==='recessao'}],
 ['Um prêmio local','Você foi indicado por sua contribuição à comunidade.',[['Compartilhar prêmio',{reputation:8,bond:4}],['Agradecer em discurso',{communication:6,fame:4}],['Fazer doação',{cash:-1800,reputation:8}]],{min:25,condition:s=>s.stats.reputation>55}]
];
function v2RandomAgent(person, role='Amizade'){
 if(!person)return null;
 person.id=person.id||'p_'+Math.random().toString(36).slice(2);
 person.trait=person.trait||pick(V2_TRAITS);
 person.work=person.work||pick(V2_ROLES);
 person.trust=Number.isFinite(person.trust)?cap(person.trust):cap((person.bond||50)+rnd(-12,10));
 person.mood=Number.isFinite(person.mood)?cap(person.mood):rnd(45,85);
 person.memories=Array.isArray(person.memories)?person.memories:[];
 person.role=person.role||role;
 return person;
}
function initV2(){
 if(!S)return;
 if(!S.v2){S.v2={version:2,created:S.year,legacyPoints:0,xp:0,flags:{},pending:[],budget:'equilibrado',difficulty:'normal',
  world:{inflation:4.2,unemployment:6.3,interest:9.0,market:100,phase:'estabilidade',news:'O mundo segue seu ritmo.',history:[]},
  career:{projects:0,success:0,network:20,wellbeing:70,mentors:0,certifications:0,sideIncome:0,history:[],contracts:0},
  saga:null,completedSagas:[],sagaHistory:[],relations:[],ledger:[],yearHistory:[],journal:[],diaryTheme:'esperança',estatePlan:'igualitario',
  wishes:[],habits:{sleep:55,fitness:40,learning:40,kindness:50},marketSignals:[],globalAchievements:[]};}
 const v=S.v2;
 v.flags=v.flags||{};v.pending=v.pending||[];v.world=v.world||{inflation:4.2,unemployment:6.3,interest:9,market:100,phase:'estabilidade',news:'O mercado mudou.',history:[]};v.world.history=v.world.history||[];
 v.career=v.career||{projects:0,success:0,network:20,wellbeing:70,mentors:0,certifications:0,sideIncome:0,history:[],contracts:0};
 v.saga=v.saga||null;v.completedSagas=v.completedSagas||[];v.sagaHistory=v.sagaHistory||[];v.relations=v.relations||[];
 v.ledger=v.ledger||[];v.yearHistory=v.yearHistory||[];v.journal=v.journal||[];v.wishes=v.wishes||[];v.habits=v.habits||{sleep:55,fitness:40,learning:40,kindness:50};
 if(!v.budget)v.budget='equilibrado';if(!v.estatePlan)v.estatePlan='igualitario';if(!v.aspiration)v.aspiration='equilibrio';
 S.parents.forEach(p=>v2RandomAgent(p,'Família')); S.friends.forEach(p=>v2RandomAgent(p,'Amizade'));S.children.forEach(p=>v2RandomAgent(p,'Filho'));
 if(S.partner){v2RandomAgent(S.partner,'Namoro');S.partner.role='Namoro';}if(S.spouse){v2RandomAgent(S.spouse,'Casamento');S.spouse.role='Casamento';}
 S.businesses.forEach(v2EnrichBiz);
}
function v2EnrichBiz(b){b.brand=Number.isFinite(b.brand)?cap(b.brand):rnd(44,69);b.quality=Number.isFinite(b.quality)?cap(b.quality):rnd(49,78);b.morale=Number.isFinite(b.morale)?cap(b.morale):rnd(45,78);b.innovation=Number.isFinite(b.innovation)?cap(b.innovation):rnd(30,65);b.pricing=b.pricing||'equilibrado';b.yearProfit=Number.isFinite(b.yearProfit)?b.yearProfit:0;b.history=b.history||[];return b;}
function v2Ledger(kind,amount,text){if(!S)return;initV2();S.v2.ledger.unshift({year:S.year,kind,amount:Math.round(amount),text});S.v2.ledger=S.v2.ledger.slice(0,125);}
function v2Memory(agent,text){if(!agent)return;v2RandomAgent(agent);agent.memories.unshift({year:S.year,text});agent.memories=agent.memories.slice(0,12);}
function v2Year(){if(!S||!S.v2)return;const v=S.v2,world=v.world;const oldWorth=v.yearHistory.length?v.yearHistory[0].worth:netWorth(S);
 // Não se trata de dados econômicos reais: são condições ficcionais e determinísticas por fase com pequenas flutuações.
 const phases=['estabilidade','prosperidade','recuperacao','estabilidade','recessao','recuperacao'];
 if(Math.random()<.25){world.phase=pick(phases);}
 world.inflation=Math.round(Math.max(1,Math.min(14,world.inflation+rnd(-13,14)/10+(world.phase==='recessao'?0.3:0)))*10)/10;
 world.unemployment=Math.round(Math.max(2,Math.min(16,world.unemployment+rnd(-12,12)/10+(world.phase==='recessao'?.5:world.phase==='prosperidade'?-0.4:0)))*10)/10;
 world.interest=Math.round(Math.max(2,Math.min(21,world.interest+rnd(-12,12)/10))*10)/10;
 world.market=Math.round(Math.max(45,Math.min(240,world.market*(1+(world.phase==='prosperidade'?.075:world.phase==='recessao'?-0.065:.02)+rnd(-3,3)/100))));
 world.news=pick(world.phase==='prosperidade'?['Empresas disputam profissionais qualificados.','Novas ideias encontram investidores.','As famílias estão mais otimistas.']:world.phase==='recessao'?['Empresas anunciam contenção de despesas.','Crédito mais caro preocupa pequenos negócios.','Consumidores revisam seus orçamentos.']:['Profissões emergentes criam oportunidades.','Cidades investem em educação e serviços.','Famílias reavaliam prioridades financeiras.']);
 world.history.unshift({year:S.year,market:world.market,inflation:world.inflation,unemployment:world.unemployment,phase:world.phase});world.history=world.history.slice(0,65);
 // Aplica custo adicional de inflação acima de uma referência estável; não substitui os custos que o jogo base já processou.
 if(S.age>=18){const base=5800+S.children.filter(c=>c.age<18).length*850;let mult=v.budget==='economico'?.83:v.budget==='luxo'?1.52:1;
  let adj=Math.round(base*(world.inflation-4)/100*mult);if(adj>0){S.cash-=adj;v2Ledger('gasto',-adj,'Inflação e custo de vida');}if(adj<0){S.cash-=adj;v2Ledger('ganho',-adj,'Custo de vida favorável');}
  if(v.budget==='economico'){change('stress',-1);change('joy',-1);}else if(v.budget==='luxo'){const extra=Math.round(base*.17);S.cash-=extra;v2Ledger('gasto',-extra,'Estilo de vida luxuoso');change('joy',2);}
  if(S.cash<0){S.debt+=-S.cash;S.cash=0;}
 }
 // Sistema vivo de trabalho e emprego. A progressão responde a desempenho, economia e saúde.
 const c=v.career;c.network=cap(c.network+rnd(-4,2));c.wellbeing=cap(c.wellbeing+(S.stats.stress>75?-6:rnd(-2,3)));
 if(S.job){const skill=(S.skills['Liderança']||30)/6;const merit=(S.workQuality+S.stats.discipline+skill)/3;
  if(Math.random()<.07&&world.phase==='recessao'&&S.workQuality<48&&S.prison===0){v2Memory(S.spouse||S.partner,'A família enfrentou um período sem trabalho.');logStory('Perdeu o emprego durante a recessão.','sad');S.job=null;change('stress',13);change('joy',-8);}
  else if(S.job&&Math.random()<Math.max(.015,(merit-45)/500)&&S.job.years>2&&!S.v3){S.job.level++;S.job.salary=Math.round(S.job.salary*1.085);logStory('Seu desempenho trouxe uma promoção espontânea.','work');c.history.unshift({year:S.year,name:'Promoção',salary:S.job.salary});change('joy',5);}
 }
 // Marcas e equipes evoluem com a economia.
 S.businesses.forEach(b=>{v2EnrichBiz(b);const qualityFactor=(b.quality-55)/600,brandFactor=(b.brand-50)/700,marketFactor=(world.market-100)/800;
  const delta=Math.round((b.revenue||0)*(qualityFactor+brandFactor+marketFactor)*.07);S.cash+=delta;b.yearProfit=(b.profit||0)+delta;
  b.morale=cap(b.morale+rnd(-5,4));b.brand=cap(b.brand+rnd(-4,4)+(b.quality>75?1:0));b.history.unshift({year:S.year,profit:b.yearProfit,brand:b.brand,value:b.value});b.history=b.history.slice(0,30);
  if(b.morale<25&&Math.random()<.28){b.revenue=Math.round(b.revenue*.88);logStory('Baixa satisfação da equipe afetou o negócio '+b.name+'.','work');}
  if(b.brand<22&&Math.random()<.25){b.value=Math.round(b.value*.85);}
 });
 // Relações com memória: sinais de cuidado e conflitos têm consequências persistentes.
 const agents=[...S.friends,...S.parents,...S.children,S.spouse,S.partner].filter(Boolean);
 agents.forEach(p=>{v2RandomAgent(p);p.mood=cap(p.mood+rnd(-7,7));p.trust=cap(p.trust+(p.bond<25?-3:p.bond>75?1:0));if(p.bond<20&&p.role==='Amizade'&&Math.random()<.16){v2Memory(p,'Vocês se afastaram após meses de distanciamento.');p.bond=cap(p.bond-5);}
  if(p.mood<22&&Math.random()<.18){v2Memory(p,'Precisou de apoio em um momento difícil.');}
 });
 for(const pending of v.pending.filter(x=>x.due<=S.year)){if(pending.effect)applyEffect(pending.effect);logStory(pending.text,'milestone');v2Ledger('destino',0,pending.text);}
 v.pending=v.pending.filter(x=>x.due>S.year);
 // O propósito do personagem oferece bônus por escolhas concretas, não apenas por seleção estética.
 const asp=v.aspiration;let pursuit=asp==='equilibrio'?(S.stats.stress<40&&S.stats.joy>55):asp==='aventura'?S.counts.trips>=2:asp==='criacao'?(S.counts.songs+S.counts.books>0):asp==='familia'?(S.children.length>0||S.friends.some(x=>x.bond>75)):asp==='ciencia'?(S.education.level>=1||S.skills['Ciências']>58):asp==='negocios'?(S.businesses.length>0||netWorth(S)>250000):asp==='servico'?(S.counts.volunteer>=2||S.stats.reputation>75):asp==='esportes'?(S.skills['Esportes']>55||v.habits.fitness>70):false;
 if(pursuit){v.xp+=5;change('joy',1);}else if(S.age>25&&Math.random()<.13){change('stress',1);}
 const h=v.habits;h.sleep=cap(h.sleep+rnd(-5,3));h.fitness=cap(h.fitness+rnd(-5,3));h.learning=cap(h.learning+rnd(-4,4));h.kindness=cap(h.kindness+rnd(-5,4));
 if(h.sleep>72){change('health',2);change('stress',-2);}if(h.sleep<22){change('stress',4);change('health',-1);}if(h.fitness>70)change('health',2);
 const worth=netWorth(S),changeWorth=worth-oldWorth;
 v.yearHistory.unshift({year:S.year,age:S.age,worth,cash:S.cash,debt:S.debt,joy:S.stats.joy,health:S.stats.health,fame:S.stats.fame,job:S.job?.name||'Sem emprego',kids:S.children.length,market:world.market,change:changeWorth});v.yearHistory=v.yearHistory.slice(0,110);
 if(S.age%5===0){logStory('Retrospectiva dos '+S.age+' anos: patrimônio de '+money(worth)+', '+S.children.length+' filhos e '+S.achievements.length+' conquistas.','milestone');}
 if(v.saga&&S.year>=v.saga.nextYear){v.flags.sagaReady=true;}
 v2CheckGoals();
}
function v2CheckGoals(){if(!S||!S.v2)return;for(const g of V2_GOALS){if(S.v2.flags['goal_'+g.id])continue;if(g.test(S)){S.v2.flags['goal_'+g.id]=true;S.v2.legacyPoints+=(g.points||10);logStory('Missão permanente: '+g.title+'.','milestone');}}}
const V2_GOALS=[
 {id:'firstjob',title:'Primeiro trabalho',test:s=>!!s.job,points:5},{id:'study',title:'Continuar aprendendo',test:s=>s.education.level>=1,points:8},
 {id:'family',title:'Construir uma família',test:s=>s.children.length>=1,points:10},{id:'circle',title:'Amizades de verdade',test:s=>s.friends.filter(x=>x.bond>=70).length>=3,points:12},
 {id:'property',title:'Um lar para chamar de seu',test:s=>s.homes.length>=1,points:10},{id:'entrepreneur',title:'Primeira empresa',test:s=>s.businesses.length>=1,points:12},
 {id:'rich',title:'Conquistar um milhão',test:s=>netWorth(s)>=1000000,points:20},{id:'million',title:'Dez milhões de patrimônio',test:s=>netWorth(s)>=10000000,points:30},
 {id:'journey',title:'Conhecer o mundo',test:s=>s.counts.trips>=5,points:10},{id:'philanthropy',title:'Devolver à comunidade',test:s=>s.counts.volunteer>=8,points:12},
 {id:'creative',title:'Uma obra publicada',test:s=>s.counts.songs+s.counts.books>=1,points:8},{id:'founder',title:'Liderar uma grande equipe',test:s=>s.businesses.some(b=>b.staff>=15),points:15},
 {id:'heart',title:'Anos de compromisso',test:s=>s.spouse&&s.spouse.years>=15,points:18},
 {id:'arc1',title:'Primeira saga concluída',test:s=>s.v2.completedSagas.length>=1,points:15},
 {id:'arc5',title:'Contador de histórias',test:s=>s.v2.completedSagas.length>=5,points:30},
 {id:'projects',title:'Mestre dos projetos',test:s=>s.v2.career.success>=10,points:18},
 {id:'network',title:'Rede profissional forte',test:s=>s.v2.career.network>=90,points:12},
 {id:'memory',title:'Guardar lembranças',test:s=>s.v2.journal.length>=12,points:15},
 {id:'generations',title:'Um legado que continua',test:s=>s.generation>=3,points:30},
 {id:'sage',title:'Muitas experiências',test:s=>s.age>=85,points:25}
];
function v2CanSpend(energy,cost=0,age=0){if(!requireLife(age))return false;if(S.cash<cost){notify('Dinheiro insuficiente: precisa de '+money(cost)+'.','warn');return false;}return useEnergy(energy,age);}
function v2Apply(extra={}){const effect={};for(const [k,value]of Object.entries(extra)){if(k==='network')S.v2.career.network=cap(S.v2.career.network+value);else if(k==='wellbeing')S.v2.career.wellbeing=cap(S.v2.career.wellbeing+value);else if(k==='xp')S.v2.xp+=value;else effect[k]=value;}applyEffect(effect);}
function v2ArcPlay(){const a=S.v2.saga;if(!a)return;const arc=V2_ARCS.find(x=>x.id===a.id);if(!arc)return;if(a.nextYear>S.year){notify('O próximo capítulo chega em '+a.nextYear+'.','warn');return;}if(!v2CanSpend(10,0,arc.min))return;
 const stage=arc.stages[a.step];if(!stage)return;
 openQuestion(arc.emoji+' '+stage[0],stage[1],stage[2].map((o,i)=>({label:o[0],action:()=>{
 v2Apply(o[1]);const risk=o[2]||0;const success=risk===0||Math.random()>(risk===1?.24:.6);
 S.v2.sagaHistory.unshift({year:S.year,arc:arc.title,chapter:a.step+1,choice:o[0],success});
 logStory(arc.title+' — capítulo '+(a.step+1)+': '+o[0]+(success?'.':' (a escolha trouxe dificuldades).'),'event');
 if(!success){change('stress',6);change('reputation',-3);S.v2.pending.push({due:S.year+1,text:'Uma escolha anterior em '+arc.title+' cobrou seu preço.',effect:{joy:-3}});}
 a.step++;a.nextYear=S.year+1;if(a.step>=arc.stages.length){S.v2.completedSagas.push(arc.id);S.v2.legacyPoints+=25;S.v2.xp+=200;S.v2.saga=null;logStory('Terminou a saga '+arc.title+'. Seu legado ganhou um novo capítulo!','milestone');notify('🏆 Saga concluída! +25 pontos de legado.');}
 if(arc.group==='Sociedade'&&S.v2.aspiration==='servico'||arc.group==='Conhecimento'&&S.v2.aspiration==='ciencia'||arc.group==='Negócios'&&S.v2.aspiration==='negocios'||arc.group==='Esportes'&&S.v2.aspiration==='esportes'||arc.group==='Fama & arte'&&S.v2.aspiration==='criacao'){S.v2.xp+=12;}
 v2CheckGoals();save();render();}})));
}
function v2ChooseAdvancedEvent(){const pool=V2_EVENT_PACK.filter(item=>{let t=item[3]||{};return S.age>=(t.min||0)&&S.age<=(t.max||110)&&(!t.requires||t.requires==='job'&&S.job||t.requires==='business'&&S.businesses.length||t.requires==='spouse'&&(S.spouse||S.partner)||t.requires==='children'&&S.children.length||t.requires==='study'&&S.education.enrolled)&&(!t.condition||t.condition(S));});
 if(!pool.length)return false;const [title,body,opts]=pick(pool);
 openQuestion('✦ '+title,body,opts.map(([label,effect])=>({label,action:()=>{v2Apply(effect);if(Math.random()<.28)S.v2.pending.push({due:S.year+1,text:'As consequências de "'+title+'" voltaram à sua história.',effect:{joy:rnd(-3,4)}});logStory(title+': '+label+'.','event');save();render();}})));return true;
}
function v2PersonById(id){initV2();return [...S.friends,...S.parents,...S.children,S.partner,S.spouse].filter(Boolean).find(x=>x.id===id);}
function v2Act(name,arg){if(!S)return false;initV2();let v=S.v2;
 if(name==='v2Aspiration'){if(!requireLife(12))return true;if(v.aspiration===arg)return true;if(v.aspirationChangedYear===S.year){notify('Você já redefiniu seu propósito neste ano.','warn');return true;}if(!useEnergy(12,12))return true;v2SetAspiration(arg,false);v.aspirationChangedYear=S.year;save();render();notify('Seu propósito mudou. Seus próximos anos vão refletir isso.');return true;}
 if(name==='v2Budget'){if(!requireLife(18))return true;v.budget=arg;logStory('Escolheu orçamento '+({economico:'econômico',equilibrado:'equilibrado',luxo:'de luxo'}[arg]||arg)+'.','money');save();render();notify('Estratégia financeira atualizada.');return true;}
 if(name==='v2StartSaga'){const a=V2_ARCS.find(x=>x.id===arg);if(!a)return true;if(!requireLife(a.min))return true;if(v.saga){notify('Termine a saga ativa antes de começar outra.','warn');return true;}if(v.completedSagas.includes(a.id)){notify('Você já completou essa história nesta vida.','warn');return true;}v.saga={id:a.id,step:0,nextYear:S.year};logStory('Começou a saga '+a.title+'.','event');save();render();notify('Nova saga iniciada! Abra o capítulo 1.');return true;}
 if(name==='v2SagaStep'){v2ArcPlay();return true;}
 if(name==='v2SagaAbandon'){if(!v.saga)return true;openQuestion('Abandonar história?','Você perderá o progresso desta saga, mas poderá tentar de novo.',[{label:'Continuar'},{label:'Abandonar',action:()=>{v.saga=null;save();render();}}]);return true;}
 if(name==='v2CareerProject'){if(!S.job){notify('Você precisa de um emprego para iniciar um projeto.','warn');return true;}if(!v2CanSpend(18,0,16))return true;const score=S.workQuality*.35+(S.skills['Liderança']||30)*.2+(S.stats.discipline)*.25+v.career.network*.2+rnd(-26,24);const win=score>=48;v.career.projects++;v.career.history.unshift({year:S.year,type:'Projeto',win,job:S.job.name});if(win){v.career.success++;S.workQuality=cap(S.workQuality+9);S.cash+=Math.round(S.job.salary*.05);v2Apply({joy:8,career:8,network:4,xp:30});}else v2Apply({stress:6,intel:2,network:1});logStory('Projeto profissional '+(win?'entregue com sucesso':'enfrentou dificuldades')+'.','work');save();render();openInfo(win?'Projeto de destaque!':'Projeto desafiador',win?'Seu planejamento e habilidade impressionaram a equipe. Você recebeu bônus e experiência.':'Você aprendeu com os imprevistos. Melhorar suas habilidades pode ajudar no próximo projeto.');return true;}
 if(name==='v2Mentor'){if(!v2CanSpend(14,900,16))return true;S.cash-=900;v.career.mentors++;v.career.network=cap(v.career.network+10);v2Apply({intel:3,communication:4,leadership:4,xp:12});logStory('Participou de mentoria profissional.','work');save();render();notify('Rede profissional e habilidades evoluíram.');return true;}
 if(name==='v2Certification'){if(!v2CanSpend(18,3500,16))return true;S.cash-=3500;v.career.certifications++;v.career.network=cap(v.career.network+4);v2Apply({technology:5,discipline:5,intel:5,xp:25});logStory('Conquistou uma certificação profissional.','milestone');save();render();notify('Certificação conquistada!');return true;}
 if(name==='v2SideGig'){if(!v2CanSpend(22,0,16))return true;const earned=Math.round(350+S.stats.discipline*11+(S.skills['Negócios']||15)*16+rnd(0,1200));S.cash+=earned;v.career.sideIncome+=earned;v2Ledger('ganho',earned,'Trabalho extra');v2Apply({business:2,stress:4,xp:8});logStory('Prestou um serviço extra e ganhou '+money(earned)+'.','money');save();render();notify('Renda extra: '+money(earned));return true;}
 if(name==='v2BizAction'){const [idxRaw,kind]=String(arg).split('|');const b=S.businesses[Number(idxRaw)];if(!b)return true;v2EnrichBiz(b);const opts={marketing:{cost:Math.round(b.value*.035)+400,energy:15,txt:'campanha de marketing'},pesquisa:{cost:Math.round(b.value*.045)+600,energy:17,txt:'pesquisa e inovação'},cultura:{cost:2200+b.staff*230,energy:14,txt:'programa para equipe'},qualidade:{cost:2000+Math.round(b.value*.025),energy:15,txt:'melhoria de qualidade'},preco:{cost:0,energy:8,txt:'revisão de preços'}};const o=opts[kind];if(!o)return true;if(!v2CanSpend(o.energy,o.cost,18))return true;S.cash-=o.cost;const bonus={marketing:{brand:12,revenue:0},pesquisa:{innovation:14,quality:3},cultura:{morale:17,quality:3},qualidade:{quality:13,brand:4},preco:{brand:kind==='preco'?1:0}}[kind];for(const [key,val] of Object.entries(bonus))if(key==='revenue')b.revenue+=Math.round(b.revenue*.09);else b[key]=cap(b[key]+val);if(kind==='preco'){b.pricing=b.pricing==='equilibrado'?'premium':b.pricing==='premium'?'acessivel':'equilibrado';b.revenue=Math.round(b.revenue*(b.pricing==='premium'?1.035:b.pricing==='acessivel'?1.02:.98));b.brand=cap(b.brand+(b.pricing==='premium'?-3:2));}
 v2Apply({business:4,xp:12});v2Ledger('gasto',-o.cost,'Empresa: '+o.txt);logStory('Investiu em '+o.txt+' na empresa '+b.name+'.','work');save();render();notify('Estratégia aplicada: '+o.txt);return true;}
 if(name==='v2Relationship'){const [id,kind]=String(arg).split('|');const p=v2PersonById(id);if(!p)return true;const cost=kind==='present'?600:0;if(!v2CanSpend(10,cost,0))return true;S.cash-=cost;const effects={talk:{bond:6,trust:6,mood:4,txt:'Conversaram com sinceridade'},help:{bond:5,trust:10,mood:4,txt:'Você ofereceu ajuda'},advice:{bond:4,trust:3,mood:4,txt:'Pediu um conselho'},present:{bond:12,trust:4,mood:7,txt:'Deu um presente especial'},conflict:{bond:-12,trust:-13,mood:-10,txt:'Tiveram uma discussão séria'},apology:{bond:10,trust:9,mood:3,txt:'Vocês resolveram um conflito'}};let e=effects[kind]||effects.talk;let bonus=p.trait==='Leal'&&kind==='help'?4:p.trait==='Reservado'&&kind==='talk'?-2:0;p.bond=cap(p.bond+e.bond+bonus);p.trust=cap(p.trust+e.trust);p.mood=cap(p.mood+e.mood);v2Memory(p,e.txt+'.');v2Apply({joy:kind==='conflict'?-5:3,communication:kind==='talk'||kind==='apology'?4:1,xp:6});logStory(e.txt+' com '+p.name+'.','event');save();render();notify(e.txt+' com '+p.name);return true;}
 if(name==='v2Habit'){if(!v2CanSpend(12,0,8))return true;const effects={sleep:{sleep:14},fitness:{fitness:14},learning:{learning:14},kindness:{kindness:14}};const e=effects[arg];if(!e)return true;for(const [k,x]of Object.entries(e))v.habits[k]=cap(v.habits[k]+x);v2Apply(arg==='sleep'?{stress:-7,health:3}:arg==='fitness'?{health:5,athletic:3}:arg==='learning'?{intel:5,discipline:3}:{joy:4,reputation:4});logStory('Cuidou do hábito '+({sleep:'sono',fitness:'atividade física',learning:'aprendizado',kindness:'gentileza'}[arg])+'.','activity');save();render();notify('Hábito fortalecido.');return true;}
 if(name==='v2Journal'){const input=document.getElementById('v2JournalText');const text=(input?.value||'').trim().slice(0,450);if(!text){notify('Escreva algo antes de salvar.','warn');return true;}v.journal.unshift({id:Date.now()+Math.random(),year:S.year,age:S.age,text});v.journal=v.journal.slice(0,220);v2CheckGoals();save();render();notify('Memória adicionada ao diário.');return true;}
 if(name==='v2DiaryDelete'){const id=Number(arg);openQuestion('Excluir memória?','A anotação será removida deste arquivo local.',[{label:'Cancelar'},{label:'Excluir',action:()=>{v.journal=v.journal.filter(x=>x.id!==id);save();render();}}]);return true;}
 if(name==='v2Estate'){v.estatePlan=arg;logStory('Atualizou suas preferências de herança: '+arg+'.','milestone');save();render();notify('Plano de legado atualizado.');return true;}
 if(name==='v2Theme'){v.dark=!v.dark;document.documentElement.classList.toggle('dark',!!v.dark);save();render();return true;}
 if(name==='v2NewEvent'){if(!v2CanSpend(8,0,8))return true;v2ChooseAdvancedEvent();return true;}
 if(name==='v2Tour'){go('universo',arg||'visao');return true;}
 return false;
}
// Também enriquece o catálogo de conquistas anterior, sem retirar objetivos salvos.
const V2_EXTRA_CHALLENGES=V2_GOALS.map(g=>({id:'v2_'+g.id,name:g.title,desc:'Missão do VIDAVERSO 2.0 · '+g.points+' pontos de legado',condition:s=>!!(s.v2&&s.v2.flags['goal_'+g.id])}));
DB.challenges.push(...V2_EXTRA_CHALLENGES);
