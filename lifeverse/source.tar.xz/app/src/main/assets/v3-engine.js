/* VIDAVERSO 3.0 — motor incremental, sobre a 2.0. Sem rede, sem compras internas. */
'use strict';
const V3_SCHEMA=3;
const V3_RANKS=['Aprendiz','Júnior','Pleno','Sênior','Especialista','Coordenador','Gerente','Diretor','Executivo'];
const V3_PERSON_TRAITS=['Cuidadoso','Ambicioso','Leal','Impulsivo','Reservado','Generoso','Pragmático','Criativo','Competitivo','Paciente','Desconfiado','Colaborativo'];
const V3_JOB_ROLES=new Map();
(function registerV3Content(){
 const current=new Set();const originals=DB.jobs.slice();DB.jobs.length=0;for(const j of originals){const k=j[0].toLowerCase();if(!current.has(k)){DB.jobs.push(j);current.add(k);}}
 V3_EXTRA_JOBS.forEach(j=>{if(!current.has(j.name.toLowerCase())){DB.jobs.push([j.name,j.sector,j.minAge,j.degree,j.salary,j.skill,j.required]);current.add(j.name.toLowerCase());}V3_JOB_ROLES.set(j.name,j);});
 for(const degree of V3_DEGREES)if(!DB.degrees.includes(degree))DB.degrees.push(degree);
 const present=new Set(DB.property.map(p=>p[0].toLowerCase()));V3_PROPERTIES.forEach(p=>{if(!present.has(p[0].toLowerCase())){DB.property.push(p);present.add(p[0].toLowerCase());}});
 const businesses=new Set(DB.ventures.map(b=>b[0].toLowerCase()));V3_VENTURES.forEach(b=>{if(!businesses.has(b[0].toLowerCase())){DB.ventures.push(b);businesses.add(b[0].toLowerCase());}});
})();
function v3Clamp(x,min=0,max=100){return Math.max(min,Math.min(max,Number.isFinite(Number(x))?Number(x):min));}
function v3Rand(){if(!S||!S.v3)return Math.random();let x=S.v3.seed>>>0;if(!x)x=0x9e3779b9;x^=(x<<13);x^=(x>>>17);x^=(x<<5);S.v3.seed=x>>>0;return (S.v3.seed>>>0)/4294967296;}
function v3Int(min,max){return min+Math.floor(v3Rand()*(max-min+1));}
function v3Chance(chance){return v3Rand()<v3Clamp(chance,0,1);}
function v3Pick(arr){return arr[Math.floor(v3Rand()*arr.length)];}
function v3PersonId(p){if(!p)return '';v2RandomAgent(p);return p.id;}
function v3People(){return [...S.parents,...S.children,...S.friends,S.partner,S.spouse].filter(Boolean);}
function v3UpgradePerson(p,role){if(!p)return null;v2RandomAgent(p,role);const v=S.v3;
 if(!Number.isFinite(p.age))p.age=role==='Família'?S.age+v3Int(19,42):role==='Filho'?0:Math.max(5,S.age+v3Int(-4,5));
 if(!Number.isFinite(p.health))p.health=v3Int(58,95);if(!Number.isFinite(p.loyalty))p.loyalty=v3Int(25,92);
 if(!Number.isFinite(p.ambition))p.ambition=v3Int(25,92);if(!Number.isFinite(p.patience))p.patience=v3Int(25,92);
 if(!Number.isFinite(p.wealth))p.wealth=v3Int(0,10000);if(!Number.isFinite(p.careerYears))p.careerYears=0;
 if(!Number.isFinite(p.lastContactYear))p.lastContactYear=S.year;
 if(!Array.isArray(p.longMemories))p.longMemories=[];
 if(!Array.isArray(p.personalHistory))p.personalHistory=[];
 if(!p.goal)p.goal=v3Pick(['Segurança','Construir família','Sucesso profissional','Viajar','Aprender','Ajudar a comunidade']);
 if(p.role==='Filho'&&p.age<16)p.work=p.age<6?'Criança':'Estudante';
 if(!p.trait)p.trait=v3Pick(V3_PERSON_TRAITS);
 if(!p.role)p.role=role;
 p.alive=p.alive!==false;
 return p;
}
function v3Init(){if(!S)return;
 initV2();if(!S.v3)S.v3={version:V3_SCHEMA,seed:((Number(S.id)||2026)^0x9e3779b9)>>>0,limits:{},career:{history:[],applications:0,everEmployed:0},diplomas:[],academic:{performance:65,failures:0},conditions:[],scheduled:[],events:{},eventLog:[],familyArchive:[],lineage:[],annual:[],jobTracks:{},worldNews:[],debtPaid:0,petsHistory:[],npcsUpdated:0};
 const v=S.v3;v.version=V3_SCHEMA;v.limits=v.limits||{};v.career=v.career||{};v.career.history=v.career.history||[];v.diplomas=v.diplomas||[];v.academic=v.academic||{performance:65,failures:0};v.conditions=v.conditions||[];v.scheduled=v.scheduled||[];v.events=v.events||{};v.eventLog=v.eventLog||[];v.familyArchive=v.familyArchive||[];v.lineage=v.lineage||[];v.annual=v.annual||[];v.jobTracks=v.jobTracks||{};v.worldNews=v.worldNews||[];v.petsHistory=v.petsHistory||[];v.seed=v.seed>>>0||0x9e3779b9;
 if(!v.migratedLegacyDiplomas){if(S.education.level>0&&S.education.major)v.diplomas.push({major:S.education.major,kind:S.education.kind||'Graduação',year:S.year,legacy:true});v.migratedLegacyDiplomas=true;}
 v.school=v.school||{grade:Math.max(30,Math.min(95,Math.round((S.stats.intel+S.stats.discipline)/2))),repeats:0,graduated:S.age>=18,quality:55,yearlyEffort:0};
 S.parents.forEach(p=>v3UpgradePerson(p,'Família'));S.friends.forEach(p=>v3UpgradePerson(p,'Amizade'));S.children.forEach(p=>v3UpgradePerson(p,'Filho'));
 if(S.spouse)v3UpgradePerson(S.spouse,'Casamento');if(S.partner)v3UpgradePerson(S.partner,'Namoro');
 S.businesses.forEach(v2EnrichBiz);S.homes.forEach(v3Home);S.pets.forEach(v3Pet);
 if(S.job)v3UpgradeJob(S.job);
}
function v3Home(h){if(!h)return h;h.condition=Number.isFinite(h.condition)?v3Clamp(h.condition):v3Int(52,92);h.purchasePrice=h.purchasePrice||h.value;h.maintenanceYear=h.maintenanceYear||S.year-1;h.tenantQuality=h.tenantQuality??v3Int(40,95);h.vacancyYears=h.vacancyYears||0;h.loanRemaining=h.loanRemaining||0;h.history=h.history||[];return h;}
function v3Pet(p){p.health=Number.isFinite(p.health)?v3Clamp(p.health):v3Int(62,96);p.bond=Number.isFinite(p.bond)?v3Clamp(p.bond):v3Int(45,70);p.personality=p.personality||v3Pick(['Brincalhão','Tímido','Calmo','Curioso','Teimoso']);p.vetYear=p.vetYear||S.year-1;return p;}
function v3UpgradeJob(j){if(!j)return;j.startedYear=j.startedYear??(S.year-(j.years||0));j.employer=j.employer||v3Employer(j.sector);j.level=Math.max(1,Math.min(9,j.level||1));j.gradeTitle=V3_RANKS[j.level-1];j.performance=Number.isFinite(j.performance)?v3Clamp(j.performance):S.workQuality;j.lastPromotionYear=j.lastPromotionYear??j.startedYear;j.workHistory=j.workHistory||[];}
function v3Employer(sector){return v3Pick(['Horizonte','Aliança','Aurora','Ponte','Nexus','Vereda','Prisma'])+' '+(sector||'Serviços');}
function v3JobDef(j){if(!j)return null;const d=Array.isArray(j)?j:DB.jobs.find(x=>x[0]===j.name);if(!d)return null;
 const explicit=V3_JOB_ROLES.get(d[0]);const degree=d[3];let major=explicit?.major||'';
 if(!major&&/^(Médico|Cirurgião|Psiquiatra|Cardiologista|Pediatra|Neurocirurgião|Dermatologista|Anestesista|Oncologista)$/.test(d[0]))major='Medicina';
 if(!major&&/^(Advogado|Juiz|Promotor|Delegado)$/.test(d[0]))major='Direito';
 if(!major&&/^(Enfermeiro|Fisioterapeuta|Dentista|Farmacêutico|Veterinário)$/.test(d[0]))major=({Enfermeiro:'Enfermagem',Fisioterapeuta:'Fisioterapia',Dentista:'Odontologia',Farmacêutico:'Farmácia',Veterinário:'Veterinária'})[d[0]];
 const experience=explicit?.experience??(d[4]>=250000?9:d[4]>=180000?6:d[4]>=110000?3:0);
 const special=['Presidente','Governador','Prefeito','Deputado','Vereador'].includes(d[0]);
 const stress=({Saúde:68,Justiça:64,Tecnologia:55,Ciências:46,Educação:54,Comércio:59,Básico:55,Mídia:65,Celebridades:73,Esportes:76,Governo:70,Criatividade:51})[d[1]]||50;
 return {id:'job_'+d[0].toLowerCase().replace(/[^a-z0-9]/g,'_'),name:d[0],sector:d[1],minAge:d[2],degree,annualPay:d[4],skill:d[5],required:d[6],major,experience,stress,rankCeiling:9,risks:special?['eleições','opinião pública']:d[1]==='Esportes'?['lesão','contrato']:['mercado','desempenho'],special};
}
function v3DegreesFor(spec){return S.v3.diplomas.some(d=>d.major===spec.major&&(spec.degree<=1||d.kind==='Pós-graduação'||d.kind==='Doutorado'))||S.education.major===spec.major&&S.education.level>=spec.degree;}
function v3JobEligibility(spec){if(!spec)return ['Vaga indisponível.'];const issues=[];
 if(S.age<spec.minAge)issues.push('Idade mínima: '+spec.minAge+' anos');
 if(S.prison>0)issues.push('Não é possível contratar enquanto cumpre pena');
 if(S.education.level<spec.degree)issues.push('Formação exigida: nível '+spec.degree);
 if(spec.major&&spec.degree>0&&!v3DegreesFor(spec))issues.push('Diploma específico: '+spec.major);
 const score=spec.skill==='Disciplina'?S.stats.discipline:(S.skills[spec.skill]||0);
 if(score<spec.required)issues.push('Habilidade '+spec.skill+': '+spec.required+' (atual '+score+')');
 if(spec.experience>Math.max(S.careerYears||0,S.v3.career.everEmployed||0))issues.push('Experiência profissional: '+spec.experience+' anos');
 if(spec.special)issues.push('Exige eleição: use a carreira política, não uma candidatura de emprego');
 return issues;
}
function v3LimitKey(type,entity='global'){return [S.id,S.year,entity,type].join(':');}
function v3Allow(type,entity='global',max=1,opt={}){v3Init();if(!S.alive){notify('Esta vida já terminou.','warn');return false;}
 const key=v3LimitKey(type,entity),current=S.v3.limits[key]||0;
 if(current>=max){notify(opt.message||'Essa atividade já atingiu o limite deste ano. Avance um ano para tentar novamente.','warn');return false;}
 if(opt.energy && (S.stats.energy<opt.energy||S.actionsUsed>=24)){notify('Você precisa de energia e tempo para isso.','warn');return false;}
 if(opt.minAge&&S.age<opt.minAge){notify('Esta atividade exige '+opt.minAge+' anos.','warn');return false;}
 if(opt.cost&&S.cash<opt.cost){notify('Dinheiro insuficiente: precisa de '+money(opt.cost)+'.','warn');return false;}
 S.v3.limits[key]=current+1;save();return true;
}
function v3RefundLimit(type,entity='global'){const k=v3LimitKey(type,entity);if(S.v3.limits[k])S.v3.limits[k]--;}
function v3Paid(cost,description){cost=Math.max(0,Math.round(cost));if(S.cash<cost){notify('Dinheiro insuficiente: precisa de '+money(cost)+'.','warn');return false;}S.cash-=cost;v2Ledger('gasto',-cost,description);return true;}
function v3Memory(p,text,impact=0,kind='evento'){v3UpgradePerson(p,p.role||'Amizade');p.longMemories.unshift({year:S.year,impact,kind,text});p.longMemories=p.longMemories.slice(0,32);v2Memory(p,text);}
function v3ApplyJob(index){if(!requireLife(16))return;v3Init();const d=DB.jobs[index],spec=v3JobDef(d);if(!spec)return;
 const issues=v3JobEligibility(spec);if(issues.length){notify('Candidatura bloqueada: '+issues.join('; ')+'.','warn');return;}
 const key='apply:'+spec.name;if(!v3Allow(key,'career',1,{energy:8,message:'Você já se candidatou a essa vaga neste ano.'}))return;
 if(!v3Allow('interviews','career',4,{energy:8,message:'Você já participou de quatro entrevistas neste ano.'})){v3RefundLimit(key,'career');return;}
 const skill=spec.skill==='Disciplina'?S.stats.discipline:S.skills[spec.skill]||0;
 const chance=v3Clamp(.44+(skill-spec.required)*.008+(S.stats.reputation-50)*.002+(S.stats.intel-50)*.002-S.v2.world.unemployment*.01,.09,.93);
 S.v3.career.applications=(S.v3.career.applications||0)+1;
 if(!v3Chance(chance)){change('stress',2);logStory('Não foi selecionado para '+spec.name+' na entrevista.','work');save();render();notify('Não passou na entrevista. Experiência, habilidades e economia influenciam as vagas.','warn');return;}
 if(S.job)S.v3.career.history.unshift({job:S.job.name,employer:S.job.employer,years:S.job.years,salary:S.job.salary,ended:S.year});
 S.job={name:spec.name,sector:spec.sector,salary:Math.round(spec.annualPay*(.84+v3Rand()*.29)),level:1,years:0};v3UpgradeJob(S.job);S.careerYears=0;S.workQuality=45;
 S.v3.career.history.unshift({job:spec.name,employer:S.job.employer,started:S.year,action:'Contratação'});
 logStory('Foi contratado(a) por '+S.job.employer+' como '+spec.name+'.','work');change('joy',6);change('reputation',2);checkAchievements();save();render();notify('🎉 Contratação concluída em '+S.job.employer+'!');
}
function v3PromotionEligible(s=S){const j=s.job;if(!j)return false;v3UpgradeJob(j);return j.level<9&&j.years>=2&&s.year-j.lastPromotionYear>=2&&s.workQuality>=58&&s.stats.discipline>=48;}
function v3AskPromotion(){if(!requireLife(16))return;if(!S.job){notify('Você precisa estar empregado.','warn');return;}v3UpgradeJob(S.job);
 if(!v3Allow('promotion','job:'+S.job.startedYear+':'+S.job.name,1,{energy:18,message:'Você já solicitou promoção neste emprego este ano.'}))return;
 if(!useEnergy(18,16)){v3RefundLimit('promotion','job:'+S.job.startedYear+':'+S.job.name);return;}
 if(!v3PromotionEligible()){change('stress',3);logStory('Promoção adiada: faltam experiência, desempenho ou tempo no cargo.','work');save();render();notify('Promoção exige 2 anos de serviço, desempenho acima de 58 e disciplina acima de 48.','warn');return;}
 const chance=v3Clamp(.18+(S.workQuality-55)*.009+(S.v3.career.everEmployed||0)*.006+(S.v2.career.network-40)*.003,.08,.8);
 if(!v3Chance(chance)){change('stress',3);logStory('A comissão adiou a sua promoção após avaliação.','work');save();render();notify('A promoção foi recusada nesta avaliação.','warn');return;}
 S.job.level++;S.job.gradeTitle=V3_RANKS[S.job.level-1];S.job.lastPromotionYear=S.year;S.job.salary=Math.round(S.job.salary*(1.09+v3Rand()*.08));S.workQuality=48;
 logStory('Promoção para '+S.job.gradeTitle+' na carreira de '+S.job.name+'.','work');S.v3.career.history.unshift({job:S.job.name,action:'Promoção '+S.job.gradeTitle,year:S.year,salary:S.job.salary});change('joy',7);save();render();notify('🏆 Você foi promovido para '+S.job.gradeTitle+'!');
}
function v3BeforeYear(){v3Init();S.v3._before={year:S.year,job:S.job?.name||null,education:S.education.enrolled?{kind:S.education.kind,major:S.education.major,remaining:S.education.remaining}:null,people:v3People().map(p=>({id:p.id,name:p.name,role:p.role,alive:p.alive})),cash:S.cash,debt:S.debt};
 for(const h of S.homes){v3Home(h);if(h.rented&&h.tenantQuality<35&&v3Chance(.19)){h.rented=false;h.vacancyYears++;logStory('Inquilino deixou o imóvel '+h.name+'.','money');}}
}
function v3AfterYear(){if(!S||!S.v3?._before)return;const before=S.v3._before;if(S.year!==before.year+1)return;
 v3Init();v3AnnualNPCs();v3AnnualEducation(before.education);v3AnnualCareer(before);v3AnnualAssets();v3AnnualHealth();v3ScheduledEvents();v3AnnualPets();if(typeof v3SpecialAnnual==='function')v3SpecialAnnual();
 if(!Number.isFinite(S.cash)){S.cash=0;logStory('Correção preventiva: saldo inválido foi restaurado.','note');}
 if(S.cash<0){S.debt+=-S.cash;S.cash=0;change('stress',4);}if(!Number.isFinite(S.debt)||S.debt<0)S.debt=0;
 S.v3.annual.unshift({year:S.year,age:S.age,income:S.lastYearReport?.income||0,expenses:S.lastYearReport?.living||0,debt:S.debt,cash:S.cash,worth:netWorth(S),people:v3People().filter(p=>p.alive).length});S.v3.annual=S.v3.annual.slice(0,130);
 const latest=S.v2.yearHistory[0];if(latest?.year===S.year){latest.cash=S.cash;latest.debt=S.debt;latest.worth=netWorth(S);latest.job=S.job?.name||'Sem emprego';latest.kids=S.children.length;}
 delete S.v3._before;checkAchievements();save();render();
}
function v3AnnualNPCs(){const agents=v3People();let changes=0;for(const p of agents){v3UpgradePerson(p,p.role||'Amizade');if(!p.alive)continue;
 if(p.role!=='Filho')p.age++; // Filhos já envelhecem na rotina base.
 p.health=v3Clamp(p.health+(p.age>67?-v3Int(0,5):v3Int(-2,2)));
 const yearsApart=Math.max(0,S.year-(p.lastContactYear||S.year));if(yearsApart>=3){p.bond=cap(p.bond-1-(p.trait==='Reservado'?0:1));p.trust=cap(p.trust-1);}
 if(p.age>=18&&v3Chance(p.work==='Estudante'?.34:.09)){const newCareer=v3Pick(['Professor','Motorista','Designer','Enfermeiro','Empresário','Programador','Cozinheiro','Técnico','Atendente','Artista','Desempregado']);p.work=newCareer;p.careerYears=0;if(changes<2&&v3Chance(.25)){v3Memory(p,p.name+' mudou de trabalho e agora atua como '+newCareer+'.',1,'carreira');logStory(p.name+' começou uma nova fase profissional.','event');changes++;}}
 if(p.work!=='Desempregado'&&p.age>=18){p.careerYears++;p.wealth=Math.max(0,Math.round(p.wealth+(p.ambition-45)*32+v3Int(-1600,4200)));}
 if(p.age>=20&&p.role!=='Casamento'&&p.role!=='Namoro'&&v3Chance(.025)){p.married=!p.married;p.personalHistory.unshift({year:S.year,event:p.married?'Casamento':'Separação'});}
 if(p.age>=15&&p.age<=55&&v3Chance(.022)&&p.role!=='Filho'){p.childrenCount=(p.childrenCount||0)+1;p.personalHistory.unshift({year:S.year,event:'Nascimento na família'});}
 if((p.age>80&&v3Chance(v3Clamp((p.age-70)/150,0,.5)))||p.age>=115||p.health<=0&&v3Chance(.4)){
 p.alive=false;v3Memory(p,p.name+' faleceu aos '+p.age+' anos.',-20,'luto');logStory(p.name+' faleceu aos '+p.age+' anos.','sad');change('joy',-7);S.v3.familyArchive.unshift({id:p.id,name:p.name,role:p.role,deathYear:S.year,age:p.age});}
 if(p.role==='Filho'&&p.age>=18&&v3Chance(.20)&&!p.work){p.work=v3Pick(['Estudante','Atendente','Professor','Programador','Cozinheiro','Motorista']);}
 }
 S.v3.npcsUpdated=(S.v3.npcsUpdated||0)+agents.length;
}
function v3GraduationFail(){const a=S.v3.academic;const failChance=v3Clamp(.27-(a.performance-40)*.004,.03,.35);if(v3Chance(failChance)){a.failures++;return true;}return false;}
function v3AnnualEducation(was){const school=S.v3.school;
 if(S.age>=6&&S.age<=25&&!school.graduated){const grade=v3Clamp((S.stats.intel*.42+S.stats.discipline*.28+school.quality*.3)+school.yearlyEffort+v3Int(-24,17));school.grade=Math.round(grade);school.yearlyEffort=0;if(grade<35){school.repeats++;logStory('Você precisa recuperar o desempenho escolar antes de se formar.','sad');}else if(S.age>=18){school.graduated=true;logStory('Concluiu a educação básica.','milestone');}}
 if(!was)return;S.v3.academic.performance=v3Clamp(S.v3.academic.performance+(S.v2.habits.learning-45)*.09+(S.stats.discipline-45)*.11+v3Int(-11,6));
 if(!S.education.enrolled&&S.education.major===was.major&&!S.v3.diplomas.some(d=>d.major===was.major&&d.kind===was.kind)){S.v3.diplomas.push({major:was.major,kind:was.kind,year:S.year});logStory('Qualificação registrada: '+was.kind+' de '+was.major+'.','milestone');}
}
function v3AnnualCareer(before){if(!S.job){if(before.job){S.v3.career.history.unshift({job:before.job,ended:S.year,action:'Fim do vínculo'});}return;}
 v3UpgradeJob(S.job);S.v3.career.everEmployed=(S.v3.career.everEmployed||0)+1;S.job.performance=S.workQuality;
 const w=S.v2.world,sector=S.job.sector;const unemployment=w.unemployment/100;
 const dismissal=v3Clamp(unemployment*.13+(S.workQuality<32?.045:0)+(w.phase==='recessao'?.025:0),.004,.11);
 if(v3Chance(dismissal)){const old=S.job.name;S.v3.career.history.unshift({job:old,ended:S.year,action:'Demissão'});S.job=null;S.workQuality=40;change('stress',12);change('joy',-8);logStory('Foi desligado do emprego de '+old+' durante uma reorganização.','sad');return;}
 const scenario=V3_SECTOR_SCENARIOS[sector];if(scenario&&S.job.years>0&&S.job.years%3===0&&v3Chance(.48)&&!S.v3.events['career_'+S.year]){const s=v3Pick(scenario);S.v3.events['career_'+S.year]=true;
 S.v3.jobOpportunity={title:s[0],choices:s.slice(1),sector,year:S.year};logStory('No trabalho: '+s[0]+'. Veja o painel Carreira 3.0 para decidir.','work');}
 // Avaliação anual não equivale a uma promoção automática.
 S.workQuality=cap(S.workQuality+Math.round((S.stats.discipline-50)/19)+v3Int(-4,4)-(S.stats.stress>78?5:0));
}
function v3AnnualAssets(){
 if(S.age>=18){const country=DB.countries.find(c=>c[0]===S.country);const multiplier=country?.[3]||1;const baseLiving=S.lastYearReport?.living||0;const correction=Math.round(baseLiving*(multiplier-1));S.cash-=correction;S.v3.countryCost=correction;}
 for(const h of S.homes){v3Home(h);
 const cost=Math.round(h.value*(.004+(100-h.condition)/20000));S.cash-=cost;h.condition=v3Clamp(h.condition-v3Int(0,4));
 if(h.rented){if(v3Chance(v3Clamp((90-h.tenantQuality)/500,.015,.15))){const unpaid=Math.round(h.rent*v3Int(1,4));S.cash-=unpaid;h.tenantQuality=v3Clamp(h.tenantQuality-8);logStory('Inadimplência reduziu o aluguel de '+h.name+' em '+money(unpaid)+'.','money');}if(v3Chance(.07)){h.rented=false;h.vacancyYears++;logStory('Locação de '+h.name+' encerrou. Você precisa buscar novo inquilino.','money');}}
 h.history.unshift({year:S.year,value:h.value,condition:h.condition,rented:h.rented,cost});h.history=h.history.slice(0,24);
 }
 for(const v of S.vehicles){const cost=Math.max(0,Math.round(v.cost||v.value*.035));S.cash-=cost;if(v3Chance(.13)){const repair=Math.round(Math.max(200,v.value*.028));S.cash-=repair;logStory('Seu veículo '+v.name+' exigiu um reparo de '+money(repair)+'.','money');}}
 for(const b of S.businesses){v2EnrichBiz(b);const phase=S.v2.world.phase;const variance=(phase==='recessao'?-.12:phase==='prosperidade'?.09:0)+(b.quality-50)*.0009+(b.brand-50)*.0006;
 b.revenue=Math.max(0,Math.round(b.revenue*(1+variance)));if(b.profit<0){b.morale=cap(b.morale-4);b.brand=cap(b.brand-2);}if(b.profit<0&&b.value<5000&&v3Chance(.25)){const failed=b.name;S.businesses=S.businesses.filter(x=>x!==b);logStory('A empresa '+failed+' faliu após sucessivos prejuízos.','sad');change('stress',8);}}
}
function v3AnnualHealth(){for(const cond of S.v3.conditions){if(cond.status!=='active')continue;const def=V3_CONDITIONS.find(x=>x.id===cond.id);if(!def)continue;
 const harm=Math.max(0,def.impact/8+(cond.severity||def.severity)/3-(cond.treatmentLevel||0)*1.4);change('health',-Math.round(harm));
 if(def.type==='aguda'&&v3Chance(.42+Math.min(.25,(cond.treatmentLevel||0)*.10))){cond.status='recovered';cond.recoveredYear=S.year;logStory('Você se recuperou de '+def.name+'.','milestone');}
 if(def.type==='recorrente'&&v3Chance(.12+(cond.treatmentLevel||0)*.10)){cond.status='controlled';cond.recoveredYear=S.year;}
 }
 const active=S.v3.conditions.filter(x=>x.status==='active').length;
 const risk=v3Clamp(.018+(S.age>55?(S.age-55)*.0009:0)+(S.stats.stress>75?.018:0)-(S.v2.habits.fitness>68?.006:0),.007,.11);
 if(active<3&&v3Chance(risk)){const weighted=V3_CONDITIONS.filter(c=>!(S.age<35&&/Osteoporose|Hipertensão|Diabetes tipo 2/.test(c.name)));const def=v3Pick(weighted);
 if(!S.v3.conditions.some(c=>c.id===def.id&&c.status==='active')){S.v3.conditions.push({id:def.id,status:'active',year:S.year,severity:def.severity,treatmentLevel:0});logStory('Surgiu uma condição de saúde: '+def.name+'.','sad');}}
}
function v3AnnualPets(){for(const p of S.pets){v3Pet(p);p.health=v3Clamp(p.health+v3Int(-6,2)-(p.age>=8?3:0));if(p.health<20&&v3Chance(.1)){p.health=0;}}
 const lost=S.pets.filter(p=>p.health<=0);if(lost.length){lost.forEach(p=>{S.v3.petsHistory.unshift({name:p.name,year:S.year,age:p.age});logStory('Seu animal '+p.name+' morreu após problemas de saúde.','sad');change('joy',-6);});S.pets=S.pets.filter(p=>!lost.includes(p));}
}
function v3ScheduledEvents(){const due=S.v3.scheduled.filter(x=>x.due<=S.year);S.v3.scheduled=S.v3.scheduled.filter(x=>x.due>S.year);
 for(const item of due){if(item.targetId){const npc=v3People().find(p=>p.id===item.targetId);if(!npc?.alive)continue;if(item.bond)npc.bond=cap(npc.bond+item.bond);v3Memory(npc,item.text,item.bond||0,'consequencia');}
 if(item.effect)v3SafeEffect(item.effect);logStory(item.text,'event');}
}
function v3SafeEffect(effect){const cost=Math.max(0,-(effect.cash||0));if(cost&&S.cash<cost){S.debt+=cost-S.cash;S.cash=0;const e={...effect};delete e.cash;applyEffect(e);return;}applyEffect(effect);}
function v3Treat(index){if(!requireLife())return;const d=S.v3.conditions[index];if(!d||d.status!=='active'){notify('Não há tratamento pendente.','warn');return;}
 const def=V3_CONDITIONS.find(x=>x.id===d.id);if(!def)return;
 if(!v3Allow('treatment',d.id,2,{energy:10,cost:def.cost,message:'Você já realizou o limite anual de cuidados para essa condição.'}))return;
 if(!useEnergy(10)){v3RefundLimit('treatment',d.id);return;}v3Paid(def.cost,'Tratamento de '+def.name);
 d.treatmentLevel=Math.min(5,(d.treatmentLevel||0)+1);const chance=def.type==='aguda'?.28+S.stats.health/350:def.type==='recorrente'?.2+S.stats.health/500:.08;
 if(v3Chance(chance)){d.status=def.type==='cronica'?'controlled':'recovered';d.recoveredYear=S.year;logStory('Cuidados ajudaram a '+(def.type==='cronica'?'controlar':'superar')+' '+def.name+'.','milestone');notify(def.type==='cronica'?'Condição controlada; acompanhamento continuará importante.':'Tratamento apresentou melhora e recuperação.');}
 else {change('health',2);notify('O tratamento ajudou a aliviar sintomas, sem cura imediata.');}save();render();
}
function v3HomeAction(idx,kind){if(!requireLife(18))return;const h=S.homes[idx];if(!h)return;v3Home(h);
 if(kind==='reformar'){const cost=Math.max(1800,Math.round(h.value*.025));if(!v3Allow('reform','property:'+h.id,1,{energy:12,cost}))return;if(!useEnergy(12)){v3RefundLimit('reform','property:'+h.id);return;}v3Paid(cost,'Reforma do imóvel');h.condition=v3Clamp(h.condition+v3Int(15,32));h.value=Math.round(h.value*(1+.012+v3Rand()*.02));logStory('Reformou '+h.name+' e melhorou sua conservação.','money');}
 else if(kind==='inquilino'){if(h.rented){notify('Esse imóvel já está alugado.','warn');return;}if(!h.rent){notify('Este imóvel não tem aluguel residencial/comercial disponível.','warn');return;}if(!v3Allow('tenant','property:'+h.id,2,{energy:9,cost:300}))return;if(!useEnergy(9)){v3RefundLimit('tenant','property:'+h.id);return;}v3Paid(300,'Anúncio de locação');const chance=v3Clamp(.47+(h.condition-50)*.004+(S.v2.world.phase==='recessao'?-0.12:0),.15,.84);if(v3Chance(chance)){h.rented=true;h.tenantQuality=v3Int(35,94);logStory('Encontrou um inquilino para '+h.name+'.','money');notify('Contrato assinado; a renda anual depende de permanência e adimplência.');}else notify('A procura não resultou em contrato neste ano.','warn');}
 save();render();
}
function v3PetAction(index,kind){if(!requireLife(8))return;const p=S.pets[index];if(!p)return;v3Pet(p);const cost=kind==='veterinario'?420:kind==='treinar'?160:0;if(!v3Allow('pet_'+kind,'pet:'+p.name,1,{energy:8,cost}))return;if(!useEnergy(8)){v3RefundLimit('pet_'+kind,'pet:'+p.name);return;}if(cost)v3Paid(cost,'Cuidados para '+p.name);
 if(kind==='veterinario')p.health=v3Clamp(p.health+v3Int(5,15));else if(kind==='treinar')p.bond=v3Clamp(p.bond+v3Int(7,13));else {p.bond=v3Clamp(p.bond+8);change('joy',4);}logStory('Cuidou de '+p.name+' ('+kind+').','activity');save();render();
}
function v3ResolveCareerEvent(option){const pending=S.v3.jobOpportunity;if(!pending||pending.year>S.year||!S.job)return;const index=Number(option);if(index<0||index>2)return;
 const effects=[{career:9,reputation:5,stress:3},{career:5,communication:5,stress:-2},{career:-10,reputation:-8,stress:7}];v3SafeEffect(effects[index]);S.v3.scheduled.push({due:S.year+v3Int(1,3),text:'O projeto '+pending.title.toLowerCase()+' voltou a influenciar sua reputação.',effect:{reputation:index===2?-5:4}});
 logStory(pending.title+': '+pending.choices[index]+'.','work');delete S.v3.jobOpportunity;save();render();notify('Escolha registrada. Os efeitos poderão voltar em alguns anos.');
}

function v3StudyAtSchool(){if(!requireLife(6))return;if(S.age>25){notify('A educação básica é voltada a adolescentes.','warn');return;}if(!v3Allow('school_effort','school',2,{energy:10,message:'Você já dedicou o tempo permitido aos estudos escolares neste ano.'}))return;if(!useEnergy(10)){v3RefundLimit('school_effort','school');return;}S.v3.school.yearlyEffort+=12;change('intel',2);change('discipline',2);logStory('Estudou para as avaliações escolares.','activity');save();render();}
