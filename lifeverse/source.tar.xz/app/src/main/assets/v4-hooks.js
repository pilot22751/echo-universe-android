/* VIDAVERSO 4.0 — extensão sem romper saves antigos. */
'use strict';
const _v4PreviousMakeLife=makeLife;
makeLife=function(config={}){
 const next={...config};if(next.mode==='royal'&&!v4Country(next.country||'Brasil').monarchy)next.mode='normal';
 _v4PreviousMakeLife(next);v4Init();save();render();
};
const _v4PreviousRestore=restore;
restore=function(){const ok=_v4PreviousRestore();if(ok){v4Init();save();}return ok;};
const _v4PreviousImport=importBackup;
importBackup=function(text){_v4PreviousImport(text);if(S){v4Init();save();render();}};
const _v4PreviousContinue=continueChild;
continueChild=function(index){_v4PreviousContinue(index);if(S){v4Init();save();render();}};
const _v4PreviousYear=ageOneYear;
ageOneYear=function(){if(!requireLife())return;_v4PreviousYear();v4AfterYear();};
const _v4PreviousEligibility=v3JobEligibility;
v3JobEligibility=function(spec){const issues=_v4PreviousEligibility(spec);const local=V4_LOCAL_JOBS.find(x=>x.name===spec?.name);if(local){if(local.country!==S.country)issues.push('Exclusivo de '+local.country);
 if(local.major&&!S.v3.diplomas.some(d=>d.major===local.major)&&S.education.major!==local.major)issues.push('Formação local: '+local.major);
 }return issues;};
const _v4PreviousV3ApplyJob=v3ApplyJob;
v3ApplyJob=function(index){const before=S?.job;_v4PreviousV3ApplyJob(index);if(S?.job&&S.job!==before){const region=v4SalaryFactor(S.country),city=0.8+v4City().factor*.2;S.job.salary=Math.round(S.job.salary*region*city);logStory('Salário ajustado ao mercado de '+S.city+': '+money(S.job.salary)+' por ano.','work');save();render();}};
const _v4PreviousElection=election;
election=function(type){const before=S?.job;_v4PreviousElection(type);if(S?.job&&S.job!==before){S.job.salary=Math.round(S.job.salary*v4SalaryFactor(S.country));save();render();}};
const _v4PreviousEnroll=enroll;
enroll=function(kind){const degree=String(kind||'').split('|')[1];const local=V4_LOCAL_DEGREES.find(x=>x[1]===degree);if(local&&S?.country!==local[0])return notify('Esse curso está disponível apenas em '+local[0]+'.','warn');return _v4PreviousEnroll(kind);};
const _v4PreviousAction=action;
action=function(name,arg){
 if(name==='newLife'){
   const country=document.getElementById('newCountry')?.value||'Brasil',mode=document.getElementById('newMode')?.value||'normal';
   if(mode==='royal'&&!v4Country(country).monarchy){notify('Não existe realeza nacional em '+country+'. Selecione um país com monarquia para nascer na realeza.','warn');return;}
 }
 if(name==='v4City'){v4Init();S.v4.marketCity=String(arg);S.v4.marketPage=0;save();render();return;}
 if(name==='v4Filter'){v4Init();S.v4.marketFilter=String(arg);S.v4.marketPage=0;save();render();return;}
 if(name==='v4Page'){v4Init();S.v4.marketPage=Math.max(0,(S.v4.marketPage||0)+Number(arg));save();render();return;}
 if(name==='v4VehicleFilter'){v4Init();S.v4.vehicleFilter=String(arg);save();render();return;}
 if(name==='v4BuyCash')return v4BuyProperty(arg,false);
 if(name==='v4BuyFinance')return v4BuyProperty(arg,true);
 if(name==='v4Rent')return v4RentProperty(arg);
 if(name==='v4EndRental')return v4EndRental();
 if(name==='v4BuyVehicle')return v4BuyVehicle(arg);
 if(name==='sellHome'&&S.homes[Number(arg)]?.marketListing)return v4SellProperty(Number(arg));
 if(name==='v4PickCountry')return v4PickCity(document.getElementById('v4TargetCountry')?.value||S.country);
 if(name==='v4Move'){const i=String(arg).indexOf('|');return v4Move(String(arg).slice(0,i),String(arg).slice(i+1));}
 if(name==='move'){const dest=DB.countries[Number(arg)];return dest&&v4PickCity(dest[0]);}
 if(name==='v4Casino'){const [kind,option]=String(arg).split('|');return v4CasinoStart(kind,option,v4CasinoStake());}
 if(name==='v4Blackjack')return v4BlackjackAction(String(arg));
 if(name==='v4Night')return v4NightOut(String(arg),document.getElementById('v4Companion')?.value||'');
 if(name==='v4Orientation')return v4SetOrientation(String(arg));
 if(name==='v4Romance')return v4RomanceAction(String(arg));
 if(name==='dating')return v4StartDating();
 if(name==='v4Jump'){const [t,sec]=String(arg).split('|');return go(t,sec);}
 if(name==='v4NavAudit')return go('universo','v4auditoria');
 if(name==='royalMarriage'&&!v4Country().monarchy)return notify('O casamento com uma família real só está disponível em países que possuem monarquia.','warn');
 return _v4PreviousAction(name,arg);
};
// Títulos reais não podem ser obtidos ou preservados numa república.
const _v4PreviousAfterYear=v4AfterYear;
v4AfterYear=function(){_v4PreviousAfterYear();if(S.royal&&!v4Country().monarchy){S.royal=false;S.mode='normal';save();}};
