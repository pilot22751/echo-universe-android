/* VIDAVERSO 4.0 — catálogo geográfico e de experiências originais.
   Países e cidades reais; economia, cotações e imóveis inteiramente simulados. */
'use strict';
const V4_COUNTRY_LINES = `
Brasil|BRL|pt-BR|1|0|São Paulo:1.9,Rio de Janeiro:1.5,Brasília:1.5,Belo Horizonte:1.05,Jaraguá do Sul:1.05,Complexo do Alemão:0.42,Curitiba:1.15
Estados Unidos|USD|en-US|5.1|0|Los Angeles:2.7,Nova York:3.2,Detroit (Michigan):0.95,Chicago:1.55,Miami:2.25,Houston:1.2,Seattle:2.0
Canadá|CAD|en-CA|3.7|1|Toronto:2.4,Vancouver:2.6,Montreal:1.45,Calgary:1.35,Ottawa:1.5
Japão|JPY|ja-JP|0.034|1|Tóquio:2.5,Osaka:1.5,Kyoto:1.7,Sapporo:1.0,Fukuoka:1.25
Reino Unido|GBP|en-GB|6.6|1|Londres:3.0,Manchester:1.25,Edimburgo:1.65,Birmingham:1.15,Cardiff:1.05
Portugal|EUR|pt-PT|5.6|0|Lisboa:2.25,Porto:1.7,Braga:1.05,Coimbra:0.95,Faro:1.4
Espanha|EUR|es-ES|5.6|1|Madri:1.85,Barcelona:2.05,Valência:1.3,Sevilha:1.0,Bilbao:1.3
França|EUR|fr-FR|5.6|0|Paris:2.7,Lyon:1.6,Marseille:1.35,Nantes:1.15,Toulouse:1.25
Alemanha|EUR|de-DE|5.6|0|Berlim:1.8,Munique:2.4,Hamburgo:1.65,Colônia:1.3,Dresden:0.95
Itália|EUR|it-IT|5.6|0|Roma:1.85,Milão:2.3,Florença:1.7,Nápoles:1.05,Turim:1.05
Holanda|EUR|nl-NL|5.6|1|Amsterdã:2.5,Roterdã:1.65,Haia:1.55,Utrecht:1.8
Bélgica|EUR|fr-BE|5.6|1|Bruxelas:1.7,Antuérpia:1.45,Gante:1.4,Liège:1.05
Suíça|CHF|de-CH|6.0|0|Zurique:3.2,Genebra:2.9,Berna:2.0,Basileia:1.85
Áustria|EUR|de-AT|5.6|0|Viena:1.8,Salzburgo:1.6,Innsbruck:1.55,Graz:1.15
Dinamarca|DKK|da-DK|0.75|1|Copenhague:2.5,Aarhus:1.45,Odense:1.1,Aalborg:1.0
Noruega|NOK|nb-NO|0.49|1|Oslo:2.5,Bergen:1.6,Trondheim:1.3,Stavanger:1.5
Suécia|SEK|sv-SE|0.49|1|Estocolmo:2.45,Gotemburgo:1.5,Malmö:1.25,Uppsala:1.25
Finlândia|EUR|fi-FI|5.6|0|Helsinque:1.9,Tampere:1.25,Turku:1.2,Oulu:1.0
Irlanda|EUR|en-IE|5.6|0|Dublin:2.7,Cork:1.6,Galway:1.45,Limerick:1.15
Polônia|PLN|pl-PL|1.32|0|Varsóvia:1.85,Cracóvia:1.5,Gdańsk:1.4,Wrocław:1.35
República Tcheca|CZK|cs-CZ|0.23|0|Praga:2.05,Brno:1.25,Ostrava:0.8,Plzeň:1.05
Hungria|HUF|hu-HU|0.014|0|Budapeste:1.8,Debrecen:0.95,Szeged:0.9,Pécs:0.85
Grécia|EUR|el-GR|5.6|0|Atenas:1.55,Salônica:1.05,Patras:0.82,Heraclião:1.25
Turquia|TRY|tr-TR|0.15|0|Istambul:2.15,Ancara:1.2,Izmir:1.4,Antália:1.45
Rússia|RUB|ru-RU|0.06|0|Moscou:2.4,São Petersburgo:1.55,Kazan:0.95,Novosibirsk:0.85
Ucrânia|UAH|uk-UA|0.13|0|Kyiv:1.15,Lviv:1.0,Odessa:0.95,Dnipro:0.8
Argentina|ARS|es-AR|0.004|0|Buenos Aires:1.65,Córdoba:0.95,Rosário:0.9,Mendoza:1.05
Chile|CLP|es-CL|0.0055|0|Santiago:1.75,Valparaíso:1.2,Concepción:0.95,La Serena:1.15
Uruguai|UYU|es-UY|0.12|0|Montevidéu:1.85,Punta del Este:2.4,Colonia:1.1,Salto:0.8
Paraguai|PYG|es-PY|0.00072|0|Assunção:1.15,Ciudad del Este:0.85,Encarnación:0.85,Luque:0.75
Bolívia|BOB|es-BO|0.75|0|La Paz:1.05,Santa Cruz:1.2,Cochabamba:0.9,Sucre:0.85
Peru|PEN|es-PE|1.36|0|Lima:1.55,Arequipa:1.05,Cusco:1.2,Trujillo:0.9
Colômbia|COP|es-CO|0.0013|0|Bogotá:1.6,Medellín:1.35,Cali:1.05,Cartagena:1.55
Equador|USD|es-EC|5.1|0|Quito:1.2,Guayaquil:1.25,Cuenca:1.0,Manta:1.05
México|MXN|es-MX|0.28|0|Cidade do México:1.85,Guadalajara:1.35,Monterrey:1.55,Cancún:1.9,Puebla:0.95
Costa Rica|CRC|es-CR|0.01|0|San José:1.65,Heredia:1.25,Alajuela:1.15,Liberia:1.2
Panamá|USD|es-PA|5.1|0|Cidade do Panamá:1.85,Colón:1.0,David:0.95,Boquete:1.4
República Dominicana|DOP|es-DO|0.082|0|Santo Domingo:1.45,Santiago:1.05,Punta Cana:2.2,Puerto Plata:1.2
Cuba|CUP|es-CU|0.20|0|Havana:1.4,Santiago de Cuba:0.8,Trinidad:1.0,Holguín:0.85
Jamaica|JMD|en-JM|0.032|1|Kingston:1.5,Montego Bay:1.65,Ocho Rios:1.5,Portmore:0.95
África do Sul|ZAR|en-ZA|0.28|0|Cidade do Cabo:1.85,Joanesburgo:1.35,Durban:1.05,Pretória:1.1
Nigéria|NGN|en-NG|0.0035|0|Lagos:1.75,Abuja:1.55,Ibadan:0.8,Kano:0.8
Quênia|KES|en-KE|0.039|0|Nairóbi:1.55,Mombaça:1.2,Nakuru:0.75,Kisumu:0.8
Egito|EGP|ar-EG|0.10|0|Cairo:1.5,Alexandria:1.15,Gizé:1.0,Luxor:0.9
Marrocos|MAD|ar-MA|0.52|1|Casablanca:1.6,Rabat:1.45,Marrakech:1.5,Tânger:1.25
Tunísia|TND|ar-TN|1.68|0|Túnis:1.3,Sfax:0.9,Sousse:1.1,Bizerte:0.95
Etiópia|ETB|am-ET|0.034|0|Adis Abeba:1.5,Dire Dawa:0.85,Gondar:0.8,Bahir Dar:0.9
Índia|INR|en-IN|0.059|0|Mumbai:2.55,Delhi:1.6,Bengaluru:1.75,Chennai:1.2,Jaipur:0.9
China|CNY|zh-CN|0.70|0|Xangai:2.6,Pequim:2.35,Shenzhen:2.25,Chengdu:1.25,Hangzhou:1.55
Coreia do Sul|KRW|ko-KR|0.0037|0|Seul:2.6,Busan:1.35,Incheon:1.6,Daegu:1.05
Taiwan|TWD|zh-TW|0.16|0|Taipei:2.35,Taichung:1.3,Kaohsiung:1.15,Tainan:0.95
Singapura|SGD|en-SG|3.9|0|Singapura:2.75,Woodlands:1.4,Tampines:1.5,Jurong:1.5
Malásia|MYR|ms-MY|1.17|1|Kuala Lumpur:1.7,George Town:1.35,Johor Bahru:1.25,Ipoh:0.85
Tailândia|THB|th-TH|0.15|1|Bangkok:1.8,Chiang Mai:1.1,Phuket:1.9,Pattaya:1.3
Vietnã|VND|vi-VN|0.00020|0|Hanói:1.5,Cidade de Ho Chi Minh:1.75,Da Nang:1.0,Hue:0.85
Indonésia|IDR|id-ID|0.00031|0|Jacarta:1.8,Bandung:1.0,Surabaya:1.2,Bali (Denpasar):1.9
Filipinas|PHP|en-PH|0.088|0|Manila:1.75,Cebu:1.35,Davao:0.95,Quezon City:1.3
Paquistão|PKR|ur-PK|0.018|0|Karachi:1.5,Lahore:1.15,Islamabad:1.3,Rawalpindi:0.95
Bangladesh|BDT|bn-BD|0.042|0|Daca:1.5,Chittagong:1.05,Khulna:0.85,Rajshahi:0.75
Emirados Árabes Unidos|AED|ar-AE|1.39|1|Dubai:2.8,Abu Dhabi:2.25,Sharjah:1.3,Ajman:0.95
Arábia Saudita|SAR|ar-SA|1.36|1|Riad:1.9,Jeddah:1.75,Dammam:1.15,Medina:1.05
Israel|ILS|he-IL|1.4|0|Tel Aviv:2.65,Jerusalém:1.65,Haifa:1.2,Beersheba:0.95
Jordânia|JOD|ar-JO|7.2|1|Amã:1.65,Irbid:0.9,Aqaba:1.25,Zarqa:0.9
Nova Zelândia|NZD|en-NZ|3.0|1|Auckland:2.5,Wellington:1.7,Christchurch:1.4,Dunedin:1.0
Austrália|AUD|en-AU|3.25|1|Sydney:2.8,Melbourne:2.25,Brisbane:1.85,Perth:1.5,Adelaide:1.3
Camboja|KHR|km-KH|0.00125|1|Phnom Penh:1.5,Siem Reap:1.3,Battambang:0.75,Sihanoukville:1.5
Butão|BTN|dz-BT|0.059|1|Thimphu:1.3,Paro:1.2,Punakha:0.75,Phuntsholing:0.85
Brunei|BND|ms-BN|3.9|1|Bandar Seri Begawan:1.6,Kuala Belait:1.1,Seria:0.9,Jerudong:1.25
`.trim().split('\n').map(line=>{const [name,currency,locale,unit,royal,cities]=line.split('|');return {name,currency,locale,brlPerUnit:Number(unit),monarchy:royal==='1',cities:cities.split(',').map(c=>{const i=c.lastIndexOf(':');return {name:c.slice(0,i),factor:Number(c.slice(i+1))};})};});
const V4_COUNTRIES=new Map(V4_COUNTRY_LINES.map(c=>[c.name,c]));
const V4_PROPERTY_TYPES=[
{name:'Kitnet',base:85000,area:28,rent:.0082}, {name:'Studio',base:160000,area:37,rent:.0074}, {name:'Apartamento',base:300000,area:85,rent:.0060},
{name:'Casa compacta',base:140000,area:65,rent:.0074},{name:'Casa de família',base:300000,area:150,rent:.0061},{name:'Sobrado',base:365000,area:175,rent:.0058},
{name:'Cobertura',base:850000,area:195,rent:.0052},{name:'Casa de praia',base:510000,area:170,rent:.0063},{name:'Mansão',base:2600000,area:400,rent:.0046},
{name:'Terreno',base:165000,area:400,rent:0},{name:'Loja comercial',base:340000,area:96,rent:.0073},{name:'Galpão',base:750000,area:340,rent:.0071},
{name:'Chácara',base:540000,area:320,rent:.0045},{name:'Fazenda',base:2000000,area:4000,rent:.0034}];
const V4_VEHICLE_CATALOG=[
['Fiat Mobi','Popular',52000,7000],['Volkswagen Gol (usado)','Popular',30000,6500],['Honda Civic','Sedã',145000,9500],['Toyota Corolla','Sedã',170000,9000],['Hyundai HB20','Popular',90000,7400],
['Jeep Compass','SUV',185000,13000],['Toyota RAV4','SUV',280000,14000],['Ford F-150','Picape',350000,19000],['Tesla Model 3','Elétrico',270000,8200],['BYD Dolphin','Elétrico',155000,7000],
['BMW Série 3','Luxo',350000,16000],['Mercedes-Benz Classe S','Luxo',750000,29000],['Porsche 911','Esportivo',960000,33000],['Ferrari Roma','Superesportivo',2600000,72000],
['Yamaha MT-07','Motocicleta',56000,5800],['Honda CG 160','Motocicleta',22000,3400],['Harley-Davidson Sportster','Motocicleta',95000,9000],
['Bicicleta urbana','Bicicleta',2300,400],['Bicicleta elétrica','Bicicleta',8000,750],['Lancha de 25 pés','Náutico',220000,18000],['Iate de 50 pés','Náutico',3800000,190000],
['Helicóptero Robinson R44','Aeronave',2700000,165000],['Cessna 172','Aeronave',1800000,115000]];
const V4_MEDIA={
 Brasil:['O Auto da Compadecida','Central do Brasil','Cidade de Deus','Megamente','Divertida Mente'],
 Japão:['A Viagem de Chihiro','Meu Amigo Totoro','Your Name','Akira','Megamente'],
 'Estados Unidos':['Megamente','Shrek','Homem-Aranha no Aranhaverso','De Volta para o Futuro','Interestelar'],
 default:['Megamente','Shrek','Divertida Mente','Interestelar','A Viagem de Chihiro','O Auto da Compadecida']
};
const V4_NIGHT_SPOTS=['Cinema','Bar com música ao vivo','Boate','Festival local','Café noturno','Show'];
const V4_LOCAL_JOBS=[
{name:'Mangaká',country:'Japão',sector:'Criatividade',age:18,degree:0,pay:72000,skill:'Artes',required:24,major:'',experience:1},
{name:'Editor de mangá',country:'Japão',sector:'Mídia',age:22,degree:1,pay:97000,skill:'Criatividade',required:35,major:'Literatura e Editoração',experience:2},
{name:'Animador de anime',country:'Japão',sector:'Criatividade',age:18,degree:0,pay:76000,skill:'Artes',required:35,major:'',experience:1},
{name:'Mestre de cerimônia do chá',country:'Japão',sector:'Criatividade',age:21,degree:0,pay:45000,skill:'Criatividade',required:35,major:'',experience:3},
{name:'Dublador de anime',country:'Japão',sector:'Mídia',age:20,degree:0,pay:85000,skill:'Comunicação',required:32,major:'',experience:1},
{name:'Produtor de Bollywood',country:'Índia',sector:'Mídia',age:24,degree:0,pay:102000,skill:'Criatividade',required:42,major:'',experience:3},
{name:'Coreógrafo de Bollywood',country:'Índia',sector:'Criatividade',age:19,degree:0,pay:68000,skill:'Artes',required:35,major:'',experience:2},
{name:'Ator de Broadway',country:'Estados Unidos',sector:'Celebridades',age:18,degree:0,pay:110000,skill:'Artes',required:45,major:'',experience:2},
{name:'Piloto de NASCAR',country:'Estados Unidos',sector:'Esportes',age:19,degree:0,pay:160000,skill:'Esportes',required:62,major:'',experience:5},
{name:'Roteirista de Hollywood',country:'Estados Unidos',sector:'Mídia',age:22,degree:0,pay:97000,skill:'Criatividade',required:45,major:'',experience:3},
{name:'Sommelier de vinhos do Porto',country:'Portugal',sector:'Criatividade',age:20,degree:0,pay:62000,skill:'Criatividade',required:30,major:'',experience:2},
{name:'Pesquisador de fado',country:'Portugal',sector:'Mídia',age:22,degree:1,pay:68000,skill:'Música',required:32,major:'Etnomusicologia',experience:2},
{name:'Produtor de samba',country:'Brasil',sector:'Mídia',age:18,degree:0,pay:82000,skill:'Música',required:34,major:'',experience:2},
{name:'Carnavalesco',country:'Brasil',sector:'Criatividade',age:21,degree:0,pay:85000,skill:'Artes',required:45,major:'',experience:2},
{name:'Pesquisador da Amazônia',country:'Brasil',sector:'Ciências',age:22,degree:1,pay:107000,skill:'Ciências',required:43,major:'Biologia',experience:2},
{name:'Desenvolvedor de jogos da K-culture',country:'Coreia do Sul',sector:'Tecnologia',age:20,degree:0,pay:96000,skill:'Tecnologia',required:40,major:'',experience:2},
{name:'Produtor de K-pop',country:'Coreia do Sul',sector:'Mídia',age:20,degree:0,pay:99000,skill:'Música',required:48,major:'',experience:3},
{name:'Apresentador de doramas',country:'Coreia do Sul',sector:'Mídia',age:20,degree:0,pay:75000,skill:'Comunicação',required:30,major:'',experience:1},
{name:'Restaurador de castelos',country:'Reino Unido',sector:'Ciências',age:23,degree:1,pay:108000,skill:'Ciências',required:42,major:'Arquitetura',experience:3},
{name:'Artista do West End',country:'Reino Unido',sector:'Celebridades',age:18,degree:0,pay:90000,skill:'Artes',required:45,major:'',experience:2},
{name:'Designer de moda em Paris',country:'França',sector:'Criatividade',age:20,degree:0,pay:117000,skill:'Criatividade',required:48,major:'',experience:3},
{name:'Chef de pâtisserie',country:'França',sector:'Criatividade',age:20,degree:0,pay:70000,skill:'Criatividade',required:33,major:'',experience:2},
{name:'Piloto de Fórmula 1',country:'Itália',sector:'Esportes',age:18,degree:0,pay:182000,skill:'Esportes',required:72,major:'',experience:6},
{name:'Conservador de arte renascentista',country:'Itália',sector:'Criatividade',age:22,degree:1,pay:98000,skill:'Artes',required:45,major:'Artes Visuais',experience:3},
{name:'Treinador de futebol de base',country:'Argentina',sector:'Esportes',age:20,degree:0,pay:57000,skill:'Esportes',required:35,major:'',experience:2},
{name:'Instrutor de surfe',country:'Austrália',sector:'Esportes',age:18,degree:0,pay:62000,skill:'Esportes',required:35,major:'',experience:2},
{name:'Guia de safári',country:'Quênia',sector:'Básico',age:20,degree:0,pay:60000,skill:'Comunicação',required:30,major:'',experience:1}
];
const V4_LOCAL_DEGREES=[
['Japão','Manga e Ilustração Japonesa'],['Japão','Literatura e Editoração'],['Japão','Animação Japonesa'],['Japão','Artes Tradicionais do Japão'],
['Índia','Cinema Indiano'],['Estados Unidos','Produção de Cinema de Hollywood'],['Estados Unidos','Artes Cênicas da Broadway'],
['Brasil','Estudos Amazônicos'],['Brasil','Música Popular Brasileira'],['Portugal','Etnomusicologia'],
['Coreia do Sul','Produção de K-pop'],['França','Alta Costura'],['Itália','Restauração Renascentista'],['Reino Unido','Conservação Patrimonial']
];
(function v4CatalogUpgrade(){
 const existing=new Map(DB.countries.map(c=>[c[0],c]));
 for(const c of V4_COUNTRY_LINES){const old=existing.get(c.name);if(old){old[1]=old[1]||c.cities[0].name;old[2]=c.currency;}
 else DB.countries.push([c.name,c.cities[0].name,c.currency,1]);}
 const seen=new Set(DB.jobs.map(j=>j[0]));for(const job of V4_LOCAL_JOBS){if(!seen.has(job.name)){DB.jobs.push([job.name,job.sector,job.age,job.degree,job.pay,job.skill,job.required]);seen.add(job.name);}}
 for(const [country,degree] of V4_LOCAL_DEGREES)if(!DB.degrees.includes(degree))DB.degrees.push(degree);
})();
