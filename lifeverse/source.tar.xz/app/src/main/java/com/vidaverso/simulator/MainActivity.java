package com.vidaverso.simulator;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.nio.charset.StandardCharsets;
import java.io.OutputStream;

/** Casca Android offline: o jogo e seus dados permanecem no dispositivo. */
public class MainActivity extends Activity {
  private static final int REQ_IMPORT=1102, REQ_EXPORT=1103;
  private WebView web;
  private ValueCallback<Uri[]> fileCallback;
  private String backupToExport;

  @Override public void onCreate(Bundle state){
    super.onCreate(state);
    getWindow().setStatusBarColor(Color.rgb(246,248,251));
    getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    getWindow().setNavigationBarColor(Color.rgb(255,255,255));
    web=new WebView(this);
    web.setBackgroundColor(Color.rgb(246,248,251));
    web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
    WebSettings settings=web.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setAllowFileAccess(true);
    settings.setAllowFileAccessFromFileURLs(false);
    settings.setAllowUniversalAccessFromFileURLs(false);
    settings.setAllowContentAccess(false);
    settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    settings.setDefaultTextEncodingName("UTF-8");
    settings.setMediaPlaybackRequiresUserGesture(true);
    web.addJavascriptInterface(new LocalBridge(), "VidaNative");
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView v,android.webkit.WebResourceRequest r){
        Uri uri=r.getUrl();
        return !"file".equalsIgnoreCase(uri.getScheme()); // Nenhuma rede necessaria.
      }
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
        if(fileCallback!=null)fileCallback.onReceiveValue(null);
        fileCallback=callback;
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("application/json");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try{startActivityForResult(intent,REQ_IMPORT);return true;}
        catch(Exception e){fileCallback=null;return false;}
      }
    });
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  public final class LocalBridge {
    @JavascriptInterface public void exitGame(){runOnUiThread(()->finish());}
    @JavascriptInterface public void exportBackup(String json){
      runOnUiThread(()->{
        backupToExport=json;
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.setType("application/json");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.putExtra(Intent.EXTRA_TITLE,"VIDAVERSO_backup.json");
        try{startActivityForResult(i,REQ_EXPORT);}catch(Exception e){backupToExport=null;}
      });
    }
  }
  @Override protected void onActivityResult(int request,int result,Intent intent){
    super.onActivityResult(request,result,intent);
    if(request==REQ_IMPORT){
      if(fileCallback!=null){Uri[] uris=(result==RESULT_OK&&intent!=null&&intent.getData()!=null)?new Uri[]{intent.getData()}:null;fileCallback.onReceiveValue(uris);fileCallback=null;}
    }else if(request==REQ_EXPORT){
      if(result==RESULT_OK&&intent!=null&&intent.getData()!=null&&backupToExport!=null){
        try(OutputStream out=getContentResolver().openOutputStream(intent.getData())){
          if(out!=null)out.write(backupToExport.getBytes(StandardCharsets.UTF_8));
        }catch(Exception ignored){}
      }
      backupToExport=null;
    }
  }
  @Override public void onBackPressed(){
    if(web!=null){web.evaluateJavascript("(function(){if(typeof currentModal!=='undefined'&&currentModal){closeModal();return;}if(typeof tab!=='undefined'&&tab!=='vida'){go('vida');return;}openQuestion('Sair do jogo?','Seu progresso já foi salvo automaticamente.',[{label:'Continuar jogando'},{label:'Fechar aplicativo',action:function(){window.VidaNative&&VidaNative.exitGame&&VidaNative.exitGame();}}]);})()",null);}
    else super.onBackPressed();
  }
  @Override public void onDestroy(){if(web!=null){web.destroy();web=null;}super.onDestroy();}
}
